<?php
ini_set('display_errors', 'on');
require 'Psr4AutoloaderClass.php';
$loader = new Psr4AutoloaderClass();
$loader->register();
$loader->addNamespace('Addressbook', __DIR__ . '/src/Addressbook');
Addressbook\Controller\Contato::despachar();
?>