<?php
namespace Addressbook\Model;

use Addressbook\Db;

class Contato
{
    
    // DADOS
    private $mensagemDeErro;

    private $codigo;

    private $saudacao;

    private $titulo;

    private $prenome;

    private $nomeDoMeio;

    private $sobrenome;

    private $empresa;

    private $unidade;

    private $nomeDeExibicao;

    private $tituloDoTrabalho;

    private $aniversario;

    private $tel;

    private $celular;

    private $fax;

    private $telpar;

    private $celularpar;

    private $faxpar;

    private $email;

    private $emailpar;

    private $site;

    private $rua;

    private $complemento;

    private $estado;

    private $cep;

    private $comentario;

    private $cidade;

    private $pais;

    private $foto;

    private $linha;
    
    // FIM DOS DADOS
    
    // REQUISIÇAO DE PAGINAS
    public function listar()
    {
        require __DIR__ . '/../View/listar.php';
    }

    public function user()
    {
        require __DIR__ . '/../View/usuario.php';
    }

    public function AlteraUser()
    {
        require __DIR__ . '/../View/usuario.php';
    }

    /**
     * VEREFICA SE O DADO FOI ALTERADO COM SUCESSO E TIRA UM SNAPSHOT;
     * SE O DADO NAO FOR GRAVADO CORRETAMENTE, RESTAURA O ULTIMO SUCESSO;
     * SE FOR IRA GRAVAR E CRIAR UMA NOVA COMMIT;
     * FUNCIONARA APENAS PARA A ALTERACAO DE DADOS.
     */
    
    // Cria os argumentos 'get...'
    public function __call($name, array $args)
    {        
        if (substr($name, 0, 3) == 'get') {            
            $attribute = lcfirst(substr($name, 3));
            //echo print_r($this,TRUE);exit;
            return $this->$attribute;
        }
    }
    // Acaba a criacao
    
    /**
     * VEREFICA SE OS DADOS SÃO NULOS, SE FOREM RETORNA AO INICIO;
     * SE ALGUM FOR PREENCHIDO RETORNA A TELA DE ERRO;
     * SE TODOS FOREM PREENCHIDOS (salvo "Comentario") GRAVA OS DADOS;
     * LOGO DEPOIS ENVIA PARA A TELA DE CATALAGO.
     */
    public function gravar()
    {
        if (isset($_POST['inicio'])) {
            header('Location: http://localhost/addressbook/index.php?m=Contato&a=listar');
            exit();
        }
        if (! isset($_POST['validar']) || ! $this->isValido()) {
            echo "<title>ERRO!</title>";
            echo $this->mensagemDeErro;
            echo ' <a href="javascript:window.history.go(-1)"><center><  Preencher</center></a>';
        } else {
            
            Db::conectar();
            if ($codigo==NULL) {
            $saudacao = $_POST['saudacao'];
            $titulo = $_POST['titulo'];
            $prenome = $_POST['prenome'];
            $nomeDoMeio = $_POST['nomeDoMeio'];
            $sobrenome = $_POST['sobrenome'];
            $empresa = $_POST['empresa'];
            $unidade = $_POST['unidade'];
            $nomeDeExibicao = $_POST['nomeDeExibicao'];
            $tituloDoTrabalho = $_POST['tituloDoTrabalho'];
            $aniversario = $_POST['aniversario'];
            $foto = $_FILES['foto'];
            $tel = $_POST['tel'];
            $telpar = $_POST['telpar'];
            $celular = $_POST['celular'];
            $celularpar = $_POST['celularpar'];
            $fax = $_POST['fax'];
            $faxpar = $_POST['faxpar'];
            $email = $_POST['email'];
            $emailpar = $_POST['emailpar'];
            $site = $_POST['site'];
            $rua = $_POST['rua'];
            $complemento = $_POST['complemento'];
            $estado = $_POST['estado'];
            $cep = $_POST['cep'];
            $cidade = $_POST['cidade'];
            $pais = $_POST['pais'];
            $comentario = $_POST['comentario'];
            $codigo = $_POST['codigo'];
            $dir = "src/Addressbook/Model/img/";
            $baseFoto = basename($_FILES['foto']['name']);
            $url = $dir . $baseFoto;
            move_uploaded_file($_FILES['foto']['tmp_name'], $url);
            $stmt = Db::conectar()->prepare("INSERT INTO addressbook (codigo, Saudacao, Titulo, PreNome, NomeDoMeio, Sobrenome, Empresa, Unidade, NomeDeExibicao, TituloDoTrabalho, Aniversario, Foto, Tel, Celular, Fax, TelPar, CelularPar, FaxPar, Email, EmailPar, Site, Rua, Complemento, Estado, CEP, Cidade, Pais, Comentario) VALUES ('$codigo', '$saudacao', '$titulo', '$prenome', '$nomeDoMeio', '$sobrenome', '$empresa', '$unidade', '$nomeDeExibicao', '$tituloDoTrabalho', '$aniversario', '$url', '$tel', '$celular', '$fax', '$telpar', '$celularpar', '$faxpar', '$email', '$emailpar', '$site', '$rua', '$complemento', '$estado', '$cep', '$cidade', '$pais', '$comentario')");
            $result = $stmt->execute();
            
            if (isset($_POST['codigo']) && !empty($_POST['codigo'])) {
                
                /**
                 * SE A FOTO FOR ENVIADA ELE GRAVA A FOTO E EXCLUI A ANTERIOR;
                 * SE A FOTO NAO FOR ENVIADA ELE IGNORAO ELSE E ENVIA APENAS OS DADOS PRESERVANDO A FOTO.
                 */
                if (empty($baseFoto)) {
                    $stmt = Db::conectar()->prepare("UPDATE `addressbook` SET `Saudacao`='$saudacao',`Titulo`='$titulo',`PreNome`='$prenome',`NomeDoMeio`='$nomeDoMeio',`Sobrenome`='$sobrenome', `Empresa`='$empresa', `Unidade`='$unidade' , `NomeDeExibicao`='$nomeDeExibicao', `TituloDoTrabalho`='$tituloDoTrabalho', `Aniversario`='$aniversario', `Tel`='$tel', `Celular`='$celular', `Fax`='$fax', `TelPar`='$telpar', `CelularPar`='$celularpar', `FaxPar`='$faxpar', `Email`='$email', `EmailPar`='$emailpar', `Site`='$site', `Rua`='$rua', `Complemento`='$complemento', `Estado`='$estado', `CEP`='$cep', `Cidade`='$cidade', `Pais`='$pais' , `Comentario`='$comentario' WHERE  `codigo`= $codigo");
                } else {
                    echo $codigo;
                    exit();
                    $dados = $stmt = Db::conectar()->prepare("SELECT `codigo`, `Foto` FROM `addressbook` WHERE `codigo` =$codigo") or die(mysqli_error());
                    $result = $stmt->execute();
                    foreach ($result as $linha);
                    
                    if (file_exists($linha['Foto'])) {
                        unlink($linha['Foto']);
                    }
                    move_uploaded_file($_FILES['foto']['tmp_name'], $url);
                    
                    $stmt = Db::conectar()->prepare("UPDATE `addressbook` SET `Saudacao`='$saudacao',`Titulo`='$titulo',`PreNome`='$prenome',`NomeDoMeio`='$nomeDoMeio',`Sobrenome`='$sobrenome', `Empresa`='$empresa', `Unidade`='$unidade', `Foto`='$url' , `NomeDeExibicao`='$nomeDeExibicao', `TituloDoTrabalho`='$tituloDoTrabalho', `Aniversario`='$aniversario', `Tel`='$tel', `Celular`='$celular', `Fax`='$fax', `TelPar`='$telpar', `CelularPar`='$celularpar', `FaxPar`='$faxpar', `Email`='$email', `EmailPar`='$emailpar', `Site`='$site', `Rua`='$rua', `Complemento`='$complemento', `Estado`='$estado', `CEP`='$cep', `Cidade`='$cidade', `Pais`='$pais' , `Comentario`='$comentario' WHERE  `codigo`= $codigo");
                }
                $result = $stmt->execute();
                
            }
            } 
            
            header('Location: http://localhost/addressbook/index.php?m=Contato&a=listar');
        }
    }
    // FIM DA VALIDACAO/GRAVAÇAO DE DADOS;
    
    // REMOVE A LINHA EM QUESTÃO;
    public function remover()
    {
        $codigo = $_GET['codigo'];
        
        $dados = $stmt = Db::conectar()->prepare("SELECT `codigo`, `Foto` FROM `addressbook` WHERE `codigo` =$codigo") or die(mysqli_error());
        $result = $stmt->execute();
        $total = $stmt->rowCount();
        $linha = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (file_exists($linha['Foto'])) {
        $excluir = unlink($linha['Foto']);
        }
        $remover = $stmt = Db::conectar()->prepare("DELETE FROM `addressbook` WHERE `codigo` = $codigo ");
        $result = $stmt->execute();
        header('Location: http://localhost/addressbook/index.php?m=Contato&a=listar');
    }
    
    // FIM DA REMOÇAO DE CAMPOS;
    
    // DA VALOR AOS CAMPOS NA TELA DE ADICIONAR CONTATO;
    public function getFromRequest()
    {
        if (isset($_GET['codigo'])) {
            
            $codigo = $_GET['codigo'];
            Db::conectar();
            
            $stmt = Db::conectar()->prepare("SELECT `codigo`, `Saudacao`, `Titulo`, `PreNome` , `NomeDoMeio` , `Sobrenome`, `Empresa`, `Unidade`, `Foto`,   `NomeDeExibicao`, `TituloDoTrabalho`, `Aniversario`, `Tel`, `Celular`, `Fax`, `TelPar`, `CelularPar`, `FaxPar`, `Email`, `EmailPar`, `Site`, `Rua`, `Complemento`, `Estado`, `CEP`, `Cidade`, `Pais`, `Comentario` FROM `addressbook` WHERE `codigo` =$codigo") or die(mysqli_error());
            $result = $stmt->execute();
            $total = $stmt->rowCount();
            $linha = $stmt->fetch(\PDO::FETCH_ASSOC);
            $this->saudacao = $linha['Saudacao'];
            $this->titulo = $linha['Titulo'];
            $this->prenome = $linha['PreNome'];
            $this->nomeDoMeio = $linha['NomeDoMeio'];
            $this->sobrenome = $linha['Sobrenome'];
            $this->empresa = $linha['Empresa'];
            $this->unidade = $linha['Unidade'];
            $this->nomeDeExibicao = $linha['NomeDeExibicao'];
            $this->tituloDoTrabalho = $linha['TituloDoTrabalho'];
            $this->aniversario = $linha['Aniversario'];
            $this->tel = $linha['Tel'];
            $this->celular = $linha['Celular'];
            $this->fax = $linha['Fax'];
            $this->telpar = $linha['TelPar'];
            $this->celularpar = $linha['CelularPar'];
            $this->faxpar = $linha['FaxPar'];
            $this->email = $linha['Email'];
            $this->emailpar = $linha['EmailPar'];
            $this->site = $linha['Site'];
            $this->foto = $linha['Foto'];
            $this->rua = $linha['Rua'];
            $this->complemento = $linha['Complemento'];
            $this->estado = $linha['Estado'];
            $this->cep = $linha['CEP'];
            $this->cidade = $linha['Cidade'];
            $this->pais = $linha['Pais'];
            $this->comentario = $linha['Comentario'];
            $this->codigo = $_GET['codigo'];
            
            $result = $stmt->execute();
        }
    }
    
    // FIM DO REQUEST DOS CAMPOS;
    
    // SEGUNDA PARTE DA VALIDAÇAO;
    public function isValido()
    {
        $atributos = get_object_vars($this);
        unset($atributos['codigo']);
        unset($atributos['linha']);
        unset($atributos['mensagemDeErro']);
        
        foreach ($atributos as $atributo => $value) {
            if ($atributo == 'foto') {
                
                if (! isset($_FILES[$atributo]['name']) || empty($_FILES[$atributo]['name'])) {
                    $this->mensagemDeErro = "Falta preencher o campo  $atributo.<br>";
                    if (isset($_POST['codigo']) && ! empty($_POST['codigo'])) {
                        
                        return true;
                    } else
                        return false;
                }
            } else 
                if (! isset($_POST[$atributo]) || empty($_POST[$atributo])) {
                    $this->mensagemDeErro = "Falta preencher o campo  $atributo.<br>";
                    return false;
                }
        }
        
        return true;
    }
    // FIM DA SEGUNDA PARTE DA VALIDACAO;
}
// FIM
?>