<?php
namespace Addressbook\view;

use Addressbook\Db;
?>
<html>
<head>
<title>Catálogo de Endereços</title>
<meta charset="UTF-8">
<style type="text/css">
@import url("/addressbook/src/Addressbook/cadastrar.css");
</style>
</head>
</head>
<body>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<h2>Catalágo de Endereços</h2>
	<script type="text/javascript">
function editar(codigo){
	window.location ="http://localhost/addressbook/index.php?m=Contato&a=AlteraUser&codigo="+ codigo;
}
function remover(codigo){
	window.location ="http://localhost/addressbook/index.php?m=Contato&a=remover&codigo="+ codigo;
}
function criar(criar){
	window.location ="http://localhost/addressbook/index.php?m=Contato&a=user";
}
</script>


	<style type="text/css">
@import url("cadastrar.css");
</style>

	<table border="5px" cellpadding="5px">

		<tr>


			<th>Nome de Exibição</th>
			<th>Empresa</th>
			<th>Cidade</th>
			<th>Email</th>
			<th>Telefone</th>
			<th>Celular</th>
			<th>Editar</th>
			<th>Excluir</th>

			</div>
		</tr>
		<tr>
	
		
		<?

$stmt = Db::conectar()->prepare("SELECT `NomeDeExibicao`, `Empresa`, `Cidade`, `Email`, `Tel`, `Celular`,  codigo FROM `addressbook` ");
$result = $stmt->execute();
$total = $stmt->rowCount();
while ($linha = $stmt->fetch(\PDO::FETCH_ASSOC)) {
    
    echo "<tr>\n";
    echo "<td>" . $linha['NomeDeExibicao'] . "</td>";
    echo "<td>" . $linha['Empresa'] . "</td>";
    echo "<td>" . $linha['Cidade'] . "</td>";
    echo "<td>" . $linha['Email'] . "</td>";
    echo "<td>" . $linha['Tel'] . "</td>";
    echo "<td>" . $linha['Celular'] . "</td>";
    $codigo = $linha['codigo'];
    echo '<td><botao><button onclick="editar(' . $codigo . ')">Editar</button></botao></td>';
    echo '<td><botao><button onclick="remover(' . $codigo . ')">Remover</button></botao> </td>';
    echo "</tr>\n";
}
?>
  </tr>
		<th>
			<button onclick="criar(criar)">Adicionar Contato</button>
		</th>
	</table>



</body>
</html>