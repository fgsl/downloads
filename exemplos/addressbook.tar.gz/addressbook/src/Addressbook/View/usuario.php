
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style type="text/css">
@import url("/addressbook/src/Addressbook/cadastrar.css");
</style>
</head>
<body>
		<?php
use Addressbook\Model\Contato;
$contato = new Contato();
$contato->getFromRequest();
if ($contato->getcodigo() == NULL) {
    echo "<title> Adicionar contato</title>";
} else {
    echo "<title> Alterar contato</title>";
}
// Comentario
?>
		
		
		        <form enctype="multipart/form-data" name="cadastro"
		action="http://localhost/addressbook/index.php?m=Contato&a=gravar"
		method="post">
		<div class="contato">Contato</div>
		<div class="box1"></div>
		<div class="box2">
			<div class="informacao">
				<b>Informação pessoal</b>
				<div class="quadrado"></div>
			</div>
			<div class="saudacao">
				<label><span>Saudação</span></label>
				<div class="saudacao">
					<select id="saudacao" name="saudacao">
						<option value=></option>
						<option value="Sr"
							<?=(($contato->getSaudacao() == 'Sr')?  'selected' : '')?>>Sr</option>
						<option value="Sra"
							<?=(($contato->getSaudacao() == 'Sra')?  'selected' : '')?>>Sra</option>
						<option value="Empresa"
							<?=(($contato->getSaudacao() == 'Empresa')?  'selected' : '')?>>Empresa</option>
					</select>

					<div class="titulo">
						<label><span>Titulo</span></label>
					</div>
					<div class="titulo">
						<input type="text" class="input_text"
							value="<?=$contato->getTitulo(); ?>" name="titulo" id="titulo" />
					</div>
					<div class="prenome">
						<label> <span> Prenome </span></label>
					</div>
					<div class="prenome">
						<input type="text" class="input_text"
							value="<?=$contato->getprenome(); ?>" name="prenome" id="prenome" />
					</div>
					<div class="nomeDoMeio">
						<label> <span> Nome do Meio </span></label>
					</div>
					<div class="nomeDoMeio">
						<input type="text" class="input_text"
							value="<?=$contato->getnomeDoMeio(); ?>" name="nomeDoMeio"
							id="nomeDoMeio" />
					</div>
					<div class="sobrenome">
						<label> <span> Sobrenome </span></label>
					</div>
					<div class="sobrenome">
						<input type="text" class="input_text"
							value="<?=$contato->getSobrenome(); ?>" name="sobrenome"
							id="sobrenome" />
					</div>
					<div class="empresa">
						<label> <span> Empresa </span></label>
					</div>
					<div class="empresa">
						<input type="text" class="input_text"
							value="<?=$contato->getEmpresa(); ?>" name="empresa" id="empresa" />
					</div>
					<div class="unidade">
						<label> <span> Unidade </span></label>
					</div>
					<div class="unidade">
						<input type="text" class="input_text"
							value="<?=$contato->getUnidade(); ?>" name="unidade" id="unidade" />
					</div>
					<div class="nomeDeExibicao">
						<label> <span> Nome de Exibição </span></label>
					</div>
					<div class="nomeDeExibicao">
						<input type="text" class="input_text"
							value="<?=$contato->getnomeDeExibicao(); ?>"
							name="nomeDeExibicao" id="nomeDeExibicao" />
					</div>
					<div class="tituloDoTrabalho">
						<label> <span> Titulo Do Trabalho </span></label>
					</div>
					<div class="tituloDoTrabalho">
						<input type="text" class="input_text"
							value="<?=$contato->gettituloDoTrabalho(); ?>"
							name="tituloDoTrabalho" id="tituloDoTrabalho" />
					</div>


					<div class="aniversario">
						<label> <span> Aniversário </span></label>
					</div>
					<div class="aniversario">
						<input type="date" class="input_text"
							value="<?=$contato->getAniversario(); ?>" name="aniversario"
							id="aniversario" />
					</div>
					<div class="img">
						<label> <span> Foto </span></label>
					</div>
					<div class="img">

						<img src="<?=$contato->getFoto(); ?>" height="40" width="40" /><input
							type="file" name="foto" value="<?=$contato->getFoto(); ?>" />

						<div></div>

						<div class="comentario">
							<label><span>Comentarios</span></label>
						</div>
						<div class="comentario">
							<textarea id="comentario" name="comentario" rows="46"
								value="<?=$contato->comentario;?>"><?=$contato->getComentario();?>
								</textarea>


						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="boxcontato">
			<div class="infocontato">
				<legend>
					<b>Informação de contato</b>
				</legend>
			</div>
			<div class="tel">
				<img
					src="https://expressobr.serpro.gov.br/images/oxygen/16x16/apps/kcall.png">
				<label><span>Telefone</span></label>
			</div>
			<div class="tel">
				<input type="text" class="input_text"
					value="<?=$contato->getTel(); ?>" name="tel" id="tel" />
			</div>
			<div class="celular">
				<img
					src="https://expressobr.serpro.gov.br/images/oxygen/16x16/devices/phone.png">
				<label><span>Celular</span></label>
			</div>
			<div class="celular">
				<input type="text" class="input_text"
					value="<?=$contato->getCelular(); ?>" name="celular" id="celular" />
			</div>
			<div class="fax">
				<img
					src="https://expressobr.serpro.gov.br/images/oxygen/16x16/devices/printer.png">
				<label><span>Fax</span></label>
			</div>
			<div class="fax">
				<input type="text" class="input_text"
					value="<?=$contato->getFax(); ?>" name="fax" id="fax" />
			</div>
			<div class="telpar">
				<img
					src="https://expressobr.serpro.gov.br/images/oxygen/16x16/apps/kcall.png">
				<label><span>Telefone <i>(particular)</i></span></label>
			</div>
			<div class="telpar">
				<input type="text" class="input_text"
					value="<?=$contato->getTelpar(); ?>" name="telpar" id="telpar" />
			</div>
			<div class="celularpar">
				<img
					src="https://expressobr.serpro.gov.br/images/oxygen/16x16/devices/phone.png">
				<label><span>Celular <i>(particular)</i></span></label>
			</div>
			<div class="celularpar">
				<input type="text" class="input_text"
					value="<?=$contato->getcelularpar();?>" name="celularpar"
					id="celularpar" />
			</div>
			<div class="faxpar">
				<img
					src="https://expressobr.serpro.gov.br/images/oxygen/16x16/devices/printer.png">
				<label><span>Fax <i>(particular)</i></span></label>
			</div>
			<div class="faxpar">
				<input type="text" class="input_text"
					value="<?=$contato->getfaxpar(); ?>" name="faxpar" id="faxpar" />
			</div>
			<div class="email">
				<img
					src="https://expressobr.serpro.gov.br/images/oxygen/16x16/actions/kontact-mail.png">
				<label><span>E-mail</span></label>
			</div>
			<div class="email">
				<input type="text" class="input_text"
					value="<?=$contato->getemail(); ?>" name="email" id="email" />
			</div>
			<div class="emailpar">
				<img
					src="https://expressobr.serpro.gov.br/images/oxygen/16x16/actions/kontact-mail.png">
				<label><span>E-mail <i>(particular)</i></span></label>
			</div>
			<div class="emailpar">
				<input type="text" class="input_text"
					value="<?=$contato->getemailpar(); ?>" name="emailpar"
					id="emailpar" />
			</div>
			<div class="site">
				<img
					src="https://expressobr.serpro.gov.br/images/oxygen/16x16/actions/network.png">
				<label><span>Web</span></label>
			</div>
			<div class="site">
				<input type="text" class="input_text"
					value="<?=$contato->getsite(); ?>" name="site" id="site" />
			</div>
		</div>
		<div class="boxenderecos"></div>
		<div class="enderecos">
			<legend>
				<legend>
					<b>Endereço da empresa</b>
				</legend>
			</legend>
		</div>
		<div class="rua">
			<label><span>Rua</span></label>
		</div>
		<div class="rua">
			<input type="text" class="input_text" value="<?=$contato->getrua()?>"
				name="rua" id="rua" />
		</div>
		<div class="complemento">
			<label><span>Complemento</span></label>
		</div>
		<div class="complemento">
			<input type="text" class="input_text"
				value="<?=$contato->getcomplemento(); ?>" name="complemento"
				id="complemento" />
		</div>
		<div class="estado">
			<label><span>Estado</span></label>
		</div>
		<div class="estado">
			<input type="text" class="input_text"
				value="<?=$contato->getestado(); ?>" name="estado" id="estado" />
		</div>
		<div class="cep">
			<label><span>Código Postal</span></label>
		</div>
		<div class="cep">
			<input type="text" class="input_text"
				value="<?=$contato->getcep(); ?>" name="cep" id="cep" />
		</div>
		<div class="cidade">
			<label><span>Cidade</span></label>
		</div>
		<div class="cidade">
			<input type="text" class="input_text"
				value="<?=$contato->getcidade(); ?>" name="cidade" id="cidade" />
		</div>
		<div class="pais">
			<label><span>País</span></label>
		</div>
		<div class="pais">
			<input type="text" class="input_text"
				value="<?=$contato->getPais(); ?>" name="pais" id="pais" />
		</div>
		<div class="home">

			<input type="submit" name="validar" value="Enviar dados" /> <input
				type="hidden" name="codigo" value="<?=$contato->codigo ;?>" /> <input
				type="reset" name="cancel" value="Resetar campos" /> <input
				type="submit" name="inicio" value="Inicio" />

		</div>

	</form>
</body>
</html>

