<?php
namespace Addressbook\Controller;

class Contato
{

    public static function despachar()
    {
        $model = 'Addressbook\Model\\' . (isset($_GET['m']) ? $_GET['m'] : 'Contato');
        $action = isset($_GET['a']) ? $_GET['a'] : 'listar';
        
        $instancia = new $model();
        return $instancia->$action();
    }
}
?>