<?php
namespace Addressbook;

class Db
{

    public static function conectar()
    {
        
        // CRIAR TABELA
        include 'config/config.php';
        
        $conecta = new \PDO("mysql:host=" . $loginDb['host'] . ";dbname=" . $loginDb['banco'], $loginDb["user"], $loginDb["password"]);
        
        $query = "CREATE TABLE IF NOT EXISTS `addressbook` (
		    `codigo` int(11) NOT NULL AUTO_INCREMENT,
		    `Saudacao` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
		    `Titulo` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `PreNome` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `NomeDoMeio` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `Sobrenome` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
		    `Empresa` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `Unidade` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `NomeDeExibicao` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `TituloDoTrabalho` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `Aniversario` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `Tel` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `Celular` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
		    `Fax` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
		    `TelPar` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
		    `CelularPar` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `FaxPar` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `Email` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `EmailPar` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `Site` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `Rua` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `Complemento` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `Estado` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `CEP` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `Cidade` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `Pais` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
		    `Comentario` longtext COLLATE utf8_unicode_ci NOT NULL,
		    `Foto` blob NOT NULL COMMENT '//Fotos',
		    PRIMARY KEY (`codigo`),
		    UNIQUE KEY `codigo` (`codigo`)
		    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;";
        $stmt = $conecta->exec($query);
        
        return $conecta;
    }
}

?>