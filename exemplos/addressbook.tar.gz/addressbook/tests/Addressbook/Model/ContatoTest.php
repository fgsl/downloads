<?php
namespace Addressbook\Model;

use Addressbook\Db;

class ContatoTest extends \PHPUnit_Framework_TestCase
{

    public function testGravar()
    {
        $amc = new \Addressbook\Model\Contato();
        $pdo = Db::conectar();
        $_POST['validar'] = 'validar';
        $_POST['saudacao'] = "Sr";
        $_POST['titulo'] = "testTitulo";
        $_POST['prenome'] = "testPreNome";
        $_POST['nomeDoMeio'] = "testNomeDoMeio";
        $_POST['sobrenome'] = "testSobrenome";
        $_POST['empresa'] = "testEmpresa";
        $_POST['unidade'] = "testUnidade";
        $_POST['nomeDeExibicao'] = "testNomeDeExibicao";
        $_POST['tituloDoTrabalho'] = "testTituloDoTrabalho";
        $_POST['aniversario'] = "testAniversario";
        $_FILES['foto'] = "torreP.png";
        $_POST['tel'] = "testTelefone";
        $_POST['telpar'] = "testTelefoneParticular";
        $_POST['celular'] = "testCelular";
        $_POST['celularpar'] = "testCelularParticular";
        $_POST['fax'] = "testFax";
        $_POST['faxpar'] = "testFaxParticular";
        $_POST['email'] = "testEmail";
        $_POST['emailpar'] = "testEmailParticular";
        $_POST['site'] = "testSite";
        $_POST['rua'] = "testRua";
        $_POST['complemento'] = "testComplemento";
        $_POST['estado'] = "testEstado";
        $_POST['cep'] = "testCEP";
        $_POST['cidade'] = "testCidade";
        $_POST['pais'] = "testPais";
        $_POST['comentario'] = "testComentario";
        $_POST['codigo'] = "";
        
        $amc->gravar();
        
        $resultSet = $pdo->query('SELECT MAX(codigo) FROM addressbook');
        
        $codigoTest = $resultSet->fetchColumn(0);
        
        $_GET['codigo'] = $codigoTest;
        
        $amc->getFromRequest();
        
        $this->assertEquals('Sr', $amc->getSaudacao());
        $this->assertEquals('testTitulo', $amc->getTitulo());
        $this->assertEquals('testPreNome', $amc->getPrenome());
        $this->assertEquals('testAniversario', $amc->getAniversario());
        $this->assertEquals('testFax', $amc->getFax());
        $this->assertEquals('testComplemento', $amc->getComplemento());
        $this->assertEquals('testRua', $amc->getRua());
        
        $amc->remover();
        
        $resultSet = $pdo->query('SELECT MAX(codigo) FROM addressbook');
        
        $codigo = $resultSet->fetchColumn(0);
        
        $this->assertNotEquals($codigoTest, $codigo);
    }
}

?>