<?php
namespace Addressbook\Controller\ContatoTest;

class ContatoTest extends \PHPUnit_Framework_TestCase
{

    public function testDespachar()
    {
        $controller = new \Addressbook\Controller\Contato();
        $_GET['a'] = 'isValido';
        $resultado = $controller->despachar();
        $this->assertFalse($resultado);
    }
}

