<?php
require 'bootstrap.php';

$a = new Addressbook\Controller\Contato();

var_dump($a);
