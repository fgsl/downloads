<?php
require __DIR__ . '/../Psr4AutoloaderClass.php';
/*
 * Busca no diretorio os arquivos a partir do /var/www/addressbook
 * set_include_path é o que adiciona a string passada como mecanismo de busca
 */

set_include_path(__DIR__ . '/../');
$loader = new Psr4AutoloaderClass();
$loader->register();
$loader->addNamespace('Addressbook', __DIR__ . '/../src/Addressbook');
$loader->addNamespace('Addressbook', __DIR__ . '/Addressbook');
?>
