<?php
$loginDb = array(
    "user" => 'root',
    "password" => 'admin',
    "banco" => 'addressbook',
    "host" => 'localhost'
);

return $loginDb;

?>