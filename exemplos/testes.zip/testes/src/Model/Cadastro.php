<?php
declare(strict_types=1);
namespace Acme\Cadastro\Model;

class Cadastro {

	private $storage;


	public function __construct($storage)
	{
		$this->storage = $storage;
	}

    public function adicionarContato(string $nome,string $telefone)
    {
        return $this->storage->persistirContato($nome,$telefone);
    }
}
