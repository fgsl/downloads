<?php
declare(strict_types=1);

namespace Acme\Cadastro\Storage;

interface StorageInterface {
	public function persistirContato(string $nome,string $telefone);
}
