<?php
declare(strict_types=1);

namespace Acme\Cadastro\Mock;

use Acme\Cadastro\Storage\StorageInterface;

class StorageDouble implements StorageInterface{
	public function persistirContato(string $nome, string $telefone){
		return 1;
	}
}
