<?php
use PHPUnit\Framework\TestCase;
use Acme\Cadastro\Model\Cadastro;
use Acme\Cadastro\Mock\StorageDouble;

class CadastroDeTelefonesTest extends TestCase {

	public function testInserirContato()
	{
                $storage = new StorageDouble();

		$cadastro = new Cadastro($storage);

		$nome = 'Cebolinha';
		$telefone = '4112345789';

		$this->assertEquals(1,$cadastro->adicionarContato($nome,$telefone));
	}

}
