<?php
/**
 * 
 * @param string $nome
 * @return boolean
 */
function gravarAluno($nome)
{
	if (is_null($nome)) return FALSE;
	$handle = fopen(__DIR__ . '/alunos.txt','a');

	if (!$handle) return FALSE;

	$codigo = md5(time());
	$registro = $codigo . ';' . $nome;
	$registro = substr(
			$registro . str_repeat(' ', 300)
			,0,299) . "\n";
	fwrite($handle,$registro,300);
	fclose($handle);
	return TRUE;
}

/**
 * 
 * @param string $codigo
 * @param string $nome
 */
function alterarAluno($codigo,$nome)
{
	$handle = fopen(__DIR__ . '/alunos.txt',
			'r');
	$handle2 = fopen(__DIR__ . '/tmp.txt',
			'a');
	while(!feof($handle)){
		$registro = fread($handle,300);
		$campos = explode(';',$registro);
		if ($campos[0] == $codigo)
		{
			$registro = $codigo .
			';' . $nome;
			$registro = substr(
					$registro .
					str_repeat(' ',299)
					,0,299) . "\n";
		}
		fwrite($handle2,$registro,300);
	}
	fclose($handle);
	fclose($handle2);
	unlink(__DIR__ . '/alunos.txt');
	rename(
	__DIR__ . '/tmp.txt',
	__DIR__ . '/alunos.txt'
			);

}
