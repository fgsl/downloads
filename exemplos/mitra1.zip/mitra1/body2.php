<?php
$handle = fopen(__DIR__ . '/alunos.txt',
'r');
if ($handle) :
	while (!feof($handle)):
		$registro = fread($handle,
		300);
		if (trim($registro)==''){
			continue;
		}
		
		$registro = 
		explode(';',$registro);		
?>
<tr>
<td><?=$registro[0]?></td>
<td><?=$registro[1]?></td>
</tr>
<?php		
	endwhile;
	fclose($handle);
endif;