<?php
$codigo = isset($_GET['codigo']) ?
$_GET['codigo'] : NULL;

if (!is_null($codigo)){
	$handle = fopen(__DIR__ . '/alunos.txt',
'r');
	$handle2 = fopen(__DIR__ . '/tmp.txt',
'a');
	while(!feof($handle)){
		$registro = fread($handle,300);
		$campos = explode(';',$registro);
		if ($campos[0] != $codigo)
		{
			fwrite($handle2,$registro,300);
		}
	}
	fclose($handle);
	fclose($handle2);
	unlink(__DIR__ . '/alunos.txt');
	rename(
	__DIR__ . '/tmp.txt',
	__DIR__ . '/alunos.txt'
	);	
}
header('Location: index.php');
