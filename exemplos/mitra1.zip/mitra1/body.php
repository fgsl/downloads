<?php
$handle = fopen(__DIR__ . '/alunos.txt',
'r');
if ($handle) {
	while (!feof($handle)){
		$registro = fread($handle,
		300);
		if (trim($registro)==''){
			continue;
		}
		
		$registro = 
		explode(';',$registro);		
?>
<tr>
<td><a href="edit.php?codigo=
<?=$registro[0]?>"><?=$registro[0]?></a></td>
<td><?=$registro[1]?></td>
<td><a href="delete.php?codigo=<?=
$registro[0]?>">Excluir</a></td>
</tr>
<?php		
	}
	fclose($handle);
} 