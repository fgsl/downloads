<?php
$codigo = isset($_GET['codigo']) ?
$_GET['codigo'] : NULL;

$nome = '';

if (!is_null($codigo))
{
	$handle = fopen(__DIR__ . '/alunos.txt',
'r');
	while (!feof($handle)){
		$registro = fread($handle,300);
		$registro = explode(';',$registro);
		if ($registro[0] == $codigo){
			$nome = $registro[1];
			break;
		}	
	}
	fclose($handle);
}