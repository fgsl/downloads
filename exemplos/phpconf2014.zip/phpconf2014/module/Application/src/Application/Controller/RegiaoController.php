<?php
namespace Application\Controller;

use Zend\View\Model\ViewModel;

/**
 * RegiaoController
 *
 * @author
 *
 * @version
 *
 */
class RegiaoController extends AbstractController
{
    protected $defaultTable = 'Regiao';
    protected $formName = 'Application\Form\Regiao';
    protected $modelName = 'Application\Model\Regiao';
}