<?php
namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Application\Form\Regiao as RegiaoForm;
use Application\Model\Regiao;

/**
 * AbstractController
 *
 * @author
 *
 * @version
 *
 */
abstract class AbstractController extends AbstractActionController
{
    protected $defaultTable;
    protected $formName;
    protected $modelName;
    protected static $lastControllerName;
    
    public function __construct()
    {
        self::$lastControllerName = self::getControllerName();
    }
    
    public static function lastControllerName()
    {
        return self::$lastControllerName;
    }

    /**
     * The default action - show the home page
     */
    public function indexAction()
    {
        $models = $this->getTable($this->defaultTable)
        ->getModels();       

        return [
            'controllerName'=> self::getControllerName(),
            'models'=>$models,
        ];
    }
    
    public function editAction()
    {
        $key = $this->params('key');
        
        $model = $this->getTable($this->defaultTable)
        ->getModel($key);
        
        $formClass = $this->formName;
        $form = new $formClass();
        $form->setAttribute('action',
            $this->url()->fromRoute(
	           'application/default',
                array(
        	       'controller'=>self::getControllerName(),
                    'action' => 'save'
            )
        ));
        $form = $this->getCustomForm($form);
        $form->bind($model);
        return ['form'=>$form];
    }
    
    public function saveAction()
    {
        $model = call_user_func(array(
        	$this->modelName,
            'getFromRequest'
        ),$this->getRequest());
        
        $this->getTable($this->defaultTable)
        ->save($model);          
        
        return $this->redirect()
        ->toRoute('application/default',
            array(
        	   'controller'=>self::getControllerName()
        ));
    }
    
    protected function getTable($name)
    {
        return $this->getServiceLocator()
        ->get($name . 'Table');
    }
    
    public function deleteAction()
    {
        $key = $this->params('key');
        
        $this->getTable($this->defaultTable)
        ->delete($key);
        
        return $this->redirect()
        ->toRoute('application/default',
            array(
        	   'controller'=>self::$getControllerName()
            )
        );        
        
    }
    
    protected static function getControllerName()
    {
        $tokens = explode('\\',get_called_class());
        $controllerName = end($tokens);
        $controllerName = lcfirst(str_replace('Controller', '', $controllerName));
        return $controllerName;
    }   
    
    protected function getCustomForm($form)
    {
        return $form;
    }
    
}