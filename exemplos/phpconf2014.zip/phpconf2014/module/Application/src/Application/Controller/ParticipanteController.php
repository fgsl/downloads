<?php
namespace Application\Controller;

use Zend\View\Model\ViewModel;

/**
 * ParticipanteController
 *
 * @author
 *
 * @version
 *
 */
class ParticipanteController extends AbstractController 
{
    protected $defaultTable = 'Participante';
    protected $formName = 'Application\Form\Participante';
    protected $modelName = 'Application\Model\Participante';
    
    protected function getCustomForm($form)
    {    
        $options = array();
        $regioes = $this->getTable('Regiao')
        ->getModels();
        foreach($regioes as $regiao){
            $options[$regiao->codigo] =
            $regiao->nome;
        }
        $form->get('codigo_regiao')
        ->setValueOptions($options);
        return $form;
    }
}