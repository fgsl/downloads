<?php
namespace Application\Model;

use Zend\Db\TableGateway\TableGatewayInterface;
use Zend\Text\Table\Table;
use Zend\Db\Sql\Select;

class ParticipanteTable extends AbstractTable
{
    protected $modelName = 'Application\Model\Participante';
    
    public function getModels($where = null)
    {
        $select = new Select();
        $select->from('participantes')
        ->columns(array('codigo','nome'))
        ->join('regioes',
            'participantes.codigo_regiao = regioes.codigo',
            array(
                'codigo_regiao' => 'codigo',
                'regiao' => 'nome'
                )
        );
        
        if (!is_null($where)){
            $select->where(array(
            		'participantes.codigo' =>
            		$where['codigo']
            ));            
        }
    
        return $this->tableGateway
        ->selectWith($select);
    }
}