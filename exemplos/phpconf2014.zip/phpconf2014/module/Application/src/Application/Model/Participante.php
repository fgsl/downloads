<?php
namespace Application\Model;

use Zend\Stdlib\RequestInterface;
class Participante
{
    public $codigo;
    public $nome;
    
    /**
     * 
     * @var Regiao
     */
    public $regiao;    
    
    public static function getFromRequest(
        RequestInterface $request)
    {
        $participante = new Participante();
        $participante->codigo = $request
        ->getPost('codigo');
        $participante->nome = $request
        ->getPost('nome');
        $participante->regiao
        = new Regiao();      
        $participante->regiao
        ->codigo = $request
        ->getPost('codigo_regiao');
        return $participante;  
    }
    
    public function toArray()
    {
        return get_object_vars($this);
    }

    public function getArrayCopy()
    {
        $set = $this->toArray();
        $set['codigo_regiao']
        = $this->regiao->codigo;
        unset($set['regiao']);
        return $set;
    }
    
    public function exchangeArray($array)
    {
        $this->codigo = $array['codigo'];
        $this->nome = $array['nome'];
        $this->regiao = new Regiao();
        $this->regiao->codigo = $array['codigo_regiao'];
        $this->regiao->nome = $array['regiao'];
    }
    
    
    
    
    
    
    
}