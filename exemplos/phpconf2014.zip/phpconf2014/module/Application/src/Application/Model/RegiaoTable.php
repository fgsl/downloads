<?php
namespace Application\Model;

use Zend\Db\TableGateway\TableGatewayInterface;
use Zend\Text\Table\Table;

class RegiaoTable extends AbstractTable
{
    protected $modelName = 'Application\Model\Regiao';
}