<?php
namespace Application\Model;

use Zend\Db\TableGateway\TableGatewayInterface;
use Zend\Text\Table\Table;
use Zend\Db\Sql\Select;

abstract class AbstractTable
{
    /**
     * 
     * @var TableGatewayInterface
     */
    protected $tableGateway;
    protected $modelName;
    
    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }
    
    public function save($model)
    {
        $set = $model->getArrayCopy();
        
        if (empty($model->codigo)){
            $this->tableGateway
            ->insert($set);
        } else {
            $where = array(
            	'codigo' => $model->codigo
            );
            $this->tableGateway->update($set,
            $where);
        }   
    }
    
    public function getModels($where = null)
    {
        return $this->tableGateway
        ->select($where);
    }
    
    public function getModel($key)
    {
        $where = array('codigo'
        => $key);
        $models = $this->getModels(
        	$where
        );
        if ($models->count()==0){
            $modelClass = $this->modelName;
            return new $modelClass();
        } else {
            return $models->current();
        }       
    }
    
    public function delete($key)
    {
        $where = array(
        	'codigo'=> $key
        );
        $this->tableGateway
        ->delete($where);
    }
}