<?php
require('application/path.php');
require('application/Bootstrap.php');
new Bootstrap($_SERVER['PHP_SELF']);
