<?php
/**
* Faz o include do componente Zend_Loader.
* Zend_Loader carrega arquivos, classes e recursos
* dinamicamente em sua aplicação PHP.
*/
include('Zend/Loader.php');
class Bootstrap
{
    public function __construct($self)
    {
    /** Classe de controladores */
    Zend_Loader::loadClass('Zend_Controller_Front'); 
    /** Configura o ponto de retorno da aplicação, por acaso é o index.php */
    $baseUrl = substr($self, 0, strpos($self, '/index.php'));
    /** Cria uma nova instãncia da classe controladora */
    $frontController = Zend_Controller_Front::getInstance();
    /** Configura o endereço do controlador do projeto */
    $frontController->setbaseUrl($baseUrl);
    /** Indica o diretório onde estão os outros controladores da aplicação */
    $frontController->setControllerDirectory('./application/controllers');
    /** O controlador não deve tratar as exceções */
    $frontController->throwExceptions(FALSE);
    /** Chama o controlador de página. */ -
    $frontController->dispatch();
    }
}