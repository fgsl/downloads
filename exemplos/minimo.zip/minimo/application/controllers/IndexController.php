<?php

class IndexController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
		$this->view->mensagem = 'Alô Mundo';
    }
    
    public function aboutAction() {
		$this->view->mensagem = 'Feito por mim!';    	
    }


}

