<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
	public function __construct($application)
	{
		parent::__construct($application);
		$this->openDBConnection();
		$this->createSessionNamespace();
		$this->createInputFilters();
	}
	
	private function openDBConnection()
	{
		$config = new Zend_Config_Ini(APPLICATION_PATH.'/configs/db.ini','database');
		$db = Zend_Db::factory($config->db->adapter,$config->db->config->toArray());
		Zend_Db_Table_Abstract::setDefaultAdapter($db); 	
	}

	private function createSessionNamespace()
	{
		Zend_Registry::set('session',new Zend_Session_Namespace('session'));
	}
	
	private function createInputFilters()
	{
		Zend_Registry::set('get',new Zend_Filter_Input(null,null,$_GET));
		Zend_Registry::set('post',new Zend_Filter_Input(null,null,$_POST));
	}

}

