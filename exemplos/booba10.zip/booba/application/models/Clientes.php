<?php
/**
* Modelo da classe Clientes
*  @filesource
 * @author			Eu
 * @copyright		Copyright 2007 Consultoria Moleza Ltda
 * @package			booba
 * @subpackage		booba.application.models
 * @version			1.0
*/
class Clientes extends Zend_Db_Table
{
	protected $_name = 'clientes';
}
?>
