<?php
/**
* Modelo da classe Itens
*  @filesource
 * @author			Eu
 * @copyright		Copyright 2007 Consultoria Moleza Ltda
 * @package			booba
 * @subpackage		booba.application.models
 * @version			1.0
*/
class Itens extends Zend_Db_Table
{
	protected $_name = 'itenspedidos';
}
?>
