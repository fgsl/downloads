<?php
/**
* Modelo da classe Produtos
*  @filesource
 * @author			Eu
 * @copyright		Copyright 2007 Consultoria Moleza Ltda
 * @package			booba
 * @subpackage		booba.application.models
 * @version			1.0
*/
class Produtos extends Zend_Db_Table
{
	protected $_name = 'produtos';
}
?>
