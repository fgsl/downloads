<?php
/**
* Controlador do cliente
*  @filesource
 * @author			Eu
 * @copyright		Copyright 2007 Consultoria Moleza Ltda
 * @package			booba
 * @subpackage		booba.application.controllers
 * @version			1.0
*/
class ClienteController extends Zend_Controller_Action
{
	/**
	 * Este m�todo ser� executado sempre que a classe for instanciada,
	 * depois do construtor.
	 * Faz o carregamento das classes que ser�o usadas pelo controlador.
	 *
	 * @return void
	 */
	 public function init()
	 {
	 	Zend_Loader::loadClass('Clientes');
	 }

	 /**
	  * M�todo que mostra a p�gina inicial
	  *
	  * @return void
	  */
	  public function indexAction()
	  {
	  	$this->_redirect('index/index');
	  }

	/** Identifica��o do cliente
	 * @return void
	 */
	public function acessarAction()
	{
		$session = Zend_Registry::get('session');
		if (isset($session->cliente))
		{
			$this->_redirect('/carrinho/comprar');
		}

	  	$this->view->assign('mensagem',isset($session->mensagem) ? $session->mensagem : '');

		$this->view->assign('header','pageheader.phtml');
		$this->view->assign('footer','pagefooter.phtml');
	}

	/** Efetua o login do cliente
	 * @return void
	 */
	public function loginAction()
	{
		$post = Zend_Registry::get('post');
		$cpf = $post->cpf;
		$senha = $post->senha;

		$table = new Clientes();

		$where = $table->getAdapter()->quoteInto("cpf = ?", $cpf);
		$usuario = $table->fetchAll($where)->toArray();

		$session = Zend_Registry::get('session');
		if (!empty($usuario) && $usuario[0]['senha'] == $senha)
		{
			$session->cliente = $usuario[0];
			$this->_redirect('/carrinho');
		}
		else
		{
			$session->mensagem = 'Dados inv�lidos';
			$this->_redirect('/cliente/acessar');
		}
		Zend_Registry::set('session',$session);
	}

	/** Cadastramento do cliente
	 * @return void
	 */
	public function cadastrarAction()
	{

		$session = Zend_Registry::get('session');
	  	$this->view->assign('mensagem',isset($session->mensagem) ? $session->mensagem : '');
		$session->mensagem = '';
		Zend_Registry::set('session',$session);

		$this->view->assign('header','pageheader.phtml');
		$this->view->assign('footer','pagefooter.phtml');
	}

	/** Persist�ncia dos dados do cliente
	 * @return void
	 */
	public function gravarClienteAction()
	{
		$post = Zend_Registry::get('post');
		$cpf = $post->cpf;
		$email = $post->email;
		$senha = $post->senha;
		$senha2 = $post->senha2;

		$session = Zend_Registry::get('session');

		if ($senha != $senha2)
		{
			$session->mensagem = 'Dados inv�lidos';
			Zend_Registry::set('session',$session);
			$this->_redirect('/cliente/cadastrar');
			exit;
		}

		$table = new Clientes();
		$where = $table->getAdapter()->quoteInto('cpf = ?', $cpf);
		$cliente = $table->fetchAll($where)->toArray();

		$cpfExiste = !empty($cliente);

		if ($cpfExiste)
		{
			$session->mensagem = 'CPF j� cadastrado';
			Zend_Registry::set('session',$session);
			$this->_redirect('/cliente/cadastrar');
			exit;
		}

		$dados = array('cpf'=>$cpf,'senha'=>$senha);

		$table->insert($dados);

		$this->_redirect('/cliente/acessar');
	}

	/** Encerra a sess�o do cliente, destruindo o carrinho
	 * @return void
	 */
	public function logoutAction()
	{
		/* Mata todas as vari�veis de sess�o */
		Zend_Registry::set('session',array());

		/* Destr�i a sess�o. */
		Zend_Session::destroy();

		$this->_redirect('/');
	}
}