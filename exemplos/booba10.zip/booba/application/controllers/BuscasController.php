<?php
/**
* Controlador de buscas
* Controla as pesquisas e seus resultados
*  @filesource
 * @author			Eu
 * @copyright		Copyright 2007 Consultoria Moleza Ltda
 * @package			booba
 * @subpackage		booba.application.controllers
 * @version			1.0
*/
class BuscasController extends Zend_Controller_Action
{
	/**
	 * Este m�todo ser� executado sempre que a classe for instanciada,
	 * depois do construtor.
	 * Faz o carregamento das classes que ser�o usadas pelo controlador.
	 *
	 * @return void
	 */
	 public function init()
	 {
	 	Zend_Loader::loadClass('Produtos');
	 }

	 /**
	  * M�todo que mostra o resultado da pesquisa
	  *
	  * @return void
	  */
	  public function indexAction()
	  {
	  	$post = Zend_Registry::get('post');
		$chave = (string)$post->nome;

	  	$view = Zend_Registry::get('view');

	  	$table = new Produtos();

		//$where = "position('$chave' in nome)>0";
		$where = "nome LIKE '$chave%'";
	  	$produtos = $table->fetchAll($where);

	  	$view->assign('produtos',$produtos);

		$view->assign('header','pageHeader.phtml');
		$view->assign('footer','pageFooter.phtml');
	  }
}