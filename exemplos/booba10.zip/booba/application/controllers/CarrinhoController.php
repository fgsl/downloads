<?php
/**
* Controlador do carrinho de compras
*  @filesource
 * @author			Eu
 * @copyright		Copyright 2007 Consultoria Moleza
 * @package			booba
 * @subpackage		booba.application.controllers
 * @version			1.0
*/
class CarrinhoController extends Zend_Controller_Action
{
	/**
	 * Este m�todo ser� executado sempre que a classe for instanciada,
	 * depois do construtor.
	 * Faz o carregamento das classes que ser�o usadas pelo controlador.
	 *
	 * @return void
	 */
	public function init()
	{
		Zend_Loader::loadClass('Usuarios');
	 	Zend_Loader::loadClass('Produtos');
	 	Zend_Loader::loadClass('Itens');
	 	Zend_Loader::loadClass('Pedidos');

	}

	/**
	 * @return void
	 */
	public function indexAction()
	{
		$this->_redirect('/carrinho/comprar');
	}

	/** P�gina do carrinho de compras */
	public function comprarAction()
	{
		$mensagem = '';

		$session = Zend_Registry::get('session');
		if (!isset($session->carrinho))
		{
			$session->carrinho = array();
		}

		$carrinho = $session->carrinho;

		$get = Zend_Registry::get('get');
		if (!is_null($get->id))
		{
			$id = (int)$get->id;

			$incluido = FALSE;

			foreach ($carrinho as $produto)
			{
				if (isset($produto['id']))
				{
					if ($produto['id'] == $id )
					{
						$incluido = TRUE;
						$mensagem = 'Produto j� selecionado';
						break;
					}
				}
			}

			if (!$incluido)
			{
				$produtos = new Produtos();
				$item = $produtos->find($id)->toArray();
				$item[0]['quantidade']= 1;
				$carrinho[] = $item[0];
				$session->carrinho = $carrinho;
				Zend_Registry::set('session',$session);
			}

		}

		$this->view->assign('mensagem',$mensagem);
		$this->view->assign('itens',$session->carrinho);

		$this->view->assign('header','pageheader.phtml');
		$this->view->assign('footer','pagefooter.phtml');
	}

	/** Exclus�o de itens do carrinho de compras
	 * @return void
	 */
	public function excluirAction()
	{
		$get = Zend_Registry::get('get');
		$id = (int)$get->id;

		if (is_null($id))
		{
			$this->_redirect('/carrinho');
			exit;
		}

		$session = Zend_Registry::get('session');
		foreach ($session->carrinho as $chave => $produto)
		{
			if ($produto['id'] == $id )
			{
				unset($session->carrinho[$chave]);
				break;
			}
		}
		Zend_Registry::set('session');

		$this->_redirect('/carrinho/comprar');
	}

	/** Edi��o de quantidade de um item do carrinho
	 * @return void
	 */
	public function editarAction()
	{
		$get = Zend_Registry::get('get');
		$id = (int)$get->id;

		if (is_null($id))
		{
			$this->_redirect('/carrinho');
			exit;
		}

		$produtoSelecionado = array();

		$session = Zend_Registry::get('session');
		foreach ($session->carrinho as $chave => $produto)
		{
			if (isset($produto['id']))
			{
				if ($produto['id'] == $id )
				{
					$produtoSelecionado = $produto;
					break;
				}
			}
		}

		$this->view->assign('produtoSelecionado',$produtoSelecionado);

		$this->view->assign('header','pageheader.phtml');
		$this->view->assign('footer','pagefooter.phtml');
	}

	/**
	 * Altera��o de quantidade de um item do carrinho
	 * @return void
	 */
	public function alterarAction()
	{
		$post = Zend_Registry::get('post');
		$id = (int)$post->id;

		if (is_null($id))
		{
			$this->_redirect('/carrinho/');
			exit;
		}

		$quantidade = (int) $post->quantidade;

		$session = Zend_Registry::get('session');
		foreach ($session->carrinho as $chave => $produto)
		{
			if (isset($produto['id']))
			{
				if ($produto['id'] == $id )
				{
					$session->carrinho[$chave]['quantidade'] = $quantidade;
					break;
				}
			}
		}
		Zend_Registry::set('session',$session);

		$this->_redirect('/carrinho/');
	}

	/** Fechamento da compra
	 * @return void
	 */
	public function fecharAction()
	{
		$session = Zend_Registry::get('session');
		if (!isset($session->cliente))
		{
			$this->_redirect('/cliente/acessar');
			exit;
		}

		$this->view->assign('header','pageheader.phtml');
		$this->view->assign('footer','pagefooter.phtml');
	}

	/** Grava o pedido de compra
	 * @return void
	 */
	public function gravarCompraAction()
	{
		$post = Zend_Registry::get('post');

		$formaEscolhida = $post->formaPagamento;

		$formasPagamento = array('boleto'=>'Boleto Banc�rio','cartao'=>'Cart�o de Cr�dito');

		$codigo = mt_rand(10000,99999);

		$pedido = new Pedidos();

		$idPedido = $pedido->insert(array('id'=>$codigo));

		$session = Zend_Registry::get('session');
		$itens = $session->carrinho;

		foreach ($itens as $item)
		{
			$dados = array(	'idpedido'=>$idPedido,
							'idproduto'=>$item['id'],
							'preco'=>$item['preco'],
							'quantidade'=>$item['quantidade']);

			$novoItem = new Itens();
			$novoItem->insert($dados);
		}

		$session->carrinho = array();
		Zend_Registry::set('session',$session);

		$mensagem = "O pedido $codigo pago com {$formasPagamento[$formaEscolhida]} foi finalizado com sucesso";

		$this->view->assign('mensagem',$mensagem);

		$this->view->assign('header','pageheader.phtml');
		$this->view->assign('footer','pagefooter.phtml');
	}

	/* Encerra a sess�o do estoquista */
	public function logoutAction()
	{
		session_destroy();
		$this->redirect('/estoque');
	}
}