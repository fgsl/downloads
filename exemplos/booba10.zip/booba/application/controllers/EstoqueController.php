<?php
/**
* Controlador de estoque
* Controla as opera��es de estoque
*  @filesource
 * @author			Eu
 * @copyright		Copyright 2007 Consultoria Moleza Ltda
 * @package			booba
 * @subpackage		booba.application.controllers
 * @version			1.0
*/
class EstoqueController extends Zend_Controller_Action
{
	/**
	 * Este m�todo ser� executado sempre que a classe for instanciada,
	 * depois do construtor.
	 * Faz o carregamento das classes que ser�o usadas pelo controlador.
	 *
	 * @return void
	 */
	 public function init()
	 {
	 	Zend_Loader::loadClass('Usuarios');
	 	Zend_Loader::loadClass('Produtos');
	 	Zend_Loader::loadClass('Itens');
	 	Zend_Loader::loadClass('Pedidos');
	 }

	/**
	 * @return void
	 */
	public function indexAction()
	{
		$session = Zend_Registry::get('session');
		$this->view->assign('mensagem',isset($session->mensagem) ? $session->mensagem : '');
		$session->mensagem = '';
		Zend_Registry::set('session',$session);

		$this->view->assign('header','estoqueheader.phtml');
		$this->view->assign('footer','pagefooter.phtml');
	}

	/** Efetua o login do estoquista
	 * @return void
	 */
	public function loginAction()
	{
		$post = Zend_Registry::get('post');
		$matricula = (string)$post->matricula;
		$senha = (string)$post->senha;

		$table = new Usuarios();

		if ($matricula)
		{
			$where = $table->getAdapter()->quoteInto('matricula = ?', $matricula);
			$usuario = $table->fetchAll($where)->toArray();
		}
		else
		{ $usuario = NULL; }

		$session = Zend_Registry::get('session');
		if (!empty($usuario) && $usuario[0]['senha'] == $senha)
		{
			$session->estoquista = $usuario[0];
			Zend_Registry::set('session',$session);
			$this->_redirect('/estoque/manterProduto');
		}
		else
		{
			$this->_redirect('/estoque');
		}
	}

	/** Exibe o menu de opera��es de estoque
	 * @return void
	 */
	public function manterProdutoAction()
	{
		$session = Zend_Registry::get('session');
		if (!isset($session->estoquista))
		{ $this->_redirect('/estoque');}
		else
		{
			$estoquista = $session->estoquista;
			$matricula  = $estoquista['matricula'];

			$table = new Produtos();
			$itens = $table->fetchAll();
		}

		$this->view->assign('mensagem',isset($session->mensagem) ? $session->mensagem : '');
		$session->mensagem = '';
		Zend_Registry::set('session',$session);

	  	$this->view->assign('matricula',$matricula);
	  	$this->view->assign('itens',$itens->toArray());
		$this->view->assign('header','estoqueheader.phtml');
		$this->view->assign('footer','pagefooter.phtml');
	}

	/** Encerra a sess�o do estoquista
	 * @return void
	 */
	public function logoutAction()
	{
		/* Mata todas as vari�veis de sess�o */
		Zend_Registry::set('session',array());

		Zend_Session::destroy();
		$this->_redirect('/estoque');
	}

	/** Retorna um produto de acordo com o id passado
	 * @return void
	 */
	private function selecionarProduto()
	{
		$get = Zend_Registry::get('get');

		if (!isset($get->id))
		{
			$this->_redirect('/estoque/manterproduto');
			exit;
		}
		$id = (int)$get->id;

		$table = new Produtos();

		$produtoSelecionado =  $table->find($id)->toArray();

 		return $produtoSelecionado[0];
	}

	/**
	 * @return void
	 */
	public function darEntradaAction()
	{
		$produtoSelecionado = $this->selecionarProduto();

		$this->view->assign('produtoSelecionado',$produtoSelecionado);
		$this->view->assign('header','estoqueheader.phtml');
		$this->view->assign('footer','pagefooter.phtml');
	}

	/**
	 * @return void
	 */
	public function darBaixaAction()
	{
		$produtoSelecionado = $this->selecionarProduto();

		$this->view->assign('produtoSelecionado',$produtoSelecionado);
		$this->view->assign('header','estoqueheader.phtml');
		$this->view->assign('footer','pagefooter.phtml');
	}

	/**
	 * @return void
	 */
	public function editarNomeAction()
	{
		$produtoSelecionado = $this->selecionarProduto();

		$this->view->assign('produtoSelecionado',$produtoSelecionado);
		$this->view->assign('header','estoqueheader.phtml');
		$this->view->assign('footer','pagefooter.phtml');
	}

	/**
	 * @return void
	 */
	public function editarPrecoAction()
	{
		$produtoSelecionado = $this->selecionarProduto();

	  	$this->view = Zend_Registry::get('view');

		$this->view->assign('produtoSelecionado',$produtoSelecionado);
		$this->view->assign('header','estoqueheader.phtml');
		$this->view->assign('footer','pagefooter.phtml');
	}

	/**
	 * @return void
	 */
	public function editarPromocaoAction()
	{
		$produtoSelecionado = $this->selecionarProduto();

	  	$this->view = Zend_Registry::get('view');

		$this->view->assign('produtoSelecionado',$produtoSelecionado);
		$this->view->assign('header','estoqueheader.phtml');
		$this->view->assign('footer','pagefooter.phtml');
	}

	/** Adi��o de quantidade de estoque
	 * @return void
	 */
	public function adicionarAction()
	{
		$post = Zend_Registry::get('post');

		if (isset($post->id))
		{
			$id = (int)$post->id;
			$quantidade = (int)$post->quantidade;

			$table = new Produtos();

			$produto = $table->find($id)->toArray();

			$quantidade = $quantidade + $produto[0]['quantidade'];

			$dados =  array('quantidade' => $quantidade);

			$where = $table->getAdapter()->quoteInto('id = ?', $id);

			$table->update($dados, $where);
		}

		$this->_redirect('/estoque/manterproduto');
	}

	/**  Subtra��o de quantidade de estoque
	 * @return void
	 */
	public function subtrairAction()
	{
		$post = Zend_Registry::get('post');

		if (isset($post->id))
		{
			$id = (int)$post->id;
			$quantidade = (int)$post->quantidade;

			$table = new Produtos();

			$produto = $table->find($id)->toArray();

			$quantidade = $produto[0]['quantidade'] - $quantidade;

			$dados =  array('quantidade' => $quantidade);

			$where = $table->getAdapter()->quoteInto('id = ?', $id);

			$table->update($dados, $where);
		}

		$this->_redirect('/estoque/manterproduto');
	}

	/** Grava��o de um novo nome
	 * @return void
	 */
	public function alterarNomeAction()
	{
		$post = Zend_Registry::get('post');

		if (isset($post->id))
		{
			$id = (int)$post->id;

			$nome = (string)$post->nome;

			$table = new Produtos();

			$dados =  array('nome' => $nome);

			$where = $table->getAdapter()->quoteInto('id = ?', $id);

			$table->update($dados, $where);
		}

		$this->_redirect('/estoque/manterproduto');
	}

	/** Grava��o de um novo preco
	 * @return void
	 */
	public function alterarPrecoAction()
	{
		$post = Zend_Registry::get('post');

		if (isset($post->id))
		{
			$id = (int)$post->id;

			$preco = str_replace('.','',$post->preco);
			$preco = (float)str_replace(',','.',$preco);

			$table = new Produtos();

			$dados =  array('preco' => $preco);

			$where = $table->getAdapter()->quoteInto('id = ?', $id);

			$table->update($dados, $where);
		}

		$this->_redirect('/estoque/manterproduto');
	}

	/** Grava��o do status de promo��o
	 * @return void
	 */
	public function alterarPromocaoAction()
	{
		$post = Zend_Registry::get('post');

		if (isset($post->id))
		{
			$id = (int)$post->id;
			$promocao = (boolean)$post->promocao;

			$table = new Produtos();

			$dados =  array('promocao' => $promocao);

			$where = $table->getAdapter()->quoteInto('id = ?', $id);

			$table->update($dados, $where);
		}

		$this->_redirect('/estoque/manterproduto');
	}

	/** Exclus�o do produto.
	 * N�o exclui se houver pedidos com o produto.
	 * @return void
	 */
	public function excluirAction()
	{
		$get = Zend_Registry::get('get');

		if (isset($get->id))
		{
			$id = (int)$get->id;
			$table = new Itens();

			$where = $table->getAdapter()->quoteInto('idproduto = ?', $id);
			$pedidos = $table->fetchAll($where)->toArray();

			if (empty($pedidos))
			{
				$table = NULL;
				$table = new Produtos();
				$where = $table->getAdapter()->quoteInto('id = ?', $id);
				$table->delete($where);
			}
			else
			{
				$session = Zend_Registry::get('session');
				$session->mensagem = 'produto consta em pedido';
				Zend_Registry::set('session',$session);
			}
		}
		$this->_redirect('/estoque/manterproduto');
	}

	/** Inclus�o de produto
	 * @return void
	 */
	public function incluirAction()
	{
		$this->view->assign('header','estoqueheader.phtml');
		$this->view->assign('footer','pagefooter.phtml');
	}

	/** Grava��o de novo produto
	 * @return void
	 */
	public function incluirProdutoAction()
	{
		$post = Zend_Registry::get('post');

		if (isset($post->nome))
		{
			$nome = (string)$post->nome;

			$table = new Produtos();

			$dados = array(	'nome'=> $nome,
							'quantidade'=> 0,
							'preco' => 0);

			$table->insert($dados);
		}
		else
		{
			$session = Zend_Registry::get('session');
			$session->mensagem = 'nome inv�lido';
			Zend_Registry::set('session',$session);
		}
		$this->_redirect('/estoque/manterProduto');
	}

}