<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Cadastros</title>
</head>
<body>
<h1>Cadastros</h1>
<a href="alunos.php">Alunos</a><br>
<a href="professores.php">Professores</a><br>
<a href="disciplinas.php">Disciplinas</a>
</body>
</html>