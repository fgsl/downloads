<?php
use Entidade\Professor;
use Entidade\Disciplina;

require 'autoload.php';
$class = 'Entidade\\Professor';

$entidade = call_user_func(array($class,'get'),
isset($_GET['chave']) ? $_GET['chave'] : NULL); 

$method = 'get' . ucfirst(
	call_user_func(array($class,'getChave'))
);

$codigoProfessor = $entidade->$method();

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Inclusão de Professor</title>
</head>
<body>
<form method="post" 
action=
"Controlador/ControladorEntidade.php?
metodo=gravar&cadastro=professor">
Nome <input type="text" name="nome" value="<?=$entidade->getNome()?>" autofocus="autofocus">
<input type="hidden" name="chave" value="<?=$codigoProfessor?>">
<input type="submit" value="gravar">
</form>
<?php
if (!is_null($codigoProfessor)):
?>
<form method="post" 
action="Controlador/ControladorEntidade.php?
metodo=gerenciarDisciplinas">
Disciplinas:<br>
<select name="codigo_disciplina">
<?=Disciplina::getSelectOptions()?>
</select>
<br>
Disciplinas deste professor:<br>
<select name="disciplinas_professor">
<?php
Professor::$codigoProfessor = $entidade->$method(); 
echo Professor::getSelectOptions();
?>
</select>
<br>
<input type="hidden" name="codigo_professor" value="<?=Professor::$codigoProfessor?>">
<input type="submit" name="adicionar" value="Adicionar"><br>
<input type="submit" name="remover" value="Remover">
</form>
<?php
endif; 
?>
<a href="professores.php">Voltar</a>
</html>







