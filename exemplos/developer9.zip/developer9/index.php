<?php
require 'autoload.php';
use Util\Tradutor;
Tradutor::$localidade = 'en_US';
$t = new Tradutor();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Cadastros</title>
</head>
<body>
<h1><?=$t('Cadastros')?></h1>
<a href="alunos.php"><?=$t('Alunos')?></a><br>
<a href="professores.php"><?=$t('Professores')?></a><br>
<a href="disciplinas.php"><?=$t('Disciplinas')?></a>
</body>
</html>