<?php 
require 'autoload.php';
use Entidade\Disciplina;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Cadastro de Disciplinas</title>
</head>
<body>
	<h1>Cadastro de Disciplinas</h1>
	<a href="form.php?cadastro=disciplina">Incluir disciplina</a>
	<table>
		<thead>
			<tr>
				<th>Código</th>
				<th>Nome</th>
			</tr>
		</thead>
		<tbody>
<?php
echo Disciplina::listar();
?>
</tbody>
	</table>
	<a href="index.php">Homepage</a>	
</body>
</html>