<?php
class ServiceController extends Zend_Controller_Action
{
	public function init()
	{
		Zend_Loader::loadClass('Translator');
	}

	public function indexAction()
	{
		$server = new Zend_Rest_Server();
		$server->setClass('Translator','translator');
		echo $server->handle();	
		exit;
	}
}