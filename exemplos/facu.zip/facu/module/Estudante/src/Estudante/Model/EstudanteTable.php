<?php
namespace Estudante\Model;

use Zend\Db\TableGateway\TableGateway;

class EstudanteTable
{
	protected $tableGateway;
	
	public function __construct(TableGateway $tableGateway)
	{
		$this->tableGateway = $tableGateway;
	}
	
	public function fetchAll()
	{
		$resultSet = $this->tableGateway->select();
		return $resultSet;
	}
	
	public function getEstudante($matricula)
	{
		$matricula = (int) $matricula;

		$rowSet = $this->tableGateway->select(
				array('matricula'=>$matricula)
				);
		$row = $rowSet->current();
		if (!$row)
		{
			throw new \Exception("Não encontrou matrícula $matricula");
		}		
		
		return $row;
	}
	
	public function saveEstudante(Estudante $estudante)
	{
		$data = array(
				'nome' => $estudante->nome
				);
		
		$matricula = $estudante->matricula;
		
		if (empty($matricula))
		{
			$this->tableGateway->insert($data);
		}
		else
		{
			if ($this->getEstudante($matricula))
			{
				$this->tableGateway->update($data,array(
						'matricula'=>$matricula));
			}
		}
	}
	
	public function deleteEstudante($matricula)
	{
		$this->tableGateway->delete(array(
				'matricula'=>$matricula
				));
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
} 