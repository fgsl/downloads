<?php
class ServiceController extends Zend_Controller_Action
{
	private $_service;

	public function init()
	{
		$client = new Zend_XmlRpc_Client('http://localhost/xmlrpcserversample/service');
		$this->_service = $client->getProxy('translator');
	}

	public function bomdiaAction()
	{
		$locale = $this->getRequest()->getParam('locale');
		echo $this->_service->getGreeting($locale);
		exit;
	}

	public function localesAction()
	{
		$locale = $this->getRequest()->getParam('locale');
		print_r($this->_service->getLocales());
		exit;
	}



}