<?php
namespace Distrito\Model;

class Distrito
{
    public $codigo;
    public $nome;
   
    public function toArray()
    {
        return get_object_vars($this);
    }
  
    // Este é exigido pelo bind() do Zend\Form  
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }    
   
    //Este é exigido pelo ResultSet
    public function exchangeArray($array)
    {
        $this->codigo = $array['codigo'];
        $this->nome = $array['nome'];
    }    
}