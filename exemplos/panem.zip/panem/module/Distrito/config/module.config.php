<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Distrito\Controller\Index' => 'Distrito\Controller\IndexController',
        ),
    ),
    'router' => array(
        'routes' => array(
            'distrito' => array(
                'type'    => 'Segment',
                'options' => array(
                    // Change this to something specific to your module
                    'route'    => '/distrito[/[:action[/:codigo]]]',
                    'defaults' => array(
                        // Change this value to reflect the namespace in which
                        // the controllers for your module are found
                        '__NAMESPACE__' => 'Distrito\Controller',
                        'controller'    => 'Index',
                        'action'        => 'index',
                    ),
                ),
                'may_terminate' => true,                
            ),
        ),
    ),
    'view_manager' => array(
        'template_path_stack' => array(
            'Distrito' => __DIR__ . '/../view',
        ),
    ),
);
