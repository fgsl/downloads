<?php
$conjunto3 = ['hugo', 'alfredo', 'zimbinski', 'donatello'];
$conjunto3[10] = 'pascoal';

print_r($conjunto3);

sort($conjunto3);

echo '<br>';

print_r($conjunto3);

echo '<br>';

$json = json_encode($conjunto3);

print_r($json);

echo '<br>';

$conjunto4 = json_decode($json);

echo '<br>';

print_r($conjunto4);

