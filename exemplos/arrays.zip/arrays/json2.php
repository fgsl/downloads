<?php
$conjunto3 = [
    'leonardo'=>'espadas',
    'michelangelo' => 'nunchakus',
    'donatello'=> 'bastão',
    'rafael'=>'sais'
];

print_r($conjunto3);

echo '<br>';

$json = json_encode($conjunto3);

print_r($json);

echo '<br>';

$conjunto4 = json_decode($json);

echo '<br>';

print_r($conjunto4);

$conjunto5 = (array) $conjunto4;

echo '<br>';

print_r($conjunto5);





