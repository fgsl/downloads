<?php
$conjunto2 = [12, 34, 45, 78, 98, 198];

/* uma possibilidade
for ($i = 0; $i < count($conjunto2); $i++) {
	echo $conjunto2[$i] * 20 . '<br>';
}
*/

function vinteplicar(&$numero, $indice)
{
    $numero = $numero * 20;
}

array_walk($conjunto2, 'vinteplicar');

for ($i = 0; $i < count($conjunto2); $i++) {
    echo $conjunto2[$i] . '<br>';
}
