<?php
$conjunto3 = [9,5,2,7,3,6,4];


print_r($conjunto3);

sort($conjunto3);

echo '<br>';

print_r($conjunto3);