<?php
$conjunto1 = array('huguinho','zezinho','luisinho');

$conjunto1[] = 'biquinho';

$conjunto1[54] = 'pato donald';

$conjunto1[] = 'tio patinhas';

$conjunto1['especial'] = 'professor Pardal';


print_r($conjunto1);


echo 'Número de elementos: ' . count($conjunto1);

echo '<br>';

for($i=0;$i<count($conjunto1);$i++)
{
    echo $conjunto1[$i];	
}

