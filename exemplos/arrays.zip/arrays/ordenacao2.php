<?php
$conjunto3 = ['hugo', 'alfredo', 'zimbinski', 'donatello'];
$conjunto3[10] = 'pascoal';

print_r($conjunto3);

sort($conjunto3);

echo '<br>';

print_r($conjunto3);