// Itens da tabela
//EDITAR/REMOVER
function editar(codigo){
	window.location ="http://localhost/addressbook2/application/user/edit/"+ codigo;
}
function remover(codigo){
	window.location ="http://localhost/addressbook2/application/user/remover/"+ codigo;
}

//Return ID -> CreateElement -> Return Element;
function tableItens() {
var saudacao = table.saudacao.value;
var titulo;
var prenome;
var nomeDoMeio;
var sobrenome;
var unidade;
var nomeDeExibicao;
var tituloDoTrabalho;
var aniversario;
var telefone;
var celular;
var fax;
var telefonepar;
var celularpar;
var faxpar;
var email;
var emailpar;
var web;
var rua;
var rua2;
var estado;
var cep;
var cidade;
var pais; 
if (saudacao == '1') {
	alert('Saudação ativada');
}
}
