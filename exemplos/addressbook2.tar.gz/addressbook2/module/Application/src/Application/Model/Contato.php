<?php
namespace Application\Model;

use Application\DBase;

class Contato
{
    private $mensagemDeErro;

    private $codigo;

    private $saudacao;

    private $titulo;

    private $prenome;

    private $nomeDoMeio;

    private $sobrenome;

    private $empresa;

    private $unidade;

    private $nomeDeExibicao;

    private $tituloDoTrabalho;

    private $aniversario;

    private $telefone;

    private $celular;

    private $fax;

    private $telefonepar;

    private $celularpar;

    private $faxpar;

    private $email;

    private $emailpar;

    private $web;

    private $rua;

    private $complemento;

    private $estado;

    private $cep;

    private $comentario;

    private $cidade;

    private $pais;

    private $foto;

    private $linha;

    public function __call($name, array $args)
    {
        if (substr($name, 0, 3) == 'get') {
            $attribute = lcfirst(substr($name, 3));
            return $this->$attribute;
        }
    }

    /**
     *
     * @return boolean
     */
    private function getContatoFromPost()
    {
        
        //Metodo privado que resgata variaveis ou cria novas se necessario.
        $this->saudacao = $_POST['saudacao'];
        $this->titulo = $_POST['titulo'];
        $this->prenome = $_POST['prenome'];
        $this->nomeDoMeio = $_POST['nomeDoMeio'];
        $this->sobrenome = $_POST['sobrenome'];
        $this->empresa = $_POST['empresa'];
        $this->unidade = $_POST['unidade'];
        $this->nomeDeExibicao = $_POST['nomeDeExibicao'];
        $this->tituloDoTrabalho = $_POST['tituloDoTrabalho'];
        $this->aniversario = $_POST['aniversario'];
        $this->foto = $_FILES['foto'];
        $this->telefone = $_POST['telefone'];
        $this->telefonepar = $_POST['telefonepar'];
        $this->celular = $_POST['celular'];
        $this->celularpar = $_POST['celularpar'];
        $this->fax = $_POST['fax'];
        $this->faxpar = $_POST['faxpar'];
        $this->email = $_POST['email'];
        $this->emailpar = $_POST['emailpar'];
        $this->web = $_POST['web'];
        $this->rua = $_POST['rua'];
        $this->complemento = $_POST['complemento'];
        $this->estado = $_POST['estado'];
        $this->cep = $_POST['cep'];
        $this->cidade = $_POST['cidade'];
        $this->pais = $_POST['pais'];
        $this->comentario = $_POST['comentario'];
        $this->codigo = $_POST['codigo'];
        
        
    }

    public function gravar()
    {
        if (isset($_POST['cancel'])) {
            $this->mensagemDeErro = 'cancel';
            return false;
        }
        if (! isset($_POST['validar']) || ! $this->isValido()) {
            return false;
        } else {
            
            DBase::conectar();
            
            $dir= "";
            $baseFoto = basename($_FILES['foto']['name']);
            $url = $dir . $baseFoto;
            if (empty($this->codigo)) {
                // getContatoFromPost
                Contato::getContatoFromPost();
                $baseFoto = basename($_FILES['foto']['name']);
                
                move_uploaded_file($_FILES['foto']['tmp_name'], '/var/www/addressbook2/public/img/' . basename($baseFoto));
                
                $stmt = DBase::conectar()->query("INSERT INTO addressbook (Saudacao, Titulo, PreNome, NomeDoMeio, Sobrenome, Empresa, Unidade, NomeDeExibicao, TituloDoTrabalho, Aniversario, Foto, Tel, Celular, Fax, TelPar, CelularPar, FaxPar, Email, EmailPar, Site, Rua, Complemento, Estado, CEP, Cidade, Pais, Comentario) VALUES ( '$this->saudacao', '$this->titulo', '$this->prenome', '$this->nomeDoMeio', '$this->sobrenome', '$this->empresa', '$this->unidade', '$this->nomeDeExibicao', '$this->tituloDoTrabalho', '$this->aniversario', '$url', '$this->telefone', '$this->celular', '$this->fax', '$this->telefonepar', '$this->celularpar', '$this->faxpar', '$this->email', '$this->emailpar', '$this->web', '$this->rua', '$this->complemento', '$this->estado', '$this->cep', '$this->cidade', '$this->pais', '$this->comentario')");
                
                if (isset($_POST['codigo']) && ! empty($_POST['codigo'])) {
                    if (empty($baseFoto)) {
                        $stmt = DBase::conectar()->query("UPDATE `addressbook` SET `Saudacao`='$this->saudacao',`Titulo`='$this->titulo',`PreNome`='$this->prenome',`NomeDoMeio`='$this->nomeDoMeio',`Sobrenome`='$this->sobrenome', `Empresa`='$this->empresa', `Unidade`='$this->unidade' , `NomeDeExibicao`='$this->nomeDeExibicao', `TituloDoTrabalho`='$this->tituloDoTrabalho', `Aniversario`='$this->aniversario', `Tel`='$this->telefone', `Celular`='$this->celular', `Fax`='$this->fax', `TelPar`='$this->telefonepar', `CelularPar`='$this->celularpar', `FaxPar`='$this->faxpar', `Email`='$this->email', `EmailPar`='$this->emailpar', `Site`='$this->web', `Rua`='$this->rua', `Complemento`='$this->complemento', `Estado`='$this->estado', `CEP`='$this->cep', `Cidade`='$this->cidade', `Pais`='$this->pais' , `Comentario`='this->$comentario' WHERE  `codigo`= '$this->codigo'");
                    } else {
                        
                        $dados = $stmt = DBase::conectar()->query("SELECT `codigo`, `Foto` FROM `addressbook` WHERE `codigo` =$this->codigo") or die(mysqli_error());
                        
                        $result = $stmt->execute();
                        foreach ($result as $linha) {
                            if (file_exists('/var/www/addressbook2/public/img/' . $linha['Foto'])) {
                                unlink('/var/www/addressbook2/public/img/' . $linha['Foto']);
                            }
                        }
                        move_uploaded_file($_FILES['foto']['tmp_name'], '/var/www/addressbook2/public/img/' . basename($baseFoto));
                        $stmt = DBase::conectar()->query("UPDATE `addressbook` SET `Saudacao`='$this->saudacao',`Titulo`='$this->titulo',`PreNome`='$this->prenome',`NomeDoMeio`='$this->nomeDoMeio',`Sobrenome`='$this->sobrenome', `Empresa`='$this->empresa', `Unidade`='$this->unidade', `Foto`='$url' , `NomeDeExibicao`='$this->nomeDeExibicao', `TituloDoTrabalho`='$this->tituloDoTrabalho', `Aniversario`='$this->aniversario', `Tel`='$this->telefone', `Celular`='$this->celular', `Fax`='$this->fax', `TelPar`='$this->telefonepar', `CelularPar`='$this->celularpar', `FaxPar`='$this->faxpar', `Email`='$this->email', `EmailPar`='$this->emailpar', `Site`='$this->web', `Rua`='$this->rua', `Complemento`='$this->complemento', `Estado`='$this->estado', `CEP`='$this->cep', `Cidade`='$this->cidade', `Pais`='$this->pais' , `Comentario`='$this->comentario' WHERE  `codigo`= '$this->codigo'");
                    }
                }
                
                $pdo = DBase::conectar();
                $pdo->getDriver()
                    ->getConnection()
                    ->beginTransaction();
                try {
                    // Grava
                    $result = $stmt->execute();
                    $pdo->getDriver()
                        ->getConnection()
                        ->commit();
                } catch (Exception $e) {
                    $pdo->getDriver()
                        ->getConnection()
                        ->rollback();
                    $erro = $e->getMessage();
                    echo $erro;
                }
            }
        }
        return true;
    }

    public function remover($codigo)
    {
        $stmt = DBase::conectar()->query("SELECT `codigo`, `Foto` FROM `addressbook` WHERE `codigo` =$codigo") or die(mysqli_error());
        
        $result = $stmt->execute();
        
        foreach ($result as $linha);
        
        if (file_exists('/var/www/addressbook2/public/img/' . $linha['Foto'])) {
            $excluir = unlink('/var/www/addressbook2/public/img/' . $linha['Foto']);
        }
        
        $remover = $stmt = DBase::conectar()->query("DELETE FROM `addressbook` WHERE `codigo` = $codigo");
        $result = $stmt->execute();
        return true;
    }

    public function getFromRequest($codigo)
    {
        DBase::conectar();
        if (! empty($codigo)) {
            $stmt = DBase::conectar()->query("SELECT `codigo`, `Saudacao`, `Titulo`, `PreNome` , `NomeDoMeio` , `Sobrenome`, `Empresa`, `Unidade`, `Foto`,   `NomeDeExibicao`, `TituloDoTrabalho`, `Aniversario`, `Tel`, `Celular`, `Fax`, `TelPar`, `CelularPar`, `FaxPar`, `Email`, `EmailPar`, `Site`, `Rua`, `Complemento`, `Estado`, `CEP`, `Cidade`, `Pais`, `Comentario` FROM `addressbook` WHERE `codigo` =$codigo") or die(mysqli_error());
            $result = $stmt->execute();
            foreach ($result as $linha) {
                $this->saudacao = $linha['Saudacao'];
                $this->titulo = $linha['Titulo'];
                $this->prenome = $linha['PreNome'];
                $this->nomeDoMeio = $linha['NomeDoMeio'];
                $this->sobrenome = $linha['Sobrenome'];
                $this->empresa = $linha['Empresa'];
                $this->unidade = $linha['Unidade'];
                $this->nomeDeExibicao = $linha['NomeDeExibicao'];
                $this->tituloDoTrabalho = $linha['TituloDoTrabalho'];
                $this->aniversario = $linha['Aniversario'];
                $this->telefone = $linha['Tel'];
                $this->celular = $linha['Celular'];
                $this->fax = $linha['Fax'];
                $this->telefonepar = $linha['TelPar'];
                $this->celularpar = $linha['CelularPar'];
                $this->faxpar = $linha['FaxPar'];
                $this->email = $linha['Email'];
                $this->emailpar = $linha['EmailPar'];
                $this->web = $linha['Site'];
                $this->foto = $linha['Foto'];
                $this->rua = $linha['Rua'];
                $this->complemento = $linha['Complemento'];
                $this->estado = $linha['Estado'];
                $this->cep = $linha['CEP'];
                $this->cidade = $linha['Cidade'];
                $this->pais = $linha['Pais'];
                $this->comentario = $linha['Comentario'];
                $this->codigo = $linha['codigo'];
            }
            
            $result = $stmt->execute();
        }
    }

    public function isValido()
    {
        $atributos = get_object_vars($this);
        unset($atributos['codigo']);
        unset($atributos['linha']);
        unset($atributos['mensagemDeErro']);
        unset($atributos['comentario']);
        
        foreach ($atributos as $atributo => $value) {
            if ($atributo == 'foto') {
                
                if (! isset($_FILES[$atributo]['name']) || empty($_FILES[$atributo]['name'])) {
                    $this->mensagemDeErro = "Campo  $atributo inválido.<br>";
                    if (isset($_POST['codigo']) && ! empty($_POST['codigo'])) {
                        
                        return true;
                    } else
                        return false;
                }
            } else 
                if (! isset($_POST[$atributo]) || empty($_POST[$atributo])) {
                    $this->mensagemDeErro = "Campo  $atributo não é válido.<br>";
                    return false;
                }
        }
        
        return true;
    }
}
?>