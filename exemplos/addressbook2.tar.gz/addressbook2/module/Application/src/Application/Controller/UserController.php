<?php
namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Application\Model\Contato;
use Zend\Session\Storage\SessionStorage;

class UserController extends AbstractActionController
{

    public function addAction()
    {
        $codigo = $this->params('codigo');
        $contato = new Contato();
        $contato->getFromRequest($codigo);
        return new ViewModel(array(
            'contato' => $contato
        ));

        
    }

    public function editAction()
    {
        $codigo = $this->params('codigo');
        $contato = new Contato();
        $contato->getFromRequest($codigo);
        
        return new ViewModel(array(
            'contato' => $contato
        ));
    }

    public function usuariosAction()
    {
        return new ViewModel();
    }

    public function saveAction()
    {
        $codigo = $this->getRequest()->getPost('codigo');
        $contato = new Contato();
        $sucesso = $contato->gravar($codigo);
        
        if (!$sucesso){
            $_SESSION['mensagemDeErro'] = $contato->getMensagemDeErro();
            if ($contato->getMensagemDeErro() == 'cancel'){
                return $this->redirect()->toRoute('home');
            }
            return $this->redirect()->toRoute('application/default',array('controller'=>'user','action' => 'user-error'));
        }
        
        return $this->redirect()->toRoute('application/default',array('controller'=>'user','action' => 'usuarios'));
    }

    public function removerAction()
    {
        $codigo = $this->params('codigo');
        $contato = new Contato();
        $contato->remover($codigo);
        return $this->redirect()->toRoute('application/default',array('controller'=>'user','action' => 'usuarios'));
    }

    public function userErrorAction()
    {   return new ViewModel(array(
            'mensagemDeErro' => $_SESSION['mensagemDeErro']
            ));
    }
}