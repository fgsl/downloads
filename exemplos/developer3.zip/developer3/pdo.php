<?php
$pdo = new PDO('mysql:dbname=developer;host=localhost',
    'root', '');
