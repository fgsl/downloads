<?php
class Funcionario extends Fgsl_Db_Table_Abstract
{
	protected $_name = 'funcionarios';
	protected $_dependentTables = array('PapelFuncionario');
	public function __construct()
	{
		parent::__construct();
		$this->_fieldKey = 'matricula';
		$this->_fieldNames = $this->_getCols();
		$this->_fieldLabels = array(
		'matricula' => 'Id',
		'nome' => 'Nome',
		'apelido' => 'Apelido',
		'senha' => 'Senha'
		);
		$this->_lockedFields = array('matricula') ;
		$this->_orderField = 'nome';
		$this->_searchField = 'nome';
		$this->_selectOptions = array();
		$this->_typeElement = array(
		'nome' => Fgsl_Form_Constants::TEXT,
		'apelido' => Fgsl_Form_Constants::TEXT,
		'senha' => Fgsl_Form_Constants::PASSWORD
		);
		$this->_typeValue = array(
		'matricula' => self::INT_TYPE 
		);
	}

	public function setRelationships(array &$records)
	{
		foreach($records as $key => $value)
		{
			unset($records[$key]['Senha']);
		}
	}

	public static function encrypt($text)
	{
		return strrev(md5(sha1($text)));
	}

	public function insert(array $data)
	{
		$data['senha'] = self::encrypt($data['senha']);
		parent::insert($data);
	}
	public function update(array $data,$where)
	{
		if (trim($data['senha']) == '')
		{
			unset($data['senha']);
		}
		else
		{
			$data['senha'] = self::encrypt($data['senha']);
		}
		parent::update($data,$where);
	}
}