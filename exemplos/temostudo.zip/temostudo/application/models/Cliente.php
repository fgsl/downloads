<?php
class Cliente extends Fgsl_Db_Table_Abstract
{
	protected $_name = 'clientes';
	protected $_dependentTables = array('Pedido');

	public function init()
	{
		Zend_Loader::loadClass('Cliente');
	}

	public function __construct()
	{
		parent::__construct();
		$this->_fieldKey = 'cpf';
		$this->_fieldNames = $this->_getCols();
		$this->_fieldLabels = array(
		'cpf' => 'CPF',
		'nome' => 'Nome',
		'senha' => 'Senha',
		'email' => 'e-mail'
		);
		$this->_lockedFields = array('cpf');
		$this->_orderField = 'nome';
		$this->_searchField = 'nome';
		$this->_selectOptions = array();
		$this->_typeElement = array(
		'nome' => Fgsl_Form_Constants::TEXT,
		'senha' => Fgsl_Form_Constants::PASSWORD,
		'email' => Fgsl_Form_Constants::TEXT
		);
		$this->_typeValue = array();
	}

	public static function getUrl()
	{
		$dataAuth = Fgsl_Session_Namespace::get('data_auth');
		$rotulo = '';
		if (isset($dataAuth))
		{
			$rotulo = 'Cliente: '.$dataAuth->nome.' ';
			$acao = 'logout';
			$nomeDoLink = 'Sair';
		}
		else
		{
			$acao = 'pre-login';
			$nomeDoLink = 'Acessar';
		}
		return $rotulo.'<a href="/temostudo/cliente/'.$acao.'">'.$nomeDoLink.'</a>';
	}

	public static function criptografar($senha)
	{
		return md5(sha1(strtolower($senha)));
	}

	private function _getAllFormMessages($messages)
	{
		$completeMessage = '';
		foreach ($messages as $fieldMessage)
		{
			foreach($fieldMessage as $message)
			{
				$completeMessage .= $message;
			}
		}
		return $completeMessage;
	}

	public function preLoginAction()
	{
		$form = $this->_getForm(true);
		$this->_preparaSaidaPadrao($form);
	}
}