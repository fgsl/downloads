<?php
class Produto extends Fgsl_Db_Table_Abstract
{
	protected $_name = 'produtos';
	protected $_dependentTables = array('Estoque','Item','Movimentacao');
	protected $_referenceMap = array(
	'Promocao' => array(
	'columns' => 'id_promocao',
	'refTableClass' => 'Promocao',
	'refColumns' => 'id'
	)
	);
	public function __construct()
	{
		parent::__construct();
		$this->_fieldKey = 'id';
		$this->_fieldNames = $this->_getCols();
		$this->_fieldLabels = array(
		'id' => 'Id',
		'nome' => 'Nome',
		'preco' => 'Preço',
		'id_promocao' => 'Promoção'
		);
		$this->_lockedFields = array('id');
		$this->_orderField = 'nome';
		$this->_searchField = 'nome';
		$this->_selectOptions = array();
		$this->_typeElement = array(
		'nome' => Fgsl_Form_Constants::TEXT,
		'preco' => Fgsl_Form_Constants::TEXT,
		'id_promocao' => Fgsl_Form_Constants::SELECT
		);
		$this->_typeValue = array(
		'id' => self::INT_TYPE,
		'preco' => self::FLOAT_TYPE 
		);
	}

	public function getSelectOptions($fieldName)
	{
		$options = array();
		if ($fieldName == 'id_promocao')
		{
			Zend_Loader::loadClass('Promocao');
			$promocao = new Promocao();
			$records = $promocao->fetchAll()->toArray();
			foreach($records as $record)
			{
				$options[$record['id']] = $record['nome'];
			}
		}
		return $options;
	}

	public function setRelationships(array &$records)
	{
		Zend_Loader::loadClass('Promocao');
		$objPromocao = new Promocao();
		$rowSet = $objPromocao->fetchAll()->toArray();
		$promocoes = array();
		foreach ($rowSet as $row)
		{
			$promocoes[$row['id']]=$row['nome'];
		}
		foreach($records as $id => $element)
		{
			$records[$id]['Promoção'] = $promocoes[$element['Promoção']];
		}
	}

	public function delete(array $where)
	{
		$this->getAdapter()->beginTransaction();
		try
		{
			$row = $this->fetchRow($where);
			$refEstoque = $row->findDependentRowset('Estoque');
			$comEstoque = true;
			$estoque = $refEstoque->current();
			if ($estoque->quantidade == 0 && $estoque->reservada == 0)
			{
				$objEstoque = new Estoque();
				$objEstoque->delete(str_replace('id','id_produto',$where));
				$comEstoque = false;
			}
			$refItem = $row->findDependentRowset('Item');
			$refMovimentacao = $row->findDependentRowset('Movimentacao');
			if ($comEstoque || !is_null($refItem) || !is_null($refMovimentacao) )
			{
				throw new Exception('Produto não pode ser removido!'); 
			}
			parent::delete($where);
			$this->getAdapter()->commit();
		} catch (Exception $e) {
			$this->getAdapter()->rollBack();
			throw $e;
		}
	}
}