<?php
class CarrinhoController extends Zend_Controller_Action
{
	public function init()
	{
		Zend_Loader::loadClass('Pedido');
		Zend_Loader::loadClass('Item');
	}

	public function indexAction()
	{
		$relacaoDeProdutos = $this->_getProdutos();
		$tabelaDeProdutos = $this->_getTabelaDeProdutos($relacaoDeProdutos);
		$this->view->assign('produtos',$tabelaDeProdutos);
		$mensagem = Fgsl_Session_Namespace::get('mensagem');
		$this->view->assign('mensagem',$mensagem);
	}

	private function _getProdutos($nome = null)
	{
		$db = Zend_Registry::get('db');
		$select = $db->select();
		$select->from(array('p'=>'produtos'),
		array('id','nome','preco'))
		->join(array('e'=> 'estoques'),
		'p.id = e.id_produto',
		array('quantidade'));
		if (!is_null($nome))
		{
			$select->where("nome like '%".$nome."%'");
		}
		$stmt = $select->query();
		return $stmt->fetchAll();
	}

	private function _getTabelaDeProdutos(array $produtos)
	{
		$html = '<table border="0" cellpadding="10%">';
		$html.='<tr>';
		$contador = 1;
		foreach ($produtos as $produto) {
			$html.='<td>'.$this->_getFormulario($produto).'</td>';
			if (($contador % 4) == 0)
			{
				$html.='</tr><tr>';
			}
			$contador++;
		}
		if (substr($html,strlen($html)-4) == '<tr>')
		{
			$html = substr($html,0,strlen($html)-4);
		}
		else
		{
			$html = substr($html,0,strlen($html)-3);
		}
		$html .= '</table>';

		return $html;
	}
	
	private function _getTabelaDoCarrinho(array $carrinho)
	{
		$html = '<table border="1" cellpadding="10%">';
		$html.= '<thead>';
		$html.= '<th>Item</th>';
		$html.= '<th>Nome</th>';
		$html.= '<th>Preço</th>';
		$html.= '<th>Quantidade</th>';
		$html.= '<th>Remover</th>';
		$html.= '</thead>';		
		$html.='<tr>';
		$contador = 1;
		foreach ($carrinho as $id => $item) {
			$html.='<tr>';
			$html.="<td>$id</td>";
			$html.="<td>{$item['nome']}</td>";
			$html.="<td>{$item['preco']}</td>";
			$html.='<td><a href="/temostudo/carrinho/editar-quantidade/id/'.$id.'">'.$item['quantidade'].'</a></td>';
			$html.='<td><a href="/temostudo/carrinho/remover/id/'.$id.'">X</a></td>';
			$html.='</tr>';
		}
		$html .= '</table>';

		return $html;
	}
	

	private function _getFormulario(array $produto)
	{
		$form = new Zend_Form();
		$form->setAction("/temostudo/carrinho/incluir/id/{$produto['id']}");
		$form->setMethod('post');

		$element = new Zend_Form_Element_Text('nome');
		$element->setLabel('Nome');
		$element->setValue($produto['nome']);
		$element->setAttrib('readonly','true');
		$element->addDecorator('HtmlTag',array('tag'=>'div'));
		$element->addDecorator('Label',array('tag'=>'b'));
		$form->addElement($element);

		$element = new Zend_Form_Element_Text('preco');
		$element->setLabel('Preço R$');
		$element->setValue(number_format($produto['preco'],2,',','.'));
		$element->setAttrib('readonly','true');
		$element->addDecorator('HtmlTag',array('tag'=>'div'));
		$element->addDecorator('Label',array('tag'=>'b'));
		$form->addElement($element);

		$element = new Zend_Form_Element_Text('quantidade');
		$element->setLabel('Quantidade');
		$element->setValue(1);
		$element->addDecorator('HtmlTag',array('tag'=>'div'));
		$element->addDecorator('Label',array('tag'=>'b')); 
		$form->addElement($element);

		$element = new Zend_Form_Element_Text('estoque');
		$element->setLabel('Disponível em estoque');
		$element->setValue($produto['quantidade']);
		$element->setAttrib('readonly','true');
		$element->addDecorator('HtmlTag',array('tag'=>'div'));
		$element->addDecorator('Label',array('tag'=>'b'));
		$form->addElement($element);

		$element = new Zend_Form_Element_Submit('comprar');
		$element->setLabel('Comprar');
		$form->addElement($element);
		return $form;
	}

	public function incluirAction()
	{
		$item = array();
		$id = (int) $this->_getParam('id');
		$post = Fgsl_Session_Namespace::get('post');

		$item['nome'] = $post->nome;
		$item['preco'] = $post->preco;
		$item['quantidade'] = $post->quantidade;

		$carrinho = (array) Fgsl_Session_Namespace::get('carrinho');
		$carrinho = is_null($carrinho) ? array() : $carrinho;
		$carrinho[$id] = $item;
		Fgsl_Session_Namespace::set('carrinho',$carrinho);
		$this->_forward('ver-conteudo');
	}

	public function verConteudoAction()
	{
		$carrinho = Fgsl_Session_Namespace::get('carrinho');
		$carrinho = is_null($carrinho) ? array() : $carrinho;
		$tabelaDoCarrinho = $this->_getTabelaDoCarrinho($carrinho);
		$this->view->assign('produtos',$tabelaDoCarrinho);
	}

	public function removerAction()
	{
		$id = (int) $this->_getParam('id');
		$carrinho = Fgsl_Session_Namespace::get('carrinho');
		unset($carrinho[$id]);
		Fgsl_Session_Namespace::set('carrinho',$carrinho);
		$this->_forward('ver-conteudo');
	}

	public function editarQuantidadeAction()
	{
		$id = (int) $this->_getParam('id');
		$carrinho = Fgsl_Session_Namespace::get('carrinho');
		$form = new Zend_Form();
		$form->setAction('/temostudo/carrinho/alterar-quantidade');
		$form->setMethod('post');
		$element = new Zend_Form_Element_Text('nome');
		$element->setLabel('Nome');
		$element->setValue($carrinho[$id]['nome']);
		$element->setAttrib('readonly','true');
		$form->addElement($element);
		$element = new Zend_Form_Element_Text('quantidade');
		$element->setLabel('Quantidade');
		$element->setValue($carrinho[$id]['quantidade']);
		$form->addElement($element);
		$element = new Zend_Form_Element_Hidden('id');
		$element->setValue($id);
		$form->addElement($element);
		$element = new Zend_Form_Element_Submit('alterar');
		$element->setLabel('Alterar');
		$form->addElement($element);
		$this->view->assign('form',$form);
	}

	public function alterarQuantidadeAction()
	{
		$post = Fgsl_Session_Namespace::get('post');
		$carrinho = Fgsl_Session_Namespace::get('carrinho');
		$carrinho[(int)$post->id]['quantidade'] = (int) $post->quantidade;
		Fgsl_Session_Namespace::set('carrinho',$carrinho);
		$this->_forward('ver-conteudo');
	}

	public function fecharAction()
	{
		$dataAuth = Fgsl_Session_Namespace::get('data_auth');

		if (empty($dataAuth))
		{
			$this->_forward('pre-login','cliente');
		}
	}

	public function gravarPedidoAction()
	{
		$pedido = new Pedido();
		$item = new Item();
		$dataAuth = Fgsl_Session_Namespace::get('data_auth');
		$dataAtual = getdate();
		$data = "{$dataAtual['mday']}-{$dataAtual['mon']}-{$dataAtual['year']}";
		$dados = array(
		'data' => $data, 
		'status' => 0,
		'cpf' => $dataAuth->cpf
		);

		$pedido->getAdapter()->beginTransaction();
		try {
			$pedido->insert($dados);
			$idPedido = $pedido->getAdapter()->lastSequenceId('pedidos_id_seq');
			$carrinho = Fgsl_Session_Namespace::get('carrinho');
			foreach ($carrinho as $idProduto => $dadosProduto)
			{
				$item->insert(array(
				'id_pedido' => $idPedido,
				'id_produto' => $idProduto,
				'quantidade' => $dadosProduto['quantidade'],
				'preco' => str_replace(',','.',$dadosProduto['preco'])
				));
			}

			$pedido->getAdapter()->commit();
			$mensagem = 'Seu pedido de compra foi gerado com o número '.$idPedido;
			Fgsl_Session_Namespace::set('mensagem',$mensagem);
		} catch (Exception $e) {
			$pedido->getAdapter()->rollBack();
			$mensagem = $e->getMessage();
			Fgsl_Session_Namespace::set('mensagem',$mensagem);
			Fgsl_Session_Namespace::remove('carrinho');
		}
		$this->_forward('index','index');
	}

	public function pesquisarProdutoAction()
	{
		$nome = $this->_getParam('nome');
		$relacaoDeProdutos = $this->_getProdutos($nome);
		$tabelaDeProdutos = $this->_getTabelaDeProdutos($relacaoDeProdutos);
		echo $tabelaDeProdutos;exit;
	}
}
