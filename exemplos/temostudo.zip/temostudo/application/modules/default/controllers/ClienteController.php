<?php
class ClienteController extends Zend_Controller_Action
{
	public function init()
	{
		Zend_Loader::loadClass('Cliente');
	}
	
	public function preCadastrarAction()
	{
		$form = $this->_getForm(false);
		$this->_preparaSaidaPadrao($form);
	}

	private function _preparaSaidaPadrao($form)
	{
		$mensagem = Fgsl_Session_Namespace::get('mensagem');
		Fgsl_Session_Namespace::remove('mensagem');
		$this->view->assign('mensagem',$mensagem);
		$this->view->assign('form',$form);
	}

	public function cadastrarAction()
	{
		$post = Fgsl_Session_Namespace::get('post');
		$cpf = $post->cpf;
		$cliente = new Cliente();
		$registro = $cliente->find($cpf);
		if ($registro->count()>0)
		{
			Fgsl_Session_Namespace::set('mensagem','CPF já cadastrado');
			$this->_forward('pre-cadastrar');
			return;
		}
		$form = $this->_getForm(false);
		if (!$form->isValid($_POST))
		{
			$mensagemDeErro = $this->_getAllFormMessages($form->getMessages());
			Fgsl_Session_Namespace::set('mensagem',$mensagemDeErro);
			$this->_forward('pre-cadastrar');
		}
		else
		{
			try {
				$data = array(
				'cpf' => $_POST['cpf'],
				'nome' => $_POST['nome'],
				'email' => $_POST['email'],
				'senha' => Cliente::criptografar($_POST['senha'])
				);
				$cliente->insert($data);
				$this->_forward('index','index');
			} catch (Exception $e) {
				Fgsl_Session_Namespace::set('mensagem',$e->getMessage());
				$this->_forward('pre-cadastrar');
			}
		}
	}

	public function preLoginAction()
	{
		$form = $this->_getForm(true);
		$this->_preparaSaidaPadrao($form);
	}

	public function loginAction()
	{
		$post = Fgsl_Session_Namespace::get('post');
		$cliente = new Cliente();
		$form = $this->_getForm(true);
		if (!$form->isValid($_POST))
		{
			$mensagemDeErro = $this->_getAllFormMessages($form->getMessages());
			Fgsl_Session_Namespace::set('mensagem',$mensagemDeErro);
			$this->_forward('pre-login');
		}
		else
		{
			$clienteAutenticado = $this->_clienteAutenticado($post->cpf,$post->senha);
			if ($clienteAutenticado)
			{
				$this->_forward('index','index');
			}
			else
			{
				$this->_forward('pre-login','cliente');
			}
		}
	}

	private function _clienteAutenticado($cpf='',$senha='')
	{
		$authAdapter = new Zend_Auth_Adapter_DbTable(Cliente::getDefaultAdapter());
		$authAdapter->setTableName('clientes');
		$authAdapter->setIdentityColumn('cpf');
		$authAdapter->setCredentialColumn('senha');
		$authAdapter->setIdentity($cpf);
		$authAdapter->setCredential(Cliente::criptografar($senha));
		$resultado = $authAdapter->authenticate();

		if ($resultado->isValid())
		{
			$dataAuth = $authAdapter->getResultRowObject(null,'senha');
			Fgsl_Session_Namespace::set('data_auth',$dataAuth);
			return true;
		}
		else
		{
			$mensagens = '';
			foreach ($resultado->getMessages() as $message)
			{
				$mensagens .= $message;
			}
			Fgsl_Session_Namespace::set('mensagem',$mensagens);
			return false;
		}
	}

	private function _getForm($login = true)
	{
		$form = new Zend_Form();
		$form->setAction('/temostudo/cliente/'.($login ? 'login' : 'cadastrar'));
		$form->setMethod('post');
		$element = new Zend_Form_Element_Text('cpf');
		$element->setLabel('CPF');
		$element->addValidator(new Zend_Validate_StringLength(11,11));
		$form->addElement($element);
		if (!$login)
		{
			$element = new Zend_Form_Element_Text('nome');
			$element->setLabel('Nome');
			$form->addElement($element);
			$element = new Zend_Form_Element_Text('email');
			$element->setLabel('e-mail');
			$element->addValidator(new Zend_Validate_EmailAddress());
			$form->addElement($element);
		}
		$element = new Zend_Form_Element_Password('senha');
		$element->setLabel('Senha');
		$form->addElement($element);

		if (!$login)
		{
			$element = new Zend_Form_Element_Password('senha2');
			$element->setLabel('Confirme a senha');
			$form->addElement($element);
		}
		$element = new Zend_Form_Element_Submit($login ? 'login' : 'cadastrar');
		$element->setValue($login ? 'Login' : 'Cadastrar');
		$form->addElement($element);
		return $form;
	}

	public function logoutAction()
	{
		Zend_Session::destroy(true);
		$this->_redirect('index/index'); 
	}
}