<?php
class Admin_PapelFuncionarioController extends Zend_Controller_Action
{
	private $_modelFuncionario;
	private $_modelPapel;
	private $_modelPapelFuncionario;

	public function init()
	{
		Zend_Loader::loadClass('Funcionario');
		Zend_Loader::loadClass('Papel');
		Zend_Loader::loadClass('PapelFuncionario');
		$this->_modelFuncionario = new Funcionario();
		$this->_modelPapel = new Papel();
		$this->_modelPapelFuncionario = new PapelFuncionario();
		$this->_helper->layout->disableLayout();		
	}

	public function indexAction()
	{
		$this->view->assign('mensagem',Fgsl_Session_Namespace::get('mensagem'));
		$this->view->assign('form',$this->_getForm());
		$this->view->assign('table',$this->_getTable());
		Fgsl_Session_Namespace::remove('mensagem');
	}

	private function _getForm()
	{
		$form = new Zend_Form();
		$form->setAction('/temostudo/admin/papel-funcionario/relacionar');
		$form->setMethod('post');

		$records = $this->_modelFuncionario->fetchAll(null,'nome');
		$options = array();
		foreach ($records as $record)
		{
			$options[$record->matricula] = $record->nome;
		}
		$element = new Zend_Form_Element_Select('funcionario');
		$element->setLabel('Funcionário'); 
		$element->setMultiOptions($options);
		$form->addElement($element);
		$records = $this->_modelPapel->fetchAll(null,'nome');
		$options = array();
		foreach ($records as $record)
		{
			$options[$record->id] = $record->nome;
		}
		$element = new Zend_Form_Element_Select('papel');
		$element->setLabel('Papel');
		$element->setMultiOptions($options);
		$form->addElement($element);

		$element = new Zend_Form_Element_Submit('atribuir');
		$form->addElement($element);
		$element = new Zend_Form_Element_Submit('destituir');
		$form->addElement($element);

		return $form;
	}

	public function relacionarAction()
	{
		$post = Fgsl_Session_Namespace::get('post');
		$id_funcionario = (int)$post->funcionario;
		$id_papel = (int)$post->papel;
		$where = "id_funcionario = $id_funcionario and id_papel = $id_papel"; 
		try {
			$row = $this->_modelPapelFuncionario->fetchRow($where);
			$atribuido = $this->_isAtribuido($row);
			if (isset($post->atribuir) && !$atribuido)
			{
				$this->_atribuirPapel($id_funcionario,$id_papel,$where);
			}
			if (isset($post->destituir) && $atribuido)
			{
				$this->_destituirPapel($where);
			}
		} catch (Exception $e) {
			Fgsl_Session_Namespace::set('exception',$e);
			$this->_redirect('error/message');
		}
		$this->_forward('index');
	}

	private function _isAtribuido($row)
	{
		$atribuido = true;
		if (is_null($row))
		{
			$atribuido = false;
		}
		return $atribuido;
	}

	private function _getNome($modelo,$where)
	{
		$row = $this->_modelPapelFuncionario->fetchRow($where);
		$rowParent = $row->findParentRow($modelo);
		return $rowParent->nome;
	}

	private function _atribuirPapel($id_funcionario,$id_papel,$where)
	{
		$data = array(
'id_funcionario'=>$id_funcionario,
'id_papel'=>$id_papel
		);
		$this->_modelPapelFuncionario->insert($data);
		$nomePapel = $this->_getNome('Papel',$where);
		$nomeFuncionario = $this->_getNome('Funcionario',$where);
		Fgsl_Session_Namespace::set('mensagem',"O papel $nomePapel foi atribuído ao funcionÃ¡rio $nomeFuncionario"); 
	}
	private function _destituirPapel($where)
	{
		$nomePapel = $this->_getNome('Papel',$where);
		$nomeFuncionario = $this->_getNome('Funcionario',$where);
		Fgsl_Session_Namespace::set('mensagem',"O funcionário $nomeFuncionario foi destituído do papel $nomePapel");
		$this->_modelPapelFuncionario->delete($where);
	}

	private function _getTable()
	{
		$papeis = array();
		$rowSet = $this->_modelPapelFuncionario->fetchAll();

		foreach ($rowSet as $row)
		{
			$papeis[] = array(
'Funcionario'=>'',
'Papel'=>''
			);
			$rowParent = $row->findParentRow('Funcionario');
			$papeis[count($papeis)-1]['Funcionario'] = $rowParent->nome;
			$rowParent = $row->findParentRow('Papel');
			$papeis[count($papeis)-1]['Papel'] = $rowParent->nome;
		}
		$html = new Fgsl_Html();
		$html->addDecorator(Fgsl_Html_Constants::HTML_DECORATOR_TABLE);
		$table = $html->create($papeis,Fgsl_Html_Constants::HTML_DECORATOR_TABLE);
		return $table;
	}
}