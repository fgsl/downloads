<?php
class Admin_EstoqueCrudController extends Fgsl_Crud_Controller_Abstract
{
	public function init()
	{
		parent::init();
		Zend_Loader::loadClass('Estoque');
		Zend_Loader::loadClass('Produto');
		$this->_useModules = true;
		$this->_uniqueTemplatesForApp = false;
		$this->_privateTemplates = true;
		$this->_model = new Estoque();
		$this->_title = 'Inventário';
		$this->_searchButtonLabel = 'Pesquisar';
		$this->_searchOptions = array('nome'=>'Nome');
		$this->_menuLink = "/temostudo/admin";		
		$this->_config();
		$this->_helper->layout->disableLayout();		
	}

	public function listAction()
	{
		$this->_checkEstoque();
		parent::listAction();
	}
	private function _checkEstoque()
	{
		$sql = 'select produtos.id from produtos';
		$sql.= ' except (select produtos.id';
		$sql.= ' from produtos inner join estoques';
		$sql.= ' on produtos.id = estoques.id_produto)';
		$db = Zend_Registry::get('db');
		$stmt = new Zend_Db_Statement_Pdo($db,$sql);
		$stmt->execute(array());
		while ($record = $stmt->fetch())
		{
			$data = array(
			'id_produto' => $record['id'],
			'quantidade' => 0,
			'maximo' => 0,
			'minimo' => 0,
			'reservada' => 0 
			);
			$this->_model->insert($data);
		}
	}
}