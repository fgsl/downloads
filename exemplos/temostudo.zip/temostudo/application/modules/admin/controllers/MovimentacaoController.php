<?php
class Admin_MovimentacaoController extends Zend_Controller_Action
{
	private $_menuLink;
	public function init()
	{
		Zend_Loader::loadClass('Produto');
		Zend_Loader::loadClass('Estoque');
		Zend_Loader::loadClass('Movimentacao');

		$this->_menuLink = '/temostudo/admin';
		$this->_helper->layout->disableLayout();		
	}
	public function indexAction()
	{
		$mensagem = Fgsl_Session_Namespace::get('mensagem');
		Fgsl_Session_Namespace::set('mensagem',null);
		$this->view->assign('mensagem',$mensagem);
		$this->view->assign('form',$this->_getForm());
		$this->view->assign('menuLink',$this->_menuLink);
	}
	private function _getForm()
	{
		$form = new Zend_Form();
		$form->setAction('/temostudo/admin/movimentacao/executar');
		$form->setMethod('post');
		$element = new Zend_Form_Element_Select('produto');
		$element->setLabel('Produto');
		$options = array();
		$produto = new Produto();
		$rowSet = $produto->fetchAll(null,'nome');
		foreach($rowSet as $row)
		{
			$options[$row->id] = $row->nome;
		}

		$element->setMultiOptions($options);
		$form->addElement($element);
		$element = new Zend_Form_Element_Select('operacao');
		$element->setLabel('Operação');
		$element->setMultiOptions(
		array(
		'E' => 'Entrada',
		'B' => 'Baixa' 
		)
		);
		$form->addElement($element);

		$element = new Zend_Form_Element_Text('quantidade');
		$element->setLabel('Quantidade');
		$form->addElement($element);
		$element = new Zend_Form_Element_Submit('executar');
		$form->addElement($element);
		return $form;
	}

	public function executarAction()
	{
		$post = Fgsl_Session_Namespace::get('post');
		$id = (int) $post->produto;
		$operacao = $post->operacao;
		$quantidade = (int)$post->quantidade;
		$estoque = new Estoque();
		$row = $estoque->fetchRow('id_produto = '.$id);
		$saldoAtual = $row->quantidade;
		// entrada
		if ($operacao == 'E')
		{
			$saldoAtual = $row->quantidade + $quantidade;
		}
		// baixa
		if ($operacao == 'B')
		{
			$saldoAtual = $row->quantidade - $quantidade;
		}
		$dados = array(
		'quantidade' => $saldoAtual
		);
		try {
			$estoque->update($dados,'id_produto ='.$id);
			$movimentacao = new Movimentacao();
			$dataAtual = getdate();
			$data = "{$dataAtual['mday']}-{$dataAtual['mon']}-{$dataAtual['year']}";
			$dados = array(
			'id_produto' => $id,
			'quantidade' => $saldoAtual,
			'data' => $data,
			'tipo' => $operacao
			);
			$movimentacao->insert($dados);
			Fgsl_Session_Namespace::set('mensagem','Operação realizada com sucesso');
			$this->_redirect('admin/movimentacao');
		} catch (Exception $e) {
			Fgsl_Session_Namespace::set('exception',$e);
			$this->_redirect('error/message');
		}
	}
}