<?php
class Admin_PrivilegioCrudController extends Fgsl_Crud_Controller_Abstract
{
	public function init()
	{
		parent::init();
		Zend_Loader::loadClass('Privilegio');

		$this->_useModules = true;
		$this->_uniqueTemplatesForApp = false;
		$this->_model = new Privilegio();
		$this->_title = 'Cadastro de Privilégios';
		$this->_searchButtonLabel = 'Pesquisar';
		$this->_searchOptions = array('nome'=>'Nome');
		$this->_config();
		$this->_menuLink = "/temostudo/admin"; 
		$this->_helper->layout->disableLayout();		
	}
}