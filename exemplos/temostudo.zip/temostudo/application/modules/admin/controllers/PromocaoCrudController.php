<?php
class Admin_PromocaoCrudController extends Fgsl_Crud_Controller_Abstract
{
	public function init()
	{
		parent::init();
		Zend_Loader::loadClass('Promocao');

		$this->_useModules = true;
		$this->_uniqueTemplatesForApp = false;
		$this->_model = new Promocao();
		$this->_title = 'Cadastro de Promoção';
		$this->_searchButtonLabel = 'Pesquisar';
		$this->_searchOptions = array('nome'=>'Nome');
		$this->_menuLink = "/temostudo/admin";		
		$this->_config();
		$this->_helper->layout->disableLayout();		
	}
}