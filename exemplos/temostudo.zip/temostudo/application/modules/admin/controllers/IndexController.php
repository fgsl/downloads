<?php
class Admin_IndexController extends Zend_Controller_Action
{
	public function init()
	{
		Zend_Loader::loadClass('Funcionario');
		Zend_Loader::loadClass('AcessoPapel');
		Zend_Loader::loadClass('PapelFuncionario');
		$this->_helper->layout->disableLayout();		
	}

	public function indexAction()
	{
		$dataAuth = Fgsl_Session_Namespace::get('data_auth');
		if (!isset($dataAuth))
		{
			$this->_redirect('/admin/index/pre-login');
		}
	}

	public function preLoginAction()
	{
		$form = new Zend_Form();
		$form->setAction('/temostudo/admin/index/login');
		$form->setMethod('post');
		$element = new Zend_Form_Element_Text('matricula');
		$element->setLabel('Matrícula');
		$form->addElement($element);
		$element = new Zend_Form_Element_Password('senha');
		$element->setLabel('Senha');
		$form->addElement($element);
		$element = new Zend_Form_Element_Submit('login');
		$form->addElement($element);
		$this->view->assign('form',$form);

		$message = Fgsl_Session_Namespace::get('message');
		Fgsl_Session_Namespace::remove('message');
		$this->view->assign('message',$message);
	}

	public function loginAction()
	{
		try
		{
			$post = Fgsl_Session_Namespace::get('post');
			$authAdapter = new Zend_Auth_Adapter_DbTable(Funcionario::getDefaultAdapter());
			$authAdapter->setTableName('funcionarios');
			$authAdapter->setIdentityColumn('matricula');
			$authAdapter->setCredentialColumn('senha');
			$authAdapter->setIdentity($post->matricula);
			$authAdapter->setCredential(Funcionario::encrypt($post->senha));
			$resultado = $authAdapter->authenticate();

			if ($resultado->isValid())
			{
				$dataAuth = $authAdapter->getResultRowObject(null,'senha'); 
				Fgsl_Session_Namespace::set('data_auth',$dataAuth);
				Fgsl_Session_Namespace::set('acl',$this->_getAcl($dataAuth->matricula)); 
			}
			else
			{
				$mensagens = '';
				foreach ($resultado->getMessages() as $mensagem)
				{
					$mensagens .= $mensagem;
				}
				Fgsl_Session_Namespace::set('message',$mensagens);
			}
		}
		catch (Exception $e)
		{
			Fgsl_Session_Namespace::set('message',$e->getMessage());
		}
		$this->_redirect('/admin');
	}

	public function logoutAction()
	{
		Fgsl_Session_Namespace::remove('data_auth');
		$this->_redirect('/admin');
	}

	private function _getAcl($matricula)
	{
		$acl = new Zend_Acl();
		$papelFuncionario = new PapelFuncionario();
		$rowSet = $papelFuncionario->fetchAll('id_funcionario = '.$matricula);
		$acessoPapel = new AcessoPapel();
		foreach($rowSet as $row)
		{
			$rowPapel = $row->findParentRow('Papel');
			$acl->addRole($rowPapel->nome);
			$subRowSetAcesso = $acessoPapel->fetchAll('id_papel = '.$row->id_papel);
			foreach ($subRowSetAcesso as $subRow)
			{
				$recursoPrivilegio = $subRow->findParentRow('Acesso');
				$acl->addResource($recursoPrivilegio->recurso);
				$acl->allow($row->id_papel,$recursoPrivilegio->recurso,$recursoPrivilegio->privilegio);
			}
		}
		return $acl;
	}
}