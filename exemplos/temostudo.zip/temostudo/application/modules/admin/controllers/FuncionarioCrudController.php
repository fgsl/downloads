<?php
class Admin_FuncionarioCrudController extends Fgsl_Crud_Controller_Abstract
{
	public function init()
	{
		parent::init();
		Zend_Loader::loadClass('Funcionario');

		$this->_useModules = true;
		$this->_uniqueTemplatesForApp = false;
		$this->_model = new Funcionario();
		$this->_title = 'Cadastro de Funcionários';
		$this->_searchButtonLabel = 'Pesquisar';
		$this->_searchOptions = array('nome'=>'Nome');
		$this->_config();
		$this->_menuLink = "/temostudo/admin";
		$this->_helper->layout->disableLayout();		 
	}
}