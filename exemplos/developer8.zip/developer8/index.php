<?php
require 'autoload.php';
use Util\Tradutor;
Tradutor::$localidade = 'en_US';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Cadastros</title>
</head>
<body>
<h1><?=Tradutor::traduzir('Cadastros')?></h1>
<a href="alunos.php"><?=Tradutor::traduzir('Alunos')?></a><br>
<a href="professores.php"><?=Tradutor::traduzir('Professores')?></a><br>
<a href="disciplinas.php"><?=Tradutor::traduzir('Disciplinas')?></a>
</body>
</html>