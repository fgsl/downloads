<?php
namespace Util;

class Tradutor
{
    public static $localidade = 'pt_BR';
    
    public static function traduzir($texto)
    {
        $filename = __DIR__ . DIRECTORY_SEPARATOR .
        'traducao.' . self::$localidade;
        $traducoes = parse_ini_file($filename);
        
        $traducao = isset($traducoes[$texto]) ?
        $traducoes[$texto] : $texto;
        
        return $traducao;
    }
}

?>