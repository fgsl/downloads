<?php
/**
 * Monta um registro para ser gravado
 *
 * @param string $model
 * @param array $data
 * @return boolean
 */
function gravarModel($model, array $data)
{
	$registro = $model($data);
	return gravarRegistro($model, $registro);
}

function aluno(array $data)
{
	$data['codigo'] = md5(time());
	return $data;
}

function disciplina(array $data)
{
	$data['codigo'] = strrev(time());
	return $data;
}

function professor(array $data)
{
	$data['codigo'] = sha1(time());
	return $data;
}





/**
 *
 * @param string $codigo
 * @param string $nome
 */
function alterarModel($model, array $data)
{
	alterarRegistro($model,$data);
}

/**
 *
 * @param string $model
 * @param array $data
 */
function removerModel($model, array $data)
{
	alterarRegistro($model, $data, TRUE);
}

function getTag($model)
{
	if ($model == 'professor')
	{
		return 'professore';
	}
	return $model;
}






