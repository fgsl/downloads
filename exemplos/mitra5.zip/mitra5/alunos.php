<?php
$model='aluno';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Cadastro de Alunos</title>
</head>
<body>
<h1>Cadastro de Alunos</h1>
<a href="edit.php?model=aluno">Incluir aluno</a>
<table>
<thead>
<tr>
<th>Código</th>
<th>Nome</th>
<th>&nbsp;</th>
</tr>
</thead>
<tbody>
<?php require "body.php"?>
</tbody>
</table>
</body>
</html>