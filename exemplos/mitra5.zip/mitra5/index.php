<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Mitra</title>
</head>
<body>
<h1>Cadastros</h1>
<ul>
<li><a href="alunos.php">Cadastro de Alunos</a></li>
<li><a href="disciplinas.php">Cadastro de Disciplinas</a></li>
<li><a href="professores.php">Cadastro de Professores</a></li>
</ul>
</body>
</html>