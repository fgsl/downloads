<?php
require 'record.php';
$title = (empty($codigo) ? 
'Inclusão' :
'Alteração') . " de $model"; 
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title><?=$title?></title>
</head>
<body>
<h1><?=$title?></h1>
<form action="save.php?model=<?=$model?>" method="post">
Nome: 
<input type="text" name="nome"
value="<?=$nome?>" autofocus="autofocus">
<input type="hidden" name="codigo"
value="<?=$codigo?>">
<input type="submit" value="gravar">
</form>
</body>
</html>