<?php
require 'functions.php';

$codigo = isset($_GET['codigo']) ?
$_GET['codigo'] : NULL;

$model = isset($_GET['model']) ?
$_GET['model'] : NULL;

$nome = '';

if (is_null($codigo)) return;

$tag = getTag($model);

$fileName = $tag .'s.xml';

if (!file_exists(__DIR__ . '/' . $fileName))
	return;

$xml = new SimpleXMLElement(
		__DIR__ . '/' . $fileName,
		NULL,
		TRUE
		);

$tagModels = $xml->xpath(
	"/{$tag}s/$model"
);

foreach($tagModels as $tagModel)
{
	if ($tagModel->codigo == $codigo)
	{
		$nome = $tagModel->nome;
		break;
	}			
}