<?php
/**
 *
 * @param string $model
 * @param array $registro
 * @return boolean
 */
function gravarRegistro($model, array $registro)
{
	$tag = getTag($model);
	
	$fileName = $tag .'s.xml';
	
	$xml = '';
	$path = __DIR__ . '/' . $fileName;
	if (!file_exists($path)){
		$xml = <<<XML
<?xml version="1.0"?>
<{$tag}s>

XML;
		
	}
	$handle = fopen($path,'a');
	if (!$handle) return FALSE;
	fclose($handle);

	$content = file_get_contents($path);
	$content = str_replace("</{$tag}s>",
	'',$content);
	
	$xml .= $content;
	
	$xml .= <<<XML
<{$model}>
<codigo>{$registro['codigo']}</codigo>
<nome>{$registro['nome']}</nome>
</{$model}>
</{$tag}s>			 
XML;
	
	file_put_contents($path,$xml);	
	
	return TRUE;
}

/**
 *
 * @param string $model
 * @param array $data
 * @param boolean $excluir
 */
function alterarRegistro($model, $data, $excluir = FALSE)
{
	$tag = getTag($model);
	
	$fileName = $tag .'s.xml';	
	
	$xml = new SimpleXMLElement(
			__DIR__ . '/' . $fileName,
			NULL,
			TRUE);
	
	$xmlContent = <<<XML
<?xml version="1.0"?>
<{$tag}s>
</{$tag}s>		 		
XML;
		
	$newXml = new SimpleXMLElement(
				$xmlContent);		
		 
	foreach($xml->children() as $child)//aluno
	{
		$registro = $child->children();
		if (!($excluir && $registro->codigo == $data['codigo']))
		{
			$novoRegistro = $newXml->addChild($model);				
			$novoRegistro->addChild('codigo',
					$registro->codigo
			);
			$novoRegistro->addChild('nome',
					$registro->codigo
					== $data['codigo'] ?
					$data['nome'] :
					$registro->nome
			);
		}	
	}

	$content = $newXml->asXML();
		
	file_put_contents(__DIR__ . 
	'/' . $fileName,$content);
}