<?php
require 'functions.php';
$tag = getTag($model);
$fileName = $tag . 's.xml';

if (!file_exists(__DIR__ . '/' . $fileName))
	return;

$xml = new SimpleXMLElement(__DIR__ . '/' . $fileName,NULL,TRUE);
$children = $xml->children();
foreach($children as $child)// model
{
		$registro = $child->children();
		$codigo = $registro->codigo;
		$nome = $registro->nome;
		$urlAlterar = "edit.php?codigo=$codigo&model=$model";
		$urlExcluir = "delete.php?codigo=$codigo&model=$model";

		$template = <<<TEMPLATE
<tr>
	<td><a href="$urlAlterar">$codigo</a></td>
	<td>$nome</td>
	<td><a href="$urlExcluir">Excluir</a></td>
</tr>
TEMPLATE;
		echo $template;	
}