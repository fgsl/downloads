<?php
require 'functions.php';

$codigo = isset($_POST['codigo']) ?
$_POST['codigo'] : NULL;
$nome = isset($_POST['nome']) ? 
$_POST['nome'] : NULL ;
$model = isset($_GET['model']) ?
$_GET['model'] : NULL ;

if (empty($codigo)){
	gravarModel($model,
		['nome' => $nome]);
} else {
	alterarModel($model,
		['codigo'=>$codigo,
		'nome' => $nome]);
}
$tag = getTag($model);
header("Location: {$tag}s.php");




