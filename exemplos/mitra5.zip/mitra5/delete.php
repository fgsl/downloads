<?php
require 'functions.php';

$codigo = isset($_GET['codigo']) ?
$_GET['codigo'] : NULL;
$model = isset($_GET['model']) ?
$_GET['model'] : NULL;


if (!is_null($codigo)){
	removerModel($model,['codigo'=>$codigo]);
}
header("Location: {$model}s.php");
