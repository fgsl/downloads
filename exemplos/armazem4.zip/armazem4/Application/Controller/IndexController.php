<?php
namespace Application\Controller;

use Novatec\Framework\Controller\PageController;

class IndexController extends PageController
{
    public function indexAction()
    {
    }
}