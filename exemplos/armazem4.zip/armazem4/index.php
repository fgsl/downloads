<?php
use Novatec\Framework2\Db\Adapter;
use Novatec\Framework2\Orm\Mapper;
use Novatec\Framework2\Controller\FrontController;

require realpath(__DIR__ . '/../library/vendor'). '/autoload.php';

spl_autoload_register(function($className){
    include __DIR__ . DIRECTORY_SEPARATOR . str_replace('\\', DIRECTORY_SEPARATOR, $className) . '.php';
});

$config = parse_ini_file(__DIR__ . DIRECTORY_SEPARATOR . 'config.ini');
$adapter = new Adapter($config);
Mapper::$defaultAdapter = $adapter->factory();

$frontController = FrontController::getInstance();
$frontController->setPath(__DIR__ . DIRECTORY_SEPARATOR . 'Application' .
		DIRECTORY_SEPARATOR . 'View');
$frontController->dispatch();