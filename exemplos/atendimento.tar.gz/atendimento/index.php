<?php
use Example\Psr4AutoloaderClass;
use Atendimento\Controlador\Frontal;
use Atendimento\Modelo\ModeloAbstrato;

require 'Psr4AutoloaderClass.php';

$psr4 = new Psr4AutoloaderClass();
$psr4->addNamespace('Atendimento', __DIR__ . '/src/Atendimento');
$psr4->register();

ModeloAbstrato::$config = 
require __DIR__ . '/config/dbconfig.php';

Frontal::obterInstancia()->despachar();