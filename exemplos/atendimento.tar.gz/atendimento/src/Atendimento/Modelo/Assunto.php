<?php
namespace Atendimento\Modelo;


use Atendimento\Orm\DataTableGateway;
class Assunto extends ModeloAbstrato
{
    public static $table = 'assuntos';
    
    /**
     * 
     * @var integer
     */
    public $codigo;
    /**
     * 
     * @var string
     */
    public $assunto;
    
    
    public function __construct(array $dados)
    {
        $this->codigo = (isset($dados['codigo']) ?
            (int) $dados['codigo'] : null);
        $this->assunto = (isset($dados['assunto']) ?
            $dados['assunto'] : null);
    }
    
    public function toArray()
    {        
        return [
            'assunto' => $this->assunto  
        ];
    }
    
    public static function recuperarAssuntos()
    {
        $dtg = new DataTableGateway(self::$config);
        return $dtg->select(self::$table);        
    }
    
    
    
}
