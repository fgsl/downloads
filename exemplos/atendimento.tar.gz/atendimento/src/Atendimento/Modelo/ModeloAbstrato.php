<?php
namespace Atendimento\Modelo;

use Atendimento\Orm\DataTableGateway;

abstract class ModeloAbstrato
{
    /**
     * @var array
     */
    public static $config = []; 

    public static $table = null;
    
    public function persistir()
    {
        $dtg = new DataTableGateway(self::$config);
        $dtg->insert(static::$table,$this->toArray());
    }

    abstract public function toArray();
}
