<?php
namespace Atendimento\Modelo;

class Demanda
{
    /**
     * 
     * @var integer
     */
    public $codigo;
    /**
     * 
     * @var Solicitante
     */
    public $solicitante;
    
    /**
     * 
     * @var Assunto
     */
    public $assunto;
    
    /**
     * 
     * @var string
     */
    public $detalhes;
    
    
}
