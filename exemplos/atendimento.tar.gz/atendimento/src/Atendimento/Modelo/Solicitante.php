<?php
namespace Atendimento\Modelo;

class Solicitante
{
    public $cpf;
    public $nome;
    public $cep;
    public $municipio;
    public $uf;
    public $email;
    public $ddd;
    public $telefone;
}
