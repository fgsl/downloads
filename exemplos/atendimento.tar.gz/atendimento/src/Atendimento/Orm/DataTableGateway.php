<?php
namespace Atendimento\Orm;

class DataTableGateway
{
    private $connection = null;
    
    public function __construct(array $config)
    {
        $server = $config['server'];
        $username = $config['username'];
        $password = $config['password'];
        $database = $config['database'];
        
        $this->connection = new \mysqli(
            $server,
            $username,
            $password,
            $database
            );
    }
    
    public function insert($table,array $fields)
    {
        $query = 'INSERT INTO ' . $table . 
        '(';
        $columns = '';
        $values = '';
        foreach($fields as $name => $value){
            $columns .= $name . ',';
            $values .= (gettype($value) == 'string' ?
                 "'$value'" : $value) . ',';   
        }
        $columns = substr($columns,0,-1);
        $values = substr($values,0,-1);
        $query .= $columns . ') VALUES (' .
            $values . ')';
        
        $this->connection->query($query);
    }
    
    public function update($table,array $fields,
        $where)
        {
            
        }
        
    public function delete($table, $where)
    {
        
    }

    public function select($table, $where = null)
    {
        $sql = "SELECT * FROM $table";
        if (!is_null($where)){
            $sql .= " WHERE $where";
        }
        
        return $this->connection->query($sql);
    }
    
    
    
        
        
}