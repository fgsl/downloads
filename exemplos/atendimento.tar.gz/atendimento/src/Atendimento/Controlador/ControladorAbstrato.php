<?php
namespace Atendimento\Controlador;

abstract class ControladorAbstrato
{
    protected $acao;
    protected $redirecionar = false;
    
    public function executar($acao)
    {
        @$controlador = 
        lcfirst(end(explode('\\',get_called_class())));
        $this->acao = $acao;
        $this->$acao();
        
        if ($this->redirecionar){
            header('Location: /atendimento/index.php?c=' . $controlador .'&a=' . $this->acao);
            exit;
        }
        
        $path = realpath(__DIR__ . '/../../../view/' . $controlador);
        require $path . "/{$this->acao}.php";
    }    
}