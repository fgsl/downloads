<?php
namespace Atendimento\Controlador;

class Index extends ControladorAbstrato
{
    public function index()
    {
        
    }
}
