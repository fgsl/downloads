<?php
namespace Atendimento\Controlador;

class Frontal
{
    private static $instancia = null;
    
    private function __construct()
    {
        
    }
    
    public static function obterInstancia()
    {
        if (self::$instancia == null){
            self::$instancia = new Frontal();
        }
        return self::$instancia;
    }
    
    
    public function despachar()
    {   
        $controlador = (isset($_GET['c']) ? 
            $_GET['c'] : 'index');
        $acao = (isset($_GET['a']) ? 
            $_GET['a'] : 'index');
        
        $controlador = 'Atendimento\Controlador\\' .
            ucfirst($controlador);
        
        $controlador = new $controlador();
        
        $controlador->executar($acao);
    }
}
