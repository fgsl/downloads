<?php
namespace Atendimento\Controlador;

use Atendimento\Modelo\Assunto as ModeloAssunto;

class Assunto extends ControladorAbstrato
{
    protected $assuntos;
    
    public function index()
    {
        $this->assuntos = ModeloAssunto::recuperarAssuntos();
    }
    
    public function editar()
    {
        
    }
    
    public function gravar()
    {
        error_log(print_r($_POST,true));   
        $assunto = new ModeloAssunto($_POST);
        $assunto->persistir();
        $this->acao = 'index';
        $this->redirecionar = true;
    }
}