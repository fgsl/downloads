<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Sistema de Atendimento</title>
</head>
<body>
<h1>Sistema de Atendimento</h1>
<a href="/atendimento?c=assunto">
Cadastro de Assuntos</a>
</body>
</html>