<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Cadastro de Assuntos</title>
</head>
<body>
	<h1>Cadastro de Assuntos</h1>
	<a href="/atendimento?c=assunto&a=editar">Incluir Assunto</a>
	<table>
		<thead>
			<tr>
				<th>Código</th>
				<th>Assunto</th>
			</tr>
		</thead>
		<tbody>
<?php
foreach($this->assuntos as $assunto){
    echo '<tr>';
    foreach($assunto as $campo){
        echo "<td>$campo</td>";
    }
    echo '</tr>';
} 
?>
		</tbody>
	</table>
</body>
</html>




