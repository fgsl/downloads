<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Edição de Assunto</title>
</head>
<body>
<h1>Edição de Assunto</h1>
<form method="post" action="index.php?c=assunto&a=gravar">
Assunto: <input type="text" name="assunto" autofocus="autofocus">
<input type="hidden" name="codigo">
<input type="submit" value="gravar">
</form>
</body>
</html>