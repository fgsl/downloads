<?php
return [
  'server' => 'localhost',
  'username' => 'root',
  'password' => 'mysql',
  'database' => 'atendimento'       
];