<?php
namespace Tributo\Model;

use Tordo\Db\TableGateway\AbstractTableGateway;
class TributoTable extends AbstractTableGateway
{
   protected $keyName = 'codigo';
   protected $modelName = 'Tributo\Model\Tributo';
}