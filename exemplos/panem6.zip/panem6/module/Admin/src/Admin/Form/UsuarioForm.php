<?php
namespace Admin\Form;

use Zend\Form\Form;
use Zend\Form\Element\Text;
use Zend\Form\Element\Hidden;
use Zend\Form\Element\Submit;
use Zend\Form\Element\Password;

class UsuarioForm extends Form
{
    public function __construct($name = 'usuario', array $options = array())
    {
        parent::__construct($name,$options);
        
        $this->setAttribute('method', 'post');
        
        $elementOrFieldset = new Text('nome');
        $elementOrFieldset->setLabel('Nome:');
        
        $this->add($elementOrFieldset);

        $elementOrFieldset = new Password('senha');
        $elementOrFieldset->setLabel('Senha:');
        
        $this->add($elementOrFieldset);
        
        $elementOrFieldset = new Hidden('codigo');
        
        $this->add($elementOrFieldset);
        
        $elementOrFieldset = new Submit('gravar');
        $elementOrFieldset->setValue('gravar');
        
        $this->add($elementOrFieldset);
    }
}