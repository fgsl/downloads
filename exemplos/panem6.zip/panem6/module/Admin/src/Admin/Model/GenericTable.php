<?php
namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Filter\Word\DashToCamelCase;
final class GenericTable
{
    private static $tableName = null;
    
    public static function setTableName($tableName)
    {
        self::$tableName = $tableName;
    }
    
    private static function getTableName($table)
    {
        $filter = new DashToCamelCase();
        $table = $filter->filter($table);        
        
        return '\Admin\Model\\' . (is_null(self::$tableName) ? ucfirst($table) : self::$tableName);
    }
    
    public static function getTable($serviceManager, $table)
    {
        $adapter = $serviceManager->get('Zend\Db\Adapter');
        $resultSetPrototype = new ResultSet();
        $model =  self::getTableName($table);
       
        $resultSetPrototype->setArrayObjectPrototype(
	       new $model($serviceManager)
        );
        $tableGateway = new TableGateway($table, $adapter,
        		null, $resultSetPrototype);
        $tableName =  self::getTableName($table) . 'Table';
        $tableClass = new $tableName($tableGateway, $serviceManager);
        return $tableClass;       
    }
}