<?php
namespace Admin\Model;

use Tordo\Db\TableGateway\AbstractTableGateway;

class PapelTable extends AbstractTableGateway
{
    protected $keyName = 'codigo';
    protected $modelName = 'Admin\Model\Papel';
}