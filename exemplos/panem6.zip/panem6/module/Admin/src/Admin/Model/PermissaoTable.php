<?php
namespace Admin\Model;

use Tordo\Db\TableGateway\AbstractTableGateway;

class PermissaoTable extends AbstractTableGateway
{
    protected $keyName = 'codigo';
    protected $modelName = 'Admin\Model\Permissao';
}