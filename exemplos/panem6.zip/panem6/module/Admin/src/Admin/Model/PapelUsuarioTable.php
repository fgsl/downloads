<?php
namespace Admin\Model;

use Tordo\Db\TableGateway\AbstractTableGateway;

class PapelUsuarioTable extends AbstractTableGateway
{
    protected $keyName = array('codigo_papel','codigo_usuario');
    protected $modelName = 'Admin\Model\PapelUsuario';
}