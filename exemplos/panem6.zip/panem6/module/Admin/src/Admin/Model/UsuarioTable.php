<?php
namespace Admin\Model;

use Tordo\Db\TableGateway\AbstractTableGateway;
class UsuarioTable extends AbstractTableGateway
{
    protected $keyName = 'codigo';
    protected $modelName = 'Admin\Model\Usuario';
    
    public function save($model)
    {
        $model->senha = md5($model->senha);
        parent::save($model);
    }
}