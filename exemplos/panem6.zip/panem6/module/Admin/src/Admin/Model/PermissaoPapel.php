<?php
namespace Admin\Model;

use Tordo\Model\AbstractModel;
use Zend\Filter\Int;
use Zend\Filter\StringToUpper;
use Zend\Filter\StripTags;
use Zend\Validator\StringLength;
use Zend\I18n\Validator\Alpha;
use Tordo\Filter\AlonsoSql;
use Tordo\Validator\NotPolish;
class PermissaoPapel extends AbstractModel
{
    public $codigo;
    public $nome;
    
    public function __construct($serviceManager)
    {
        parent::__construct($serviceManager);
        
        $this->inputs = array(
        	'codigo' => array(
        	   'filters' => array(new Int()),
        	   'validators' => array()    
            ),
            'nome' => array(
        		'filters' => array(
            	   new StringToUpper('UTF-8'),
        		   new StripTags(),
        		   new AlonsoSql()  
                ),
                'validators' => array(
        			new StringLength(array(
        				'min'=>3,'max'=>30
        			)),
                    new Alpha(true),
                    new NotPolish()
        		)
        	)            
        );       
    }  
   
    //Este é exigido pelo ResultSet
    public function exchangeArray($array)
    {
        $this->codigo = $array['codigo'];
        $this->nome = $array['nome'];
    }    
}