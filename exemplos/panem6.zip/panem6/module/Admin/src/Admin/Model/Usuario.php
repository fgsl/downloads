<?php
namespace Admin\Model;

use Tordo\Model\AbstractModel;
use Zend\Filter\Int;
use Zend\Filter\StringToUpper;
use Zend\Filter\StripTags;
use Zend\Validator\StringLength;
use Zend\I18n\Validator\Alpha;
use Tordo\Filter\AlonsoSql;
use Tordo\Validator\NotPolish;
use Zend\Filter\StringTrim;
use Zend\Mvc\MvcEvent;
use Zend\Mvc\Application;
use Zend\Authentication\AuthenticationService;
use Zend\Permissions\Acl\Acl;
class Usuario extends AbstractModel
{
    public $codigo;
    public $nome;
    public $senha;
    
    public function __construct($serviceManager)
    {
        parent::__construct($serviceManager);
        
        $this->inputs = array(
        	'codigo' => array(
        	   'filters' => array(new Int()),
        	   'validators' => array()    
            ),
            'nome' => array(
        		'filters' => array(
            	   new StringToUpper('UTF-8'),
        		   new StripTags(),
        		   new AlonsoSql()  
                ),
                'validators' => array(
        			new StringLength(array(
        				'min'=>3,'max'=>30
        			)),
                    new Alpha(true),
                    new NotPolish()
        		)
        	),
            'senha' => array(
                'filters' => array(new StringTrim()),
                'validators' => array(new StringLength(
                	array('min'=>8,'max'=>255)
                ))    	
            )            
        );       
    }  
   
    //Este é exigido pelo ResultSet
    public function exchangeArray($array)
    {        
        $this->codigo = $array['codigo'];
        $this->nome = $array['nome'];
        $this->senha = $array['senha'];        
    }  

    public function onRoute(MvcEvent $event)
    {
        $authentication = new AuthenticationService();
        if ($authentication->hasIdentity()){
            $acl = isset($_SESSION['acl']) ? $_SESSION['acl']
                                            : new Acl();
            
            $resource = '';
            
            $roles = $acl->getRoles();
            
            $hasPermission = FALSE;
            foreach($roles as $role){
                try {
                    if ($acl->isAllowed($role,$resource))
                    {
                    	$hasPermission = TRUE;
                    	break;
                    }                    
                } catch (Exception $e) {
                }
            }
            
            if (!$hasPermission) {
                // redirecionar para alguma lugar
            }
            
            return;
        }        
        
        $application = $event->getApplication();
        $request = $application->getRequest();
        $uri = $request->getUri();
        $baseUrl = $application->getRequest()->getBaseUrl();
        $uri = substr($uri,strpos($uri,$baseUrl)
            + strlen($baseUrl) + 1);
                
        if (!($uri == 'home' || $uri == 'application' ||
            $uri == 'application/index/login' ||
            $uri == 'application/index/logout')){
            
            $router = $application->getServiceManager()
            ->get('Router');
        
            $uri = $router->assemble(array(
        	   'controller' => 'index',
               'action' => 'index'
            ),
            array(
        	   'name' => 'application'
            )
        );
        header('Location: '. $uri);
        exit;
        }           
    }
    
    public static function getAcl($usuario)
    {
        $acl = new Acl();
        //$acl->addRole($role);
        //$acl->addResource($resource)
        //$acl->allow($role,$resource);
        return $acl;
    }
    
    
    
    
    
    
    
}