<?php
namespace Admin\Model;

use Tordo\Db\TableGateway\AbstractTableGateway;

class PermissaoPapelTable extends AbstractTableGateway
{
    protected $keyName = 'codigo';
    protected $modelName = 'Admin\Model\PermissaoPapel';
}