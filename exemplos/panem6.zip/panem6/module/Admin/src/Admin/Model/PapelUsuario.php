<?php
namespace Admin\Model;

use Tordo\Model\AbstractModel;
use Zend\Filter\Int;
use Zend\Filter\StringToUpper;
use Zend\Filter\StripTags;
use Zend\Validator\StringLength;
use Zend\I18n\Validator\Alpha;
use Tordo\Filter\AlonsoSql;
use Tordo\Validator\NotPolish;
class PapelUsuario extends AbstractModel
{
    public $codigo_papel;
    public $codigo_usuario;
    public $papel;
    public $usuario;
    
    public function __construct($serviceManager)
    {
        parent::__construct($serviceManager);
        
        $this->inputs = array(
        	'codigo_papel' => array(
        	   'filters' => array(new Int()),
        	   'validators' => array()    
            ),
            'codigo_usuario' => array(
            		'filters' => array(new Int()),
            		'validators' => array()
            ),            
        );       
    }  
   
    //Este é exigido pelo ResultSet
    public function exchangeArray($array)
    {
        $this->codigo_papel = $array['codigo_papel'];
        $this->codigo_usuario = $array['codigo_usuario'];
        $this->papel = isset($array['papel']) ? $array['papel'] : null;
        $this->usuario = isset($array['usuario'])? $array['usuario'] : null;
    }

    public function getArrayCopy()
    {
        $set = parent::getArrayCopy();
        unset($set['papel']);
        unset($set['usuario']);
        return $set;   
    }
    
    
    
    
    
}