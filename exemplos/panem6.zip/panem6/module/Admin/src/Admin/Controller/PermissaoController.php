<?php
namespace Admin\Controller;

use Tordo\Controller\CrudController;

class PermissaoController extends CrudController
{
    protected $formName = 'Admin\Form\PermissaoForm';
    protected $tableName = 'PermissaoTable';
    protected $route = 'admin/default';

    public function setModel(&$model)
    {
        $codigo = $this->post()->get('codigo');
        $nome = $this->post()->get('nome');
        
        $model->exchangeArray(
            array(
        	   'codigo' => $codigo,
               'nome' => $nome 
            )	
        );       
    }
}