<?php
namespace Admin\Controller;

use Tordo\Controller\CrudController;

class UsuarioController extends CrudController
{
    protected $formName = 'Admin\Form\UsuarioForm';
    protected $tableName = 'UsuarioTable';
    protected $route = 'admin/default';

    public function setModel(&$model)
    {
        $codigo = $this->post()->get('codigo');
        $nome = $this->post()->get('nome');
        $senha = $this->post()->get('senha');
        
        $model->exchangeArray(
            array(
        	   'codigo' => $codigo,
               'nome' => $nome,
               'senha' => $senha  
            )	
        );       
    }
}