<?php
namespace Admin\Controller;

use Tordo\Controller\CrudController;
use Zend\Db\Sql\Select;

class PapelUsuarioController extends CrudController
{
    protected $formName = 'Admin\Form\PapelUsuarioForm';
    protected $tableName = 'PapelUsuarioTable';
    protected $route = 'admin/default';
    
    public function indexAction()
    {
        $select = new Select('papeis_usuario');
        $select->join('papel',
             'papel.codigo=papeis_usuario.codigo_papel',
            array('papel' => 'nome'))
             ->join('usuario',
            'usuario.codigo=papeis_usuario.codigo_usuario',
            array('usuario'=>'nome'))
       ->order('papel');

        $models = $this->getTable('PapelUsuarioTable')
        ->getModels(null,$select);
        
        return array('models'=>$models);
    }
    

    public function setModel(&$model)
    {
        $codigoPapel = $this->post()->get('codigo_papel');
        $codigoUsuario = $this->post()->get('codigo_usuario');
        
        $model->exchangeArray(
            array(
        	   'codigo_papel' => $codigoPapel,
               'codigo_usuario' => $codigoUsuario 
            )	
        );       
    }
    
    public function setForm($form)
    {
        $papelTable = $this->getTable('PapelTable');
        $papeis = $papelTable->getModels();
        $options = array();
        foreach($papeis as $papel){
            $options[$papel->codigo] = $papel->nome;
        }
        $form->get('codigo_papel')
        ->setValueOptions($options);

        $usuarioTable = $this->getTable('UsuarioTable');
        $usuarios = $usuarioTable->getModels();
        $options = array();
        foreach($usuarios as $usuario){
        	$options[$usuario->codigo] = $usuario->nome;
        }
        $form->get('codigo_usuario')
        ->setValueOptions($options);
        
    }
    
    
    
    
    
}