<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Admin for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Admin;

use Zend\ModuleManager\Feature\AutoloaderProviderInterface;
use Zend\Mvc\ModuleRouteListener;
use Zend\Mvc\MvcEvent;
use Admin\Model\GenericTable;
use Admin\Model\Usuario;

class Module implements AutoloaderProviderInterface
{
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
		    // if we're in a namespace deeper than one level we need to fix the \ in the path
                    __NAMESPACE__ => __DIR__ . '/src/' . str_replace('\\', '/' , __NAMESPACE__),
                ),
            ),
        );
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function onBootstrap(MvcEvent $e)
    {
        // You may not need to do this if you're doing it elsewhere in your
        // application
        $eventManager        = $e->getApplication()->getEventManager();
        $moduleRouteListener = new ModuleRouteListener();
        $moduleRouteListener->attach($eventManager);
        $serviceManager = $e->getApplication()
        ->getServiceManager();
        $eventManager->attach(MvcEvent::EVENT_ROUTE,
                array(
                    new Usuario($serviceManager),
                    'onRoute'
                    ));
    }
    
    public function getServiceConfig()
    {
        return array(
            'factories' => array(
            	'UsuarioTable' => function($serviceManager){
            	   GenericTable::setTableName('Usuario');
            	   return GenericTable::getTable($serviceManager, 'usuario');    
            	},
            	'PapelTable' => function($serviceManager){
            	    GenericTable::setTableName('Papel');
            		return GenericTable::getTable($serviceManager, 'papel');
            	},
            	'PermissaoTable' => function($serviceManager){
            	    GenericTable::setTableName('Permissao');
            		return GenericTable::getTable($serviceManager, 'permissao');
            	},
            	'PapelUsuarioTable' => function($serviceManager){
            	    GenericTable::setTableName('PapelUsuario');
            		return GenericTable::getTable($serviceManager, 'papeis_usuario');
            	},
            	'PermissaoPapelTable' => function($serviceManager){
            	    GenericTable::setTableName('PermissaoPapel');
            		return GenericTable::getTable($serviceManager, 'permissoes_papel');
            	}        	 
            )
        );
    }    
}
