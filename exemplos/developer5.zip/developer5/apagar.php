<?php
require 'autoload.php';
$class = 'Entidade\\' . ucfirst($_GET['cadastro']);
call_user_func(array($class,'apagar'),$_GET['chave']);
header('Location: index.php');