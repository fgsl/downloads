<?php
require 'autoload.php';
$class = 'Entidade\\' . ucfirst($_GET['cadastro']);
call_user_func(array($class,'gravar'),$_POST);
header('Location:index.php');






