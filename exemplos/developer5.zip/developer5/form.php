<?php
require 'autoload.php';
$class = 'Entidade\\' .ucfirst($_GET['cadastro']);

$entidade = call_user_func(array($class,'get'),
isset($_GET['chave']) ? $_GET['chave'] : NULL); 

$method = 'get' . ucfirst(
	call_user_func(array($class,'getChave'))
);

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Inclusão de <?=$_GET['cadastro']?></title>
</head>
<body>
<form method="post" action="gravar.php?cadastro=<?=$_GET['cadastro']?>">
Nome <input type="text" name="nome" value="<?=$entidade->getNome()?>" autofocus="autofocus">
<input type="hidden" name="chave" value="<?=$entidade->$method()?>">
<input type="submit" value="gravar">
</form>
</html>