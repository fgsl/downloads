<?php
$handle = fopen(__DIR__ . '/alunos.txt',
'r');
if ($handle) {
	while (!feof($handle)){
		$registro = fread($handle,
		300);
		if (trim($registro)==''){
			continue;
		}
		
		$registro = 
		explode(';',$registro);

		$codigo = $registro[0];
		$nome = $registro[1];
		$urlAlterar = "edit.php?codigo=$codigo";
		$urlExcluir = "delete.php?codigo=$codigo";

		$template = <<<TEMPLATE
<tr>
	<td><a href="$urlAlterar">$codigo</a></td>
	<td>$nome</td>
	<td><a href="$urlExcluir">Excluir</a></td>
</tr>
TEMPLATE;
		echo $template;	
	}
	fclose($handle);
} 