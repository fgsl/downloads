<?php
require 'functions.php';

$codigo = isset($_GET['codigo']) ?
$_GET['codigo'] : NULL;

if (!is_null($codigo)){
	removerAluno($codigo);
}
header('Location: index.php');
