<?php
/**
 *
 * @param string $registro
 * @return boolean
 */
function gravarRegistro($registro)
{
	$handle = fopen(__DIR__ . '/alunos.txt','a');
	if (!$handle) return FALSE;
	fwrite($handle, $registro, 300);
	fclose($handle);
	return TRUE;
}

/**
 *
 * @param string $codigo
 * @param string $nome
 * @param boolean $excluir
 */
function alterarRegistro($codigo, $nome = NULL, $excluir = FALSE)
{
	$handle = fopen(__DIR__ . '/alunos.txt',
			'r');
	$handle2 = fopen(__DIR__ . '/tmp.txt',
			'a');
	while(!feof($handle)){
		gravarConteudo($handle, $handle2, $codigo, $nome, $excluir);
	}
	fclose($handle);
	fclose($handle2);
	unlink(__DIR__ . '/alunos.txt');
	rename(
	__DIR__ . '/tmp.txt',
	__DIR__ . '/alunos.txt'
			);
}

/**
 *
 * @param resource $handle
 * @param resource $handle2
 * @param string $codigo
 * @param string $nome
 * @param boolean $excluir
 */
function gravarConteudo($handle, $handle2, $codigo, $nome, $excluir)
{
	$registro = fread($handle,300);
	$campos = explode(';',$registro);
	if ($campos[0] == $codigo)
	{
		if ($excluir) return;
		$registro = $codigo .
		';' . $nome;
		$registro = substr(
				$registro .
				str_repeat(' ',299)
				,0,299) . "\n";
	}
	fwrite($handle2,$registro,300);
}


