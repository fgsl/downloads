<?php
$texto1 = "\tatirei o pau no gato\n";
$texto1 .= ' mas o gato não morreu';
$texto1 .= " , esse gato é insistente\n";
$texto1 .= " , gato chato...\n"; 

//echo $texto1;

$Garfield = 'preguiçoso';
$gato = 'Garfield';
$animal = 'gato';

//heredoc
$texto1 = <<<BLOCO
	Atirei o pau no $animal, mas o $animal não morreu.
	Dona Chica admirou-se que o $animal não morreu.
BLOCO;

//echo $texto1;

//variável variável
//echo $$$animal;

//nowdoc
$texto1 = <<<'BLOCO'
	Atirei o pau no $animal, mas o $animal não morreu.
	Dona Chica admirou-se que o $animal não morreu.
BLOCO;

echo $texto1;

















