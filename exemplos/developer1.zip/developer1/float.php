<?php
$inteiro = 25;

$real = 4.25;

$real = (float) 25;

echo gettype($real);