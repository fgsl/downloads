<?php
$texto1 = 'atirei o pau no gato';

$texto2 = "\$texto1, mas o gato não morreu";

echo $texto1;

echo "\n";

echo $texto2;