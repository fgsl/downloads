<?php
/**
 * Monta o registro do aluno
 * para ser gravado
 *
 * @param string $nome
 * @return boolean
 */
function gravarAluno($nome)
{
	if (is_null($nome)) return FALSE;

	$codigo = md5(time());
	$registro = [$codigo,$nome];
	return gravarRegistro($registro);
}

/**
 *
 * @param string $codigo
 * @param string $nome
 */
function alterarAluno($codigo,$nome=NULL)
{
	alterarRegistro($codigo,$nome);
}

/**
 *
 * @param string $codigo
 */
function removerAluno($codigo)
{
	alterarRegistro($codigo, NULL, TRUE);
}

