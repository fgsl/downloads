<?php
require 'record.php';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Inclusão de aluno</title>
</head>
<body>
<h1>Inclusão de aluno</h1>
<form action="save.php" method="post">
Nome: 
<input type="text" name="nome"
value="<?=$nome?>" autofocus="autofocus">
<input type="hidden" name="codigo"
value="<?=$codigo?>">
<input type="submit" value="gravar">
</form>
</body>
</html>