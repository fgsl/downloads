<?php
$xml = new SimpleXMLElement(__DIR__ . '/alunos.xml',NULL,TRUE);
$children = $xml->children();
foreach($children as $child)// aluno
{
		$registro = $child->children();
		$codigo = $registro->codigo;
		$nome = $registro->nome;
		$urlAlterar = "edit.php?codigo=$codigo";
		$urlExcluir = "delete.php?codigo=$codigo";

		$template = <<<TEMPLATE
<tr>
	<td><a href="$urlAlterar">$codigo</a></td>
	<td>$nome</td>
	<td><a href="$urlExcluir">Excluir</a></td>
</tr>
TEMPLATE;
		echo $template;	
	}
