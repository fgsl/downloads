<?php
/**
 *
 * @param array $registro
 * @return boolean
 */
function gravarRegistro(array $registro)
{
	$xml = '';
	$path = __DIR__ . '/alunos.xml';
	if (!file_exists($path)){
		$xml = <<<XML
<?xml version="1.0"?>
<alunos>

XML;
		
	}
	$handle = fopen($path,'a');
	if (!$handle) return FALSE;
	fclose($handle);

	$content = file_get_contents($path);
	$content = str_replace('</alunos>',
	'',$content);
	
	$xml .= $content;
	
	$xml .= <<<XML
<aluno>
<codigo>$registro[0]</codigo>
<nome>$registro[1]</nome>
</aluno>
</alunos>			 
XML;
	
	file_put_contents($path,$xml);	
	
	return TRUE;
}

/**
 *
 * @param string $codigo
 * @param string $nome
 * @param boolean $excluir
 */
function alterarRegistro($codigo, $nome = NULL, $excluir = FALSE)
{
	$xml = new SimpleXMLElement(
			__DIR__ . '/alunos.xml',
			NULL,
			TRUE);
	
	$xmlContent = <<<XML
<?xml version="1.0"?>
<alunos>
</alunos>		 		
XML;
		
	$newXml = new SimpleXMLElement(
				$xmlContent);		
		 
	foreach($xml->children() as $child)//aluno
	{
		$registro = $child->children();
		if (!($excluir && $registro->codigo == $codigo))
		{
			$aluno = $newXml->addChild('aluno');				
			$aluno->addChild('codigo',
					$registro->codigo
			);
			$aluno->addChild('nome',
					$registro->codigo
					== $codigo ?
					$nome :
					$registro->nome
			);
		}	
	}

	$content = $newXml->asXML();
		
	file_put_contents(__DIR__ . 
	'/alunos.xml',$content);
}

/**
 *
 * @param resource $handle
 * @param resource $handle2
 * @param string $codigo
 * @param string $nome
 * @param boolean $excluir
 */
function gravarConteudo($handle, $handle2, $codigo, $nome, $excluir)
{
	$registro = fread($handle,300);
	$campos = explode(';',$registro);
	if ($campos[0] == $codigo)
	{
		if ($excluir) return;
		$registro = $codigo .
		';' . $nome;
		$registro = substr(
				$registro .
				str_repeat(' ',299)
				,0,299) . "\n";
	}
	fwrite($handle2,$registro,300);
}


