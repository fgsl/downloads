<?php
require 'base.functions.php';
require 'aluno.functions.php';