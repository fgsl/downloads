<?php
$codigo = isset($_GET['codigo']) ?
$_GET['codigo'] : NULL;

$nome = '';

if (!is_null($codigo))
{
	$xml = new SimpleXMLElement(
			__DIR__ . '/alunos.xml',
			NULL,
			TRUE
			);
	
	$tagAlunos = $xml->xpath(
		'/alunos/aluno'
	);
	
	foreach($tagAlunos as $tagAluno)
	{
		if ($tagAluno->codigo == $codigo)
		{
			$nome = $tagAluno->nome;
			break;
		}			
	}	
}





