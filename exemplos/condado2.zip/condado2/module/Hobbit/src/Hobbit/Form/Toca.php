<?php
namespace Hobbit\Form;

use Zend\Form\Form;
use Zend\Form\Element\Text;
use Zend\Form\Element\Hidden;
use Zend\Form\Element\Submit;
use Coiote\Form\IdInterface;

class Toca extends Form implements IdInterface
{

    public function __construct($name = 'toca')
    {
        parent::__construct($name);
        
        $this->setAttribute('method', 'post');

        $elementOrFieldset = new Text('nome');
        $elementOrFieldset->setLabel('Nome:');
        $elementOrFieldset->setAttribute('autofocus', 'autofocus');
        
        $this->add($elementOrFieldset);
        
        $elementOrFieldset = new Hidden('id');
        
        $this->add($elementOrFieldset);
        
        $elementOrFieldset = new Submit('gravar');
        $elementOrFieldset->setValue('gravar');
        
        $this->add($elementOrFieldset);     
        
    }
    
    public function setId($id, array $tables)
    {
        if ($id == null) return;
        
        $tocaTable = $tables['TocaTable'];
        
        $toca = $tocaTable->fetchOne($id);
        
        if ($toca != null)
        {
            $this->get('nome')->setValue($toca->nome);
            $this->get('id')->setValue($id);
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}

?>