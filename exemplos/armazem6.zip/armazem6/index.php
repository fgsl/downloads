<?php
use Novatec\Framework2\Db\Adapter;
use Novatec\Framework2\Orm\Mapper;
use Novatec\Framework2\Controller\FrontController;
use Symfony\Component\Yaml\Parser;
use Doctrine\ORM\Tools\Setup,
	Doctrine\ORM\EntityManager,
	Doctrine\ORM\Configuration,
	Doctrine\Common\Cache\ArrayCache as Cache,
	Doctrine\Common\Annotations\AnnotationRegistry;

define('DS',DIRECTORY_SEPARATOR);

require realpath(__DIR__ . '/../library/vendor'). '/autoload.php';

spl_autoload_register(function($className){
    include __DIR__ . DS . str_replace('\\', DS, $className) . '.php';
});

$yaml = new Parser();
$connection = $yaml->parse(file_get_contents(__DIR__ . DS . 'config.yml'));

$config = new Configuration();
$cache = new Cache();
$config->setMetadataCacheImpl($cache);
$annotationsPath = realpath(__DIR__ . '/../library/vendor/doctrine/orm/lib/Doctrine/ORM/Mapping/Driver');
AnnotationRegistry::registerFile($annotationsPath . '/DoctrineAnnotations.php');
$driver = new Doctrine\ORM\Mapping\Driver\AnnotationDriver(
		new Doctrine\Common\Annotations\AnnotationReader(),
		array(__DIR__ . DS . 'Application' . DS.  'Model')
);
$config->setMetadataDriverImpl($driver);
$config->setProxyDir(__DIR__ . DS . 'library' . DS . 'Application' . DS . 'Model' . DS . 'Proxy');
$config->setProxyNamespace('Application\Model\Proxy');

$GLOBALS[EntityManager::class] = EntityManager::create($connection, $config);

$frontController = FrontController::getInstance();
$frontController->setPath(__DIR__ . DS . 'Application' .
		DS . 'View');
$frontController->dispatch();