<?php
namespace Application\Controller;

use Application\Model\Pedido;
use Novatec\Framework2\Controller\PageController;
use Doctrine\ORM\EntityManager;

class PedidoController extends PageController {

    public function indexAction() {
        $url = '?controller=pedido&action=editar';
        $em = $GLOBALS[EntityManager::class];
        $query = $em->createQuery("select p from Application\Model\Pedido p");
        $pedidos = $query->getResult();

        $this->view->pedidos = $pedidos;
        $this->view->url = $url;
    }

    public function editarAction() {
        $action = '?controller=pedido&action=gravar';
        $this->view->action = $action;
    }

    public function gravarAction() {
        $numero = $_POST['numero'];

        $pedido = new Pedido();
        $pedido->setNumero($numero);

        $em = $GLOBALS[EntityManager::class];
        $em->persist($pedido);
        $em->flush();

        $this->redirect('index');
    }
}
