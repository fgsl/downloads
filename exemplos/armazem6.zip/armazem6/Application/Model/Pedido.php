<?php
namespace Application\Model;

use Doctrine\ORM\Mapping\Entity,
    Doctrine\ORM\Mapping\Table,
    Doctrine\ORM\Mapping\Id,
    Doctrine\ORM\Mapping\Column;

/**
 * @Entity
 * @Table(name="pedidos")
 *
 */
class Pedido {

    /**
     * @Id 
     * @Column(type="integer") 
     * 
     */
    private $numero;

    public function getNumero() {
        return $this->numero;
    }

    public function setNumero($numero) {
        $this->numero = $numero;
    }

}
