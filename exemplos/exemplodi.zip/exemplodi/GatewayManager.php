<?php

class GatewayManager
{
    private $dataSource;

    function __construct(DataSource $dataSource)
    {
    	//
    	$this->dataSource = $dataSource;
    }
}

?>