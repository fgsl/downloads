<?php

class PowerActiveRecord
{
    private $gatewayManager;

    function __construct(GatewayManager $gatewayManager)
    {
    	//
    	$this->gatewayManager = $gatewayManager;
    }
}

?>