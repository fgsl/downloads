<?php

class MegaPowerResultSet
{
    private $powerActiveRecord;
    
    function __construct(PowerActiveRecord $powerActiveRecord)
    {
    	//
    	$this->powerActiveRecord = $powerActiveRecord;
    }
}

?>