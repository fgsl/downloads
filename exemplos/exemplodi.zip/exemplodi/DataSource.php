<?php

class DataSource
{
    private $file;
    /**
     * 
     * @param string $file
     */
    function __construct($file)
    {
    	//
    	$this->file = $file;
    }
}

?>