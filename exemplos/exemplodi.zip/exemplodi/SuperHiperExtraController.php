<?php

class SuperHiperExtraController
{
    private $megaPowerResultSet;
    
    function __construct(MegaPowerResultSet $megaPowerResultSet)
    {
    	//
    	$this->megaPowerResultSet = $megaPowerResultSet;
    }
}

?>