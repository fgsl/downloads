<?php

use Zend\Di\Di;
use Zend\Loader\StandardAutoloader;

require 
'vendor/Zend Framework 2/Zend/Loader/StandardAutoloader.php';
$autoloader = new StandardAutoloader(array(
	'autoregister_zf' => TRUE
));
$autoloader->register();

spl_autoload_register(function($class){
    require $class . '.php';
});

$di = new Di();

$dataSource = new \DataSource('qualquercoisa.dat');
$gatewayManager = new \GatewayManager($dataSource);
$powerActiveRecord = new \PowerActiveRecord($gatewayManager);
$megaPowerResultSet = new \MegaPowerResultSet($powerActiveRecord);
$superHiperExtraController = new \SuperHiperExtraController($megaPowerResultSet);
$application = new \UltraApplication($superHiperExtraController);

var_dump($application);


