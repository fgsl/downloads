<?php

use Zend\Di\Di;
use Zend\Loader\StandardAutoloader;

require 
'vendor/Zend Framework 2/Zend/Loader/StandardAutoloader.php';
$autoloader = new StandardAutoloader(array(
	'autoregister_zf' => TRUE
));
$autoloader->register();

spl_autoload_register(function($class){
    $filename = $class . '.php';
    if (file_exists($filename))
        require $class . '.php';
});

$di = new Di();

$file = 'qualquercoisa.data';

$di->instanceManager()->setParameters('DataSource',
        array(
    	   'file' => $file, 
        )
);

$application = $di->get('UltraApplication');

var_dump($application);


