<?php

class UltraApplication
{
    private $superHiperExtraController;

    function __construct(SuperHiperExtraController $superHiperExtraController)
    {
    	//
    	$this->superHiperExtraController = $superHiperExtraController;
    }
}

?>