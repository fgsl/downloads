<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Tributo for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Tributo\Controller;

use Tordo\Controller\CrudController;

class IndexController extends CrudController 
{
    protected $tableName = 'TributoTable';
    protected $formName = 'Tributo\Form\TributoForm';
    protected $route = 'tributo';    
    
    protected function setForm($form)
    {
        $form->setDistritos($this->getTable('DistritoTable')
        		->getModels());        
    }

    public function setModel(&$model)
    {
        $codigo = $this->post()->get('codigo');
        $nome = $this->post()->get('nome');
        $codigoDistrito = $this->post()->get('codigo_distrito');
        
        $model = $this->getTable()->getModel();
        $model->exchangeArray(array(
        		'codigo' => $codigo,
        		'nome' => $nome,
        		'codigo_distrito'=> $codigoDistrito
        ));
    }    
}