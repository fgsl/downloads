<?php
namespace Tributo\Model;

use Distrito\Model\Distrito;
use Zend\ServiceManager\ServiceManager;
use Tordo\Model\AbstractModel;
use Zend\Filter\StringToUpper;
use Zend\Filter\Int;
use Zend\Filter\StripTags;
use Zend\Validator\StringLength;
use Zend\I18n\Validator\Alpha;

class Tributo extends AbstractModel
{
    /**
     * 
     * @var integer
     */
    public $codigo;
    /**
     * 
     * @var string
     */
    public $nome;
    /**
     * 
     * @var Distrito
     */
    public $distrito;
  
    public function __construct(ServiceManager $serviceManager)
    {
        parent::__construct($serviceManager);
        $this->distrito = new Distrito($serviceManager);
        
        $this->inputs = array(
        	'codigo' => array(
        	   'filters' => array(new Int()),
        	   'validators' => array(), 
            ),
            'nome' => array(
                'filters' => array(
                    new StringToUpper('UTF-8'),
                    new StripTags()
                ),
                'validators' => array(
                	new StringLength(array(
                		'min'=>3,'max'=>30
                	   )
                	),
                    new Alpha(true)
                ),                
        	),
            'codigo_distrito' => array(
                'filters' => array(new Int()),
                'validators' => array(),                
            )
        );
    }
   
    public function toArray()
    {
        return get_object_vars($this);
    }
  
    // Este é exigido pelo bind() do Zend\Form  
    public function getArrayCopy()
    {
        $set = parent::getArrayCopy();
        unset($set['distrito']);
        $set['codigo_distrito'] = $this->distrito
        ->codigo;
        return $set;
    }    
   
    //Este é exigido pelo ResultSet
    public function exchangeArray($array)
    {
        $this->codigo = $array['codigo'];
        $this->nome = $array['nome'];
        $dt = $this->serviceManager
        ->get('DistritoTable');
        $this->distrito = $dt->getModel($array['codigo_distrito']);
    }
}