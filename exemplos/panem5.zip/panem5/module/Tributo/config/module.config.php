<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Tributo\Controller\Index' => 'Tributo\Controller\IndexController',
        ),
    ),
    'controller_plugins' => array(
    		'invokables' => array(
    				'post' => 'Tordo\Controller\Plugin\Post',
    		        'easyUrl' => 'Tordo\Controller\Plugin\EasyUrl'
    		             
    		),
    ),    
    'view_helpers' => array(
    		'invokables' => array(
    				'directLoop' => 'Tordo\View\Helper\DirectLoop',
    		        'formComplete' => 'Tordo\View\Helper\FormComplete',
    		        'easyUrl' => 'Tordo\View\Helper\EasyUrl'  
    		      
    		),
    ),    
    'router' => array(
        'routes' => array(
            'tributo' => array(
                'type'    => 'Segment',
                'options' => array(
                    // Change this to something specific to your module
                    'route'    => '/tributo[/[:action[/:key]]]',
                    'defaults' => array(
                        // Change this value to reflect the namespace in which
                        // the controllers for your module are found
                        '__NAMESPACE__' => 'Tributo\Controller',
                        'controller'    => 'Index',
                        'action'        => 'index',
                    ),
                ),
                'may_terminate' => true,                
            ),
        ),
    ),
    'view_manager' => array(
        'template_path_stack' => array(
            'Tributo' => __DIR__ . '/../view',
        ),
    ),
);
