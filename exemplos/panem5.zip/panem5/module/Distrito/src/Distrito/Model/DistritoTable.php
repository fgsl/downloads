<?php
namespace Distrito\Model;

use Tordo\Db\TableGateway\AbstractTableGateway;
class DistritoTable extends AbstractTableGateway
{
    protected $keyName = 'codigo';
    protected $modelName = 'Distrito\Model\Distrito';
}