<?php
use Symfony\Component\Filesystem\Filesystem;

require __DIR__ . '/vendor/autoload.php';

$fs = new Filesystem();

print_r($fs);