<?php
use Symfony\Component\Yaml\Parser;
use Symfony\Component\Yaml\Exception\ParseException;

require __DIR__ . '/vendor/autoload.php';

$yaml = new Parser();

try {
    $value = $yaml->parse(file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . 'yaml01.yml'));
    echo '<pre>';
    print_r($value);
    echo '</pre>';
} catch (ParseException $e) {
    printf("Incapaz de interpretar o texto YAML: %s", $e->getMessage());
}