<?php
namespace Personagens\Model;

class Personagem
{
	public $codigo;
	public $nome;
	public $editora;
	
	public function exchangeArray($data)
	{
		$this->codigo = isset($data['codigo']) ? $data['codigo'] : null;
		$this->nome = isset($data['nome']) ? $data['nome'] : null;
		$this->editora = isset($data['editora']) ? $data['editora'] : null;
	}
	
	public function getArrayCopy()
	{
		return get_object_vars($this);	
	}
	
}