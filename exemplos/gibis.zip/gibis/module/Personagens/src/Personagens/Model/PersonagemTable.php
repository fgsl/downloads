<?php
namespace Personagens\Model;

use Zend\Db\TableGateway\TableGateway;

class PersonagemTable
{
	protected $tableGateway;
	
	public function __construct(TableGateway $tableGateway)
	{
		$this->tableGateway = $tableGateway;
	}
	
	public function buscarPersonagens()
	{
		return $this->tableGateway->select();
	}
	
	public function buscarPersonagem($codigo)
	{
		$rowSet = $this->tableGateway->select(array('codigo'=>$codigo));
		return $rowSet->current();
	}
	
	public function gravarPersonagem($personagem)
	{
		$personagemExistente = $this->buscarPersonagem($personagem->codigo);
		
		$set = array(
				'nome' => $personagem->nome,
				'editora' => $personagem->editora
		);		
		
		if (empty($personagemExistente))
		{			
			$this->tableGateway->insert($set);
		}
		else
		{
			$this->tableGateway->update($set, array('codigo'=>$personagem->codigo));
		}
	}
	
	public function apagarPersonagem($personagem)
	{
		$this->tableGateway->delete(array('codigo'=>$personagem->codigo));
	}
	
	
	
}