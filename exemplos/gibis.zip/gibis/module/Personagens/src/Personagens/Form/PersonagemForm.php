<?php
namespace Personagens\Form;

use Zend\Form\Element\Submit;

use Zend\Form\Element\Hidden;

use Zend\Form\Element\Text;

use Zend\Form\Form;

class PersonagemForm extends Form
{
	public function __construct($name = 'personagens')
	{
		parent::__construct($name);

		$this->setAttribute('method', 'post');
		
		$element = new Text('nome');
		$element->setLabel('Nome:');
		$this->add($element);
		
		$element = new Text('editora');
		$element->setLabel('Editora:');
		$this->add($element);
		
		$element = new Hidden('codigo');
		$this->add($element);
		
		$element = new Submit('submit');
		$element->setValue('gravar');
		$this->add($element);	
		
	}
}