<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2013 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Personagens\Controller;

use Personagens\Model\Personagem;

use Personagens\Form\PersonagemForm;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class IndexController extends AbstractActionController
{
    public function indexAction()
    {
    	$personagemTable = $this->getServiceLocator()
    	->get('Personagens\Model\PersonagemTable');
    	
    	$personagens = $personagemTable->buscarPersonagens();
    	
        return new ViewModel(array('personagens' => $personagens));
    }
    
    public function incluirAction()
    {
    	$form = new PersonagemForm();
    	$action = $this->url()->fromRoute('personagens', array('action'=>'gravar'));
    	$form->setAttribute('action', $action);    	
    	
    	return new ViewModel(array('form'=>$form));
    }
    
    public function editarAction()
    {
    	$form = new PersonagemForm();
    	$action = $this->url()->fromRoute('personagens', array('action'=>'gravar'));
    	$form->setAttribute('action', $action);
    	
    	$codigo = $this->params('codigo',null);
    	
    	$personagemTable = $this->getServiceLocator()
    	->get('Personagens\Model\PersonagemTable');
    	     	
		$personagem = $personagemTable->buscarPersonagem($codigo);
		
		$form->bind($personagem);
    	
    	return new ViewModel(array('form'=>$form));
    }
    
    
    public function gravarAction()
    {
    	$request = $this->getRequest();
    	
    	if ($request->isPost())
    	{
    		$personagem = new Personagem();
    		$personagem->exchangeArray($request->getPost());
    		
    		$personagemTable = $this->getServiceLocator()
    		->get('Personagens\Model\PersonagemTable');
    		
    		$personagemTable->gravarPersonagem($personagem);    			
    	}
    	return $this->redirect()->toRoute('personagens');
    }
    
    public function excluirAction()
    {
    	$codigo = $this->params('codigo',null);
    	
    	$personagemTable = $this->getServiceLocator()
    	->get('Personagens\Model\PersonagemTable');
    	 
    	$personagem = $personagemTable->buscarPersonagem($codigo);
    	
    	$personagemTable->apagarPersonagem($personagem);
    	
    	return $this->redirect()->toRoute('personagens');
    }
}
