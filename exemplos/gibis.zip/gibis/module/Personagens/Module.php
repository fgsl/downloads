<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2013 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Personagens;

use Zend\Db\TableGateway\TableGateway;

use Personagens\Model\Personagem;

use Zend\Db\ResultSet\ResultSet;

use Personagens\Model\PersonagemTable;

use Zend\Mvc\ModuleRouteListener;
use Zend\Mvc\MvcEvent;

class Module
{
	public function onBootstrap(MvcEvent $e)
	{
		$eventManager        = $e->getApplication()->getEventManager();
		$moduleRouteListener = new ModuleRouteListener();
		$moduleRouteListener->attach($eventManager);
	}

	public function getConfig()
	{
		return include __DIR__ . '/config/module.config.php';
	}

	public function getAutoloaderConfig()
	{
		return array(
				'Zend\Loader\StandardAutoloader' => array(
						'namespaces' => array(
								__NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
						),
				),
		);
	}

	public function getServiceConfig()
	{
		return array(
				'factories' => array(
						'Personagens\Model\PersonagemTable' => function($sm){
							$tableGateway = $sm->get('PersonagemTableGateway');
							return new PersonagemTable($tableGateway);
						},
						'PersonagemTableGateway' => function($sm){
							$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
							$resultSet = new ResultSet();
							$resultSet->setArrayObjectPrototype(new Personagem());
							return new TableGateway('personagens', $dbAdapter, null, $resultSet);
						}
				));
	}


}
