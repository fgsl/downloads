<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Tropa\Controller;

use Fgsl\Mvc\Controller\AbstractCrudController;
use Tropa\Form\LanternaForm;
use Tropa\Model\Lanterna;

class LanternaController extends AbstractCrudController
{
	public function __construct()
	{
		$this->formClass = 'Tropa\Form\LanternaForm';
		$this->modelClass = 'Tropa\Model\Lanterna';
		$this->namespaceTableGateway = 'Tropa\Model\LanternaTable';
		$this->route = 'lanterna';
		$this->title = 'Cadastro de Lanternas Verdes';
		$this->label['add']	= 'Incluir';
		$this->label['edit'] = 'Alterar';		
		$this->label['yes']	='Sim';
		$this->label['no']	='Não';
	}
}
