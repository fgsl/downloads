<?php
namespace Application\Model;

use Doctrine\ORM\Mapping as ORM;
use Fgsl\Authentication\Adapter\DoctrineTable;
use Zend\Authentication\AuthenticationService;

/**
 * @ORM\Entity
 * @ORM\Table(name="usuarios")
 *
 */
class Usuario
{
	/** @ORM\Id 
	 * @ORM\Column(type="integer") 
	 * @ORM\GeneratedValue(strategy="AUTO")
	 **/
	public $uid;	
	/** @ORM\Column(type="string") **/	
	public $identidade;
	/** @ORM\Column(type="string") **/	
	public $credencial;
	public $messages = array();
	
	public function __construct($identidade,$credencial)
	{
		$this->identidade = $identidade;
		$this->credencial = $credencial;
	}	
	
	public function authenticate()
	{
		// cria o adaptador para o mecanismo contra o qual se fará a autenticação
		$adapter = new DoctrineTable($GLOBALS['entityManager']);
		$adapter->setIdentityColumn('identidade')
		->setEntityName(__CLASS__)
		->setCredentialColumn('credencial')
		->setIdentity($this->identidade)
		->setCredential($this->credencial);

		// cria o serviço de autenticação e injeta o adaptador nele
		$authentication = new AuthenticationService();
		$authentication->setAdapter($adapter);
		
		// autentica
		$result = $authentication->authenticate();
		
		if ($result->isValid())
		{
			// recupera o registro do usuário como um objeto, sem o campo senha
			$usuario = $authentication->getAdapter()->getResultRowObject(null,'senha');
			$authentication->getStorage()->write($usuario);
			return true;			
		}
		else
		{
			$this->messages = $result->getMessages();
			return false;	
		}		
	}
}