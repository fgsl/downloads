<?php
require 'pdo.php';
require 'functions.php';

$cadastro = isset($_GET['cadastro']) ? $_GET['cadastro'] : NULL;
$nomeChave = getChave($cadastro);

$nome = isset($_POST['nome']) ? $_POST['nome'] : NULL;
$chave = (integer) (isset($_POST['chave']) ? $_POST['chave'] : NULL);


if (! is_null($nome)) {
    $sql = "INSERT INTO $cadastro(nome) values ('$nome')";

    if (!empty($chave)) {
        $sql = 
        "UPDATE $cadastro SET nome='$nome' 
        WHERE $nomeChave=$chave";        
    }
        
   if (! $pdo->exec($sql)) {
     echo 'Não conseguiu gravar o registro';
     exit();
   }
}
header('Location:index.php');






