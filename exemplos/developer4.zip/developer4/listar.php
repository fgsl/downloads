<?php
require 'pdo.php';
require 'functions.php';

$cadastro = isset($cadastro) ? $cadastro : NULL;

$resultSet = $pdo->query("SELECT * FROM $cadastro");

$records = $resultSet->fetchAll();
foreach($records as $record)
{
    echo '<tr>';
    echo 
    "<td><a href=\"form.php?cadastro=$cadastro&chave={$record[getChave($cadastro)]}\">
    {$record[getChave($cadastro)]}</a></td>";
    echo "<td>{$record['nome']}</td>";
    echo
    "<td><a href=\"apagar.php?cadastro=$cadastro&chave={$record[getChave($cadastro)]}\">
    Excluir</a></td>";    
    echo '</tr>';    
}