<?php
use Symfony\Component\Console\Application;

require realpath(__DIR__ . '/../library/vendor'). '/autoload.php';

spl_autoload_register(function($className){
    include __DIR__ . DIRECTORY_SEPARATOR . str_replace('\\', DIRECTORY_SEPARATOR, $className) . '.php';
});

$command = $argv[1];
$command = explode(':',$command);
foreach($command as $index => $token)
{
	$command[$index] = ucfirst($token);
}
$command = implode('', $command);

$application = new Application();
$application->add(new $command());
$application->run();