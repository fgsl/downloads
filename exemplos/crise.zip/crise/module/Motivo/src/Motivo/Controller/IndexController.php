<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Motivo for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Motivo\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Motivo\Form\Motivo as MotivoForm; 
use Motivo\Model\Motivo;

class IndexController extends AbstractActionController
{
    public function indexAction()
    {
        $motivoTable = $this->getServiceLocator()
        ->get('MotivoTable');
        $motivos = $motivoTable->getAll();
        return array('motivos' => $motivos);
    }

    public function editAction()
    {
        $codigo = $this->params('codigo');

        $motivo = new Motivo(array());
        if (!empty($codigo)){
            $motivoTable = $this->getServiceLocator()
            ->get('MotivoTable');
            $motivo = $motivoTable->get($codigo);
        }
        
        $form = new MotivoForm();
        $form->setAttribute('action', $this->url()
            ->fromRoute('motivo/default', array(
                'action'=>'save')
                )
            );
        $form->bind($motivo);
        return array('form' => $form);
    }
    
    public function saveAction()
    {
        $motivo = new Motivo($_POST);
        $motivoTable = $this->getServiceLocator()
        ->get('MotivoTable');
        $motivoTable->save($motivo);
        $this->redirect()->toRoute('motivo');
    }
    
    public function deleteAction()
    {
        $codigo = $this->params('codigo');
        
        $motivoTable = $this->getServiceLocator()
        ->get('MotivoTable');
        $motivoTable->delete($codigo);
        
        $this->redirect()->toRoute('motivo');
    }
}
