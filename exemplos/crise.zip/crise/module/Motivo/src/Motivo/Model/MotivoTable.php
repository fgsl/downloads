<?php
namespace Motivo\Model;

use Zend\Db\TableGateway\TableGatewayInterface;
class MotivoTable
{
    /**
     * 
     * @var TableGatewayInterface
     */
    private $tableGateway;
    
    /**
     * 
     * @param TableGatewayInterface $tableGateway
     */
    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }
    
    public function save(Motivo $motivo)
    {
        $set = $motivo->getArrayCopy();
        
        if (empty($motivo->codigo)){
            $this->tableGateway->insert($set);
        } else {
            $this->tableGateway->update($set, 'codigo = ' . $motivo->codigo);
        }
    }
    
    public function get($codigo)
    {
        $motivos = $this->tableGateway->select(array('codigo'=>$codigo));
        if ($motivos->count() == 0){
            return new Motivo(array());
        }
        return new Motivo($motivos->current()->getArrayCopy());
    }
    
    public function getAll()
    {
        return $this->tableGateway->select();
    }
    
    public function delete($codigo)
    {
        $this->tableGateway->delete('codigo = ' . $codigo);
    }
}