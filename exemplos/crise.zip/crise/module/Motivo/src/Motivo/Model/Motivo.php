<?php
namespace Motivo\Model;

class Motivo
{
    /**
     * 
     * @var integer
     */
    public $codigo;
    /**
     * 
     * @var string
     */
    public $nome;
    
    /**
     * 
     * @param array $data
     */
    public function __construct(array $data)
    {
        $this->codigo = isset($data['codigo']) ? $data['codigo'] : NULL;
        $this->nome = isset($data['nome']) ? $data['nome'] : NULL;
    }

    /**
     * Exigido por Zend\Form
     * 
     * @return array
     */
    public function getArrayCopy()
    {
       return get_object_vars($this);
    }
}
