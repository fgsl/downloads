<?php

/* LeoncioarmazemBundle:Default:index.html.twig */
class __TwigTemplate_3c797aa90753e374da4ec2a03d49bf564d653a8f29cdf2215f597ca5d7f5063f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b91dd69ad3d74e546c87d781fa2267fb22ced3b97ee0fabc7fd6c288494c4c84 = $this->env->getExtension("native_profiler");
        $__internal_b91dd69ad3d74e546c87d781fa2267fb22ced3b97ee0fabc7fd6c288494c4c84->enter($__internal_b91dd69ad3d74e546c87d781fa2267fb22ced3b97ee0fabc7fd6c288494c4c84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "LeoncioarmazemBundle:Default:index.html.twig"));

        // line 1
        echo "Hello ";
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
        echo "!
";
        
        $__internal_b91dd69ad3d74e546c87d781fa2267fb22ced3b97ee0fabc7fd6c288494c4c84->leave($__internal_b91dd69ad3d74e546c87d781fa2267fb22ced3b97ee0fabc7fd6c288494c4c84_prof);

    }

    public function getTemplateName()
    {
        return "LeoncioarmazemBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* Hello {{ name }}!*/
/* */
