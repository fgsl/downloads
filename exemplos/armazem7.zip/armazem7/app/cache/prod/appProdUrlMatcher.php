<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        // leoncioarmazem_hello
        if (0 === strpos($pathinfo, '/hello') && preg_match('#^/hello/(?P<name>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'leoncioarmazem_hello')), array (  '_controller' => 'Leoncio\\armazemBundle\\Controller\\DefaultController::indexAction',));
        }

        if (0 === strpos($pathinfo, '/armazem')) {
            // leoncioarmazem_homepage
            if ($pathinfo === '/armazem') {
                return array (  '_controller' => 'Leoncio\\armazemBundle\\Controller\\PedidoController::indexAction',  '_route' => 'leoncioarmazem_homepage',);
            }

            if (0 === strpos($pathinfo, '/armazem/editar')) {
                // leoncioarmazem_incluir
                if ($pathinfo === '/armazem/editar') {
                    return array (  '_controller' => 'Leoncio\\armazemBundle\\Controller\\PedidoController::editarAction',  '_route' => 'leoncioarmazem_incluir',);
                }

                // leoncioarmazem_alterar
                if (preg_match('#^/armazem/editar/(?P<pedido>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'leoncioarmazem_alterar')), array (  '_controller' => 'Leoncio\\armazemBundle\\Controller\\PedidoController::editarAction',));
                }

            }

            // leoncioarmazem_gravar
            if ($pathinfo === '/armazem/gravar') {
                return array (  '_controller' => 'Leoncio\\armazemBundle\\Controller\\PedidoController::gravarAction',  '_route' => 'leoncioarmazem_gravar',);
            }

        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
