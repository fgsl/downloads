<?php

namespace Leoncio\armazemBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LeoncioarmazemBundle extends Bundle
{
}
