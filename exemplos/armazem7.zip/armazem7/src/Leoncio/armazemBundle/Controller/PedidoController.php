<?php

namespace Leoncio\armazemBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class PedidoController extends Controller {

    public function indexAction() {
        $pedidos = $this->getDoctrine()->getRepository('LeoncioarmazemBundle:Pedido')->findAll();
        
        $viewData = array(
            'url' => '/armazem/editar',
            'pedidos' => $pedidos
        );
        return $this->render('LeoncioarmazemBundle:Pedido:index.html.twig', $viewData);
    }

    public function editarAction() {
    	$form = $this->createFormBuilder()
    		->add('numero', 'text')
    		->getForm();
    	
    	$viewData = array(
    			'action' => '/armazem/gravar',
    			'form' => $form->createView()
    	);    	 
    	return $this->render('LeoncioarmazemBundle:Pedido:editar.html.twig', $viewData);    }

    public function gravarAction() {
    	$http = Request::createFromGlobals();
    	$form = $http->request->get('form');
    	
    	$pedido = new Pedido();
    	$pedido->setNumero($form['numero']);
    	
    	$em = $this->getDoctrine()->getManager();
    	$em->persist($pedido);
    	$em->flush();
    	
    	$this->redirect('index');
    	 
    	return $this->forward('LeoncioarmazemBundle:Pedido:index');
    }

}
