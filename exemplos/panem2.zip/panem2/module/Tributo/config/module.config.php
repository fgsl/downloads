<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Tributo\Controller\Index' => 'Tributo\Controller\IndexController',
        ),
    ),
    'view_helpers' => array(
    		'invokables' => array(
    				'directLoop' => 'Tordo\View\Helper\DirectLoop',
    		),
    ),    
    'router' => array(
        'routes' => array(
            'tributo' => array(
                'type'    => 'Segment',
                'options' => array(
                    // Change this to something specific to your module
                    'route'    => '/tributo[/[:action[/:codigo]]]',
                    'defaults' => array(
                        // Change this value to reflect the namespace in which
                        // the controllers for your module are found
                        '__NAMESPACE__' => 'Tributo\Controller',
                        'controller'    => 'Index',
                        'action'        => 'index',
                    ),
                ),
                'may_terminate' => true,                
            ),
        ),
    ),
    'view_manager' => array(
        'template_path_stack' => array(
            'Tributo' => __DIR__ . '/../view',
        ),
    ),
);
