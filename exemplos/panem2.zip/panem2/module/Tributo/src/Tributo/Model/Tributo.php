<?php
namespace Tributo\Model;

use Distrito\Model\Distrito;
use Zend\ServiceManager\ServiceManager;
class Tributo
{
    /**
     * 
     * @var integer
     */
    public $codigo;
    /**
     * 
     * @var string
     */
    public $nome;
    /**
     * 
     * @var Distrito
     */
    public $distrito;
    
    /**
     * 
     * @var ServiceManager
     */
    private $serviceManager;
    
    
    public function __construct(ServiceManager $serviceManager)
    {
        $this->distrito = new Distrito();
        $this->serviceManager = $serviceManager;
    }
   
    public function toArray()
    {
        return get_object_vars($this);
    }
  
    // Este é exigido pelo bind() do Zend\Form  
    public function getArrayCopy()
    {
        $set = get_object_vars($this);
        $set['codigo_distrito'] = $this->distrito
        ->codigo;
        unset($set['distrito']);
        unset($set['serviceManager']);
        return $set;
    }    
   
    //Este é exigido pelo ResultSet
    public function exchangeArray($array)
    {
        $this->codigo = $array['codigo'];
        $this->nome = $array['nome'];
        $this->distrito = $this->serviceManager
        ->get('DistritoTable')
        ->getDistrito($array['codigo_distrito']);        
    }

    public function __call($method, array $args)
    {
        if ($method == 'codigo' || $method == 'nome'){
            return $this->$method;
        } else if ($method == 'codigo_distrito'){
            return $this->distrito->nome;
        }     
    }   
    
    
}