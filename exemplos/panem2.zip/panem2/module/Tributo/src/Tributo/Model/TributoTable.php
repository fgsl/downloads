<?php
namespace Tributo\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\TableGateway\TableGatewayInterface;
use Zend\ServiceManager\ServiceManager;
class TributoTable
{
    /**
     * 
     * @var TableGateway
     */
    private $tableGateway;
    private $serviceManager;
    
    public function __construct(TableGatewayInterface $tableGateway, ServiceManager $serviceManager)
    {
        $this->tableGateway = $tableGateway;
        $this->serviceManager = $serviceManager;        
    }
    
    public function saveTributo(Tributo $tributo)
    {
        $set = $tributo->getArrayCopy();
        
        if (empty($tributo->codigo)){
            $this->tableGateway->insert($set);
        } else {
            $where = array('codigo' => $tributo->codigo);
            $this->tableGateway->update($set,$where);
        }
    }
    
    public function getTributos($where = null)
    {
        return $this->tableGateway->select($where);
    }
    
    public function getTributo($codigo)
    {
        $where = array('codigo' => $codigo);
        $tributos = $this->getTributos($where);      
     
        if ($tributos->count() == 0){
            return new Tributo($this->serviceManager);
        } else {
            return $tributos->current();
        }
    }
    
    public function delete($codigo)
    {
        $where = array('codigo' => $codigo);
        
        $this->tableGateway->delete($where);
    }   
}