<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Tributo for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Tributo\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Tributo\Form\TributoForm;
use Tributo\Model\Tributo;
use Tributo\Model\TributoTable;
use Zend\Db\TableGateway\TableGateway;

class IndexController extends AbstractActionController
{
    public function indexAction()
    {
        // Altera o layout
        //$this->layout('layout/outrolayout.phtml');
        
        $tributos = $this->getTributoTable()
        ->getTributos();
        return array('tributos'=>$tributos);
    }

    public function editAction()
    {
        $codigo = $this->params('codigo');
        $tributo = $this->getTributoTable()
        ->getTributo($codigo);
        
        $form = new TributoForm();
        $form->setAttribute('action', 
        $this->url()->fromRoute('tributo',
        array('action'=>'save')));
        
        $form->setDistritos($this->getDistritoTable()
        ->getDistritos());
        
        $form->bind($tributo);
        
        return array('form'=>$form);
    }
    
    public function saveAction()
    {
        $codigo = $this->getRequest()
        ->getPost('codigo');
        $nome = $this->getRequest()->getPost('nome');
        $codigoDistrito = $this->getRequest()
        ->getPost('codigo_distrito');
        
        $tributo = new Tributo($this->getServiceLocator());
        $tributo->exchangeArray(array(
        	'codigo' => $codigo,
            'nome' => $nome,
            'codigo_distrito'=> $codigoDistrito
        ));
        
        $this->getServiceLocator()
        ->get('Log')->debug(implode('',$tributo->getArrayCopy()));
        
        $form = new TributoForm();
        $form->setDistritos($this->getDistritoTable()
        ->getDistritos());
        $form->bind($tributo);
        if (!$form->isValid()){
            $this->getServiceLocator()
            ->get('Log')->debug(print_r($form->getMessages(),true));
            
            return $this->redirect()
            ->toRoute('tributo', array(
            	'action' => edit
            )); 
        }
        
        $this->getTributoTable()->saveTributo($tributo);
        
        $this->redirect()->toRoute('tributo');
    }
    
    private function getTributoTable()
    {
        return $this->getServiceLocator()
        ->get('TributoTable');
    }
    
    private function getDistritoTable()
    {
    	return $this->getServiceLocator()
    	->get('DistritoTable');
    }
    
    
    public function deleteAction()
    {
        $codigo = $this->params('codigo');
        
        $this->getTributoTable()->delete($codigo);
        
        $this->redirect()->toRoute('tributo');
    }
}
