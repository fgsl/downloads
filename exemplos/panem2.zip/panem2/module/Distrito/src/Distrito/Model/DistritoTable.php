<?php
namespace Distrito\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\TableGateway\TableGatewayInterface;
class DistritoTable
{
    /**
     * 
     * @var TableGateway
     */
    private $tableGateway;
    
    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;        
    }
    
    public function saveDistrito(Distrito $distrito)
    {
        $set = $distrito->getArrayCopy();
        
        if (empty($distrito->codigo)){
            $this->tableGateway->insert($set);
        } else {
            $where = array('codigo' => $distrito->codigo);
            $this->tableGateway->update($set,$where);
        }
    }
    
    public function getDistritos($where = null)
    {
        return $this->tableGateway->select($where);
    }
    
    public function getDistrito($codigo)
    {
        $where = array('codigo' => $codigo);
        $distritos = $this->getDistritos($where);      
     
        if ($distritos->count() == 0){
            return new Distrito();
        } else {
            return $distritos->current();
        }
    }
    
    public function delete($codigo)
    {
        $where = array('codigo' => $codigo);
        
        $this->tableGateway->delete($where);
    }   
}