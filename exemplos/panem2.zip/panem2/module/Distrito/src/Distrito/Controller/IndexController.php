<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Distrito for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Distrito\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Distrito\Form\DistritoForm;
use Distrito\Model\Distrito;
use Distrito\Model\DistritoTable;
use Zend\Db\TableGateway\TableGateway;

class IndexController extends AbstractActionController
{
    public function indexAction()
    {
        // Altera o layout
        //$this->layout('layout/outrolayout.phtml');
        
        $distritos = $this->getDistritoTable()
        ->getDistritos();
        return array('distritos'=>$distritos);
    }

    public function editAction()
    {
        $codigo = $this->params('codigo');
        $distrito = $this->getDistritoTable()
        ->getDistrito($codigo);
        
        $form = new DistritoForm();
        $form->setAttribute('action', 
        $this->url()->fromRoute('distrito',
        array('action'=>'save')));
        $form->bind($distrito);
        
        return array('form'=>$form);
    }
    
    public function saveAction()
    {
        $codigo = $this->getRequest()->getPost('codigo');
        $nome = $this->getRequest()->getPost('nome');
        
        $distrito = new Distrito();
        $distrito->codigo = $codigo;
        $distrito->nome = $nome;
        
        $this->getServiceLocator()
        ->get('Log')->debug(implode('',$distrito->getArrayCopy()));
        
        $form = new DistritoForm();
        $form->bind($distrito);
        if (!$form->isValid()){
            return $this->redirect()
            ->toRoute('distrito', array(
            	'action' => edit
            )); 
        }
        
        $this->getDistritoTable()->saveDistrito($distrito);
        
        $this->redirect()->toRoute('distrito');
    }
    
    private function getDistritoTable()
    {
        return $this->getServiceLocator()
        ->get('DistritoTable');
    }
    
    public function deleteAction()
    {
        $codigo = $this->params('codigo');
        
        $this->getDistritoTable()->delete($codigo);
        
        $this->redirect()->toRoute('distrito');
    }
    
    
    
    
    
    
    
    
    
}
