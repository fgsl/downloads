<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Toca for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Hobbit\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Hobbit\Form\Toca as TocaForm;
use Hobbit\Model\Toca;
use Hobbit\Model\TocaTable;

class TocaController extends AbstractActionController
{
    public function indexAction()
    {
        $tocaTable = $this->getTocaTable();
        $records = $tocaTable->fetchAll();
        return array('records' => $records);
    }

    public function editAction()
    {
        $id = $this->params('id', null);
        
        if (isset($_SESSION['form'])) {
            $form = $_SESSION['form'];
            unset($_SESSION['form']);
        } else {
            $form = new TocaForm();
        }        

        $form->setAttribute('action', $this->
            url()->fromRoute('toca',array(
        	   'action'=>'save'
        )));        
        $form->setId($id, $this->getServiceLocator());
        
        return array('form' => $form);
    }
    
    public function saveAction()
    {
        $toca = new Toca();
        $toca->exchangeArray((array)$this->getRequest()
        ->getPost());
        
        $form = new TocaForm();
        $form->setInputFilter($toca->getInputFilter());
        $form->bind($toca);
        
        if (!$form->isValid()){
            $_SESSION['form'] = $form;
            
            return $this->redirect()->toRoute('toca',array(
                'action'=>'edit'
            ));
        }
        
        $tocaTable = $this->getTocaTable();
        $tocaTable->save($toca);
        
        $this->redirect()->toRoute('toca');                
    }
    
    public function deleteAction()
    {
        $id = $this->params('id', null);
        $tocaTable = $this->getTocaTable();
        $tocaTable->delete($id);
        
        $this->redirect()->toRoute('toca');
    }
    
    
    /**
     * @return TocaTable
     */
    private function getTocaTable()
    {
        return $this->getServiceLocator()
        ->get('TocaTable');
    }
    
    
    
    
    
    
    
    
    
    
    
}
