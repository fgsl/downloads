<?php
namespace Hobbit\Model;

use Zend\InputFilter\InputFilter;
use Zend\Filter\FilterChain;
use Zend\InputFilter\Input;
use Zend\Filter\Digits;
use Zend\Filter\Int;
use Zend\Validator\ValidatorChain;
use Zend\I18n\Filter\Alnum;
use Zend\Validator\StringLength;
use Zend\Filter\StringTrim;
use Zend\ServiceManager\ServiceManager;
class Hobbit
{
    /**
     * 
     * @var integer
     */
    public $id = null;
    
    /**
     * 
     * @var string
     */
    public $nome = null;
    
    /**
     * 
     * @var Toca
     */
    public $toca = NULL;

    /**
     * 
     * @var InputFilter
     */
    private $inputFilter = null;
    
    /**
     * 
     * @var ServiceManager
     */
    private $serviceManager = null;

    public function __construct(ServiceManager $serviceManager)
    {
        $this->serviceManager = $serviceManager;
    }
    
    
    public function exchangeArray(array $array)
    {
        $this->id = isset($array['id']) ? $array['id'] : null;
        $this->nome = isset($array['nome']) ? $array['nome'] : null;
        
        $idToca = isset($array['id_toca']) ? $array['id_toca'] : null;
        
        $tocaTable = $this->serviceManager->get('TocaTable');
        
        $toca = $tocaTable->fetchOne($idToca);
        
        $this->toca = $toca;
        if ($this->toca == NULL) {
            $this->toca = new Toca();
        }
        $this->toca->id = $idToca;
         
    }
    
    public function toArray()
    {
        $array = get_object_vars($this);
        
        return $array;
    }

    public function getInputFilter()
    {
        if ($this->inputFilter == NULL){
            $inputFilter = new InputFilter();
            
            $input = new Input('id');
            $input->setAllowEmpty(TRUE);
            
            $filterChain = new FilterChain();
            $filterChain->attach(new Int());
            
            $input->setFilterChain($filterChain);
            
            $validatorChain = new ValidatorChain();
            $validatorChain->addValidator(new \Zend\I18n\Validator\Int());
            $validatorChain->addValidator(new \Zend\Validator\Digits());
            
            $input->setValidatorChain($validatorChain);
            
            $inputFilter->add($input);
            
            $input = new Input('nome');
            
            $filterChain = new FilterChain();
            $filterChain->attach(new Alnum());
            $filterChain->attach(new StringTrim());
            
            $input->setFilterChain($filterChain);
            
            $validatorChain = new ValidatorChain();
            $validatorChain->addValidator(new StringLength(array(
            	'min'=>3,
                'max'=>30
            )));
            
            $input->setValidatorChain($validatorChain);
            
            $inputFilter->add($input);
            
            $input = new Input('id_toca');
            
            $filterChain = new FilterChain();
            $filterChain->attach(new Int());
            
            $input->setFilterChain($filterChain);
            
            $validatorChain = new ValidatorChain();
            //$validatorChain->addValidator(new \Zend\I18n\Validator\Int());
            $validatorChain->addValidator(new \Zend\Validator\Digits());
            
            $input->setValidatorChain($validatorChain);
            
            $inputFilter->add($input);
            
            
            $this->inputFilter = $inputFilter;
        }
        return $this->inputFilter;
    }
    
    public function getArrayCopy()
    {
        $array = get_object_vars($this);
        $array['id_toca'] = $this->toca->id;
        
        return $array;
    }
    
    
    
    
    
}

?>