<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Editar pedido</title>
</head>
<body>
<form action="<?=$this->action?>" method="post">
Número: <input type="text" name="numero">
<input type="submit" value="gravar">
</form>
</body>
</html> 