<?php
require 'functions.php';

$codigo = isset($_POST['codigo']) ?
$_POST['codigo'] : NULL;
$nome = isset($_POST['nome']) ? 
$_POST['nome'] : NULL ;

if (empty($codigo)){
	gravarAluno($nome);
} else {
	alterarAluno($codigo,$nome);
}


header('Location: index.php');




