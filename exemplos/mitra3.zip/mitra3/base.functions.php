<?php
/**
 *
 * @param array $registro
 * @return boolean
 */
function gravarRegistro(array $registro)
{
	$connection = mysql_connect('localhost','root','admin');
	if (!$connection) return FALSE;
	mysql_select_db('mitra', $connection);
	
	$sql = <<<SQL
INSERT INTO alunos(codigo,nome) VALUES ('$registro[0]','$registro[1]');	
SQL;

	$result = mysql_query($sql,$connection);
	
	mysql_close($connection);
	return $result;
}	

/**
 *
 * @param string $codigo
 * @param string $nome
 * @param boolean $excluir
 */
function alterarRegistro($codigo, $nome = NULL, $excluir = FALSE)
{
	if ($excluir){
		$sql = <<<SQL
DELETE FROM alunos WHERE codigo = 
'$codigo';
SQL;
				
	} else {
		$sql = <<<SQL
UPDATE alunos SET nome = '$nome'
 WHERE codigo = '$codigo';
SQL;
 		
	}

	$connection = mysql_connect('localhost','root','admin');
	if (!$connection) return FALSE;
	mysql_select_db('mitra', $connection);
	
	$result = mysql_query($sql,$connection);
	
	mysql_close($connection);
	return $result;
}
