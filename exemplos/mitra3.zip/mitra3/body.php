<?php
$connection = mysql_connect('localhost','root','admin');
	
if ($connection) {
	mysql_select_db('mitra', $connection);
	
	$sql = <<<SQL
SELECT * FROM alunos;
SQL;
		
	$result = mysql_query($sql,$connection);

	while($registro =
	mysql_fetch_array($result, MYSQL_NUM))
	{
		$codigo = $registro[0];
		$nome = $registro[1];
		$urlAlterar = "edit.php?codigo=$codigo";
		$urlExcluir = "delete.php?codigo=$codigo";

		$template = <<<TEMPLATE
<tr>
	<td><a href="$urlAlterar">$codigo</a></td>
	<td>$nome</td>
	<td><a href="$urlExcluir">Excluir</a></td>
</tr>
TEMPLATE;
		echo $template;	
	}
	mysql_close($connection);
} 