<?php
$codigo = isset($_GET['codigo']) ?
$_GET['codigo'] : NULL;

$nome = '';

if (!is_null($codigo))
{
	$connection = mysql_connect('localhost','root','admin');
	
	if ($connection) {
		mysql_select_db('mitra', $connection);
	
		$sql = <<<SQL
SELECT * FROM alunos WHERE codigo = '$codigo';
SQL;
	
		$result = mysql_query($sql,$connection);
		
		$registro = mysql_fetch_array($result,MYSQL_ASSOC);
		
		$nome = $registro['nome'];
	}
}