// CAMADA DE MODELO
function Contato()
{
	this.nome;
	this.telefone;
	
	this.adicionar = function(nome,telefone)
	{
		if (!this.validar(nome,telefone)) return;	
		
		var table = getFirstChild('table');
		var tbody = table.childNodes[3];
		
		var tr = createTagElement('tr',null);
		
		var tdNome = createTagElement('td',nome);
		
		var tdTelefone = createTagElement('td',telefone);
		
		var tdButton1 = createTagElement('button', 'Editar');
		tdButton1.
		setAttribute('onclick','editar(this)');
		
		var tdButton2 = createTagElement('button', 'Excluir');
		tdButton2.
		setAttribute('onclick','excluir(this)');	
		
		var td = document.createElement('td');
		td.appendChild(tdButton1);
		td.appendChild(tdButton2);
		
		var childNodes = [tdNome, tdTelefone, td];
		appendChilds(tr, childNodes);
		tbody.appendChild(tr);		
	};
	
	this.editar = function(button)
	{
		var td = button.parentNode;
		var tr = td.parentNode;

		var nome = tr.firstChild.innerHTML;
		var telefone = tr.childNodes[1].innerHTML;
		
		nome = getValue('nome',true, nome);
		telefone = getValue('telefone', true, telefone);

		if (!this.validar(nome,telefone)) return;
		
		tr.firstChild.innerHTML = nome;
		tr.childNodes[1].innerHTML = telefone;		
	};
	
	this.excluir = function(button)
	{
		var td = button.parentNode;
		var tr = td.parentNode;
		var tbody = tr.parentNode;
		
		tbody.removeChild(tr);		
	};
	
	/**
	 * string nome
	 * string telefone 
	 */
	this.validar = function(nome, telefone)
	{
		if (nome == null || telefone == null)
		{
			window.alert('Você tem de digitar os dois valores!')
			return false;
		}
		return true;
	};	
}

// CAMADA DE CONTROLE

function adicionar()
{
	var nome = getValue('nome', false);
	var telefone = getValue('telefone', false);
	
	var contato = new Contato();
	contato.adicionar(nome, telefone);
}

function editar(sender)
{
	var contato = new Contato();
	contato.editar(sender);
}

function excluir(sender)
{
	var contato = new Contato();
	contato.excluir(sender);
}


// BOOTSTRAP
function iniciar()
{
	buttons = document.getElementsByTagName('button');
	buttonNovoContato = buttons[0];
	buttonNovoContato.
	setAttribute('onclick','adicionar()');
}


function getValue(field, edit, value)
{
	var text = edit ? "Altere o " : "Digite o ";
	return window.prompt(text + field, value);
}

function getFirstChild(tag)
{
	var parent = document.
	getElementsByTagName(tag);
	return parent[0];
}

function createTagElement(tag,innerHTML)
{
	var element = document.createElement(tag);
	if (innerHTML != null){
		element.innerHTML = innerHTML;
	}
	return element;
}

function appendChilds(parent, childNodes)
{
	for(var i=0;i<childNodes.length;i++){
		parent.appendChild(childNodes[i]);
	}
}
