<?php

use Zend\EventManager\Event;
use Zend\EventManager\EventManager;
class Bombeiro2
{
    public function apagarIncendio(Event $event)
    {
        $subject = $event->getTarget();
        
    	while(($temperatura = $subject->getTemperatura()) > 40)
    	{
    	    $subject->setTemperatura($temperatura - 1);
    	    echo 'Baixando temperatura para ' . $subject
    	    ->getTemperatura() . '<br>';
    	}
    }
}

?>