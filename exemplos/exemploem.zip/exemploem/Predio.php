<?php

class Predio implements \SplSubject
{
    private $observers = array();
    private $temperatura = 0;
    private $notified = false;

    public function detach(SplObserver $observer)
    {
    	if (in_array($this->observers, $observer))
    	{
    	    foreach($this->observers as $index => 
    	        $observerStored)
    	    {
    	        if ($observer === $observerStored){
    	            unset($this->observers[$index]);
    	            break;
    	        }    	            
    	    }
    	}
    }

    public function attach(SplObserver $observer)
    {
    	$this->observers[] = $observer;
    }

    public function notify()
    {
    	foreach($this->observers as $observer)
    	{
    	    $observer->update($this);
    	}
    }
    
    public function setTemperatura($temperatura)
    {
        $this->temperatura = $temperatura;
        
        if ($this->temperatura > 40 && !$this->notified)
        {
            $this->notified = true;
            $this->notify();
            $this->notified = false;
        }        
    }
    
    public function getTemperatura()
    {
        return $this->temperatura;
    }   
}

?>