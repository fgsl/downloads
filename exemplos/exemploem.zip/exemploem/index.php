<?php
spl_autoload_register(function($class){
    $file = $class . '.php';
    if (file_exists($file))
        require $file;
});

$predio = new Predio();

$predio->attach(new Bombeiro());

$predio->setTemperatura(50);