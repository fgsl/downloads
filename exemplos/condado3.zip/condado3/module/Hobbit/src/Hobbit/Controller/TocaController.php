<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Toca for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Hobbit\Controller;

use Coiote\Controller\ControllerAbstract;

class TocaController extends ControllerAbstract
{ 
    protected $formClass = 'Hobbit\Form\Toca';
    
    protected $modelClass = 'Hobbit\Model\Toca';
    
    protected $module = 'toca';
    
    public function getTable()
    {
        return $this->getServiceLocator()
        ->get('TocaTable');
    }
    
}
