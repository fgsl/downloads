<?php
namespace Hobbit\Model;

use Zend\Validator\Digits;
use Zend\Filter\Int;
use Zend\I18n\Filter\Alnum;
use Zend\Validator\StringLength;
use Zend\Filter\StringTrim;
use Coiote\Model\ModelAbstract;
use Coiote\Filter\Corintiano;
use Coiote\Validator\HobbitName;

class Hobbit extends ModelAbstract
{
    /**
     * 
     * @var integer
     */
    public $id = null;
    
    /**
     * 
     * @var string
     */
    public $nome = null;
    
    /**
     * 
     * @var Toca
     */
    public $toca = NULL;
    
    public function __construct(array $tables = null)
    {        
        parent::__construct($tables);
        $this->attributes = array(
        	'id' => array(
        	   'allowEmpty' => TRUE,
        	   'filters' => array(
        		  new Int()
        	   ),
        	   'validators' => array(
        	   	   new Digits() 
        	   )  
            ),
            'nome' => array(
                'allowEmpty' => FALSE,
                'filters' => array(
                    new Corintiano(),
                    new StringTrim()
                ),
                'validators' => array(
                    new StringLength(array(
                    	'min' => 3,
                        'max' => 30
                    )),
                    new HobbitName()
                )
            ),
            'id_toca' => array(
                'allowEmpty' => FALSE,
                'filters' => array(
                    new Int()
                ),
                'validators' => array(
                    new Digits()
                )
            ),            
        );    
    }
   
    public function exchangeArray(array $array)
    {
        $this->id = isset($array['id']) ? $array['id'] : null;
        $this->nome = isset($array['nome']) ? $array['nome'] : null;
        
        $idToca = isset($array['id_toca']) ? $array['id_toca'] : null;
        
        if (!$this->toca instanceof Toca){
            $tocaTable = $this->tables['TocaTable'];
            $toca = $tocaTable->fetchOne($idToca);
            $this->toca = $toca;
        }                     
        
        if ($this->toca == NULL) {
            $this->toca = new Toca();
        }
        $this->toca->id = $idToca;
         
    }    
    
    public function getArrayCopy()
    {
        $array = get_object_vars($this);
        $array['id_toca'] = $this->toca->id;
        
        return $array;
    }
    
    
    
    
    
}