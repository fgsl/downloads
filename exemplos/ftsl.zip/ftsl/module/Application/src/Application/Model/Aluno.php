<?php
namespace Application\Model;

class Aluno
{
    public $matricula = NULL;
    public $nome = NULL;
    
    public function exchangeArray(array $data)
    {
        $this->matricula = $data['matricula'];
        $this->nome = $data['nome'];
    }
    
    public function toArray()
    {
        return get_object_vars($this);
    }
    
    public function getArrayCopy()
    {
        return $this->toArray();
    }
    
    
    
}