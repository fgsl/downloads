<?php
namespace Application\Model;

use Zend\Db\TableGateway\TableGateway;
class AlunoTable
{
    /**
     * 
     * @var TableGateway
     */
    private $tableGateway;
    
    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }
    
    public function save(Aluno $aluno)
    {
        $set = $aluno->toArray();
        
        // novo aluno
        if (empty($aluno->matricula)){
            $this->tableGateway->insert($set);
        // aluno existente    
        } else {
            $where = array('matricula' => $aluno->matricula);
            $this->tableGateway->update($set,$where);
        }
    }
    
    public function delete($matricula)
    {
        $where = array('matricula' => $matricula);
        $this->tableGateway->delete($where);
    }
    
    public function select($where = NULL)
    {
        return $this->tableGateway->select($where);
    }
    
    public function find($matricula)
    {
        $where = array('matricula' => $matricula);
        $rowSet = $this->select($where);
        if (empty($rowSet)){
            return new Aluno();
        } else {
            return $rowSet->current();
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}