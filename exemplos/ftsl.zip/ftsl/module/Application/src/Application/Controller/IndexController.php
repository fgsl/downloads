<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2013 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Application\Form\Aluno as AlunoForm;
use Application\Model\Aluno;

class IndexController extends AbstractActionController
{
    public function indexAction()
    {
        $alunoTable = $this->getServiceLocator()
        ->get('AlunoTable');
        
        $alunos = $alunoTable->select();
        
        return array('alunos'=>$alunos);
    }
    
    public function editAction()
    {
        $matricula = $this->params('matricula');
        
        if (empty($matricula)) {
            $aluno = new Aluno();
        } else {
            $alunoTable = $this->getServiceLocator()
            ->get('AlunoTable');
            $aluno = $alunoTable->find($matricula);
        }        
        
        $form = new AlunoForm();
        $form->setAttribute('action', 
            $this->url()->fromRoute('application',
                array(
        	       'action' => 'save'
                )	
        ));
        $form->bind($aluno);
        
        return array('form' => $form);        
    }
    
    public function saveAction()
    {
        $matricula = $this->getRequest()->getPost('matricula');
        $nome = $this->getRequest()->getPost('nome');
        
        $aluno = new Aluno();
        $aluno->matricula = $matricula;
        $aluno->nome = $nome;
        
        $alunoTable = $this->getServiceLocator()
        ->get('AlunoTable');
        
        $alunoTable->save($aluno);
        
        return $this->redirect()->toRoute('application');
    }
    
    public function deleteAction()
    {
        $matricula = $this->params('matricula');
        
        $alunoTable = $this->getServiceLocator()
        ->get('AlunoTable');
        
        $alunoTable->delete($matricula);
        
        return $this->redirect()->toRoute('application');
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
