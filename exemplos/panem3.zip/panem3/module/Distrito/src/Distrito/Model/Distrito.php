<?php
namespace Distrito\Model;

use Tordo\Model\AbstractModel;
class Distrito extends AbstractModel
{
    public $codigo;
    public $nome;
   
    public function toArray()
    {
        return get_object_vars($this);
    }
  
    // Este é exigido pelo bind() do Zend\Form  
    public function getArrayCopy()
    {
        $set = get_object_vars($this);
        unset($set['serviceManager']);
        return $set;
    }    
   
    //Este é exigido pelo ResultSet
    public function exchangeArray($array)
    {
        $this->codigo = $array['codigo'];
        $this->nome = $array['nome'];
    }    
}