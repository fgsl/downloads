<?php
namespace Tributo\Form;

use Zend\Form\Form;
use Zend\Form\Element\Text;
use Zend\Form\Element\Hidden;
use Zend\Form\Element\Submit;
use Zend\Form\Element\Select;

class TributoForm extends Form
{
    public function __construct($name = 'tributo', array $options = array())
    {
        parent::__construct($name,$options);
        
        $this->setAttribute('method', 'post');
        
        $elementOrFieldset = new Text('nome');
        $elementOrFieldset->setLabel('Nome:');
        
        $this->add($elementOrFieldset);

        $elementOrFieldset = new Select('codigo_distrito');
        $elementOrFieldset->setLabel('Distrito:');
        
        $this->add($elementOrFieldset);        
        
        $elementOrFieldset = new Hidden('codigo');
        
        $this->add($elementOrFieldset);
        
        $elementOrFieldset = new Submit('gravar');
        $elementOrFieldset->setValue('gravar');
        
        $this->add($elementOrFieldset);
    }
    
    public function setDistritos($distritos)
    {
        $options = array();
        foreach($distritos as $distrito){
            $options[$distrito->codigo] =
            $distrito->nome;
        }
        $this->get('codigo_distrito')
        ->setValueOptions($options);   
    }
    
    
    
    
    
    
    
    
    
    
}