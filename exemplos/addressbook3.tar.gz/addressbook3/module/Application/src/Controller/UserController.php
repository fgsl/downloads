<?php
namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Application\Model\Contato;
use Zend\Session\Storage\SessionStorage;
use Zend\Session\SessionManager;

class UserController extends AbstractActionController
{
	private $serviceManager;
	
	public function __construct($serviceManager)
	{
		$this->serviceManager = $serviceManager;
		$sessionManager = $serviceManager->get(SessionManager::class);
		$sessionManager->start();
		
	}

    public function userAction()
    {
        $codigo = $this->params('codigo');
        $contato = new Contato($this->serviceManager);
        $contato->getFromRequest($codigo);
        return new ViewModel(array(
            'contato' => $contato
        ));

        
    }

    public function editAction()
    {
        $codigo = $this->params('codigo');
        $contato = new Contato($this->serviceManager);
        $contato->getFromRequest($codigo);
        
        return new ViewModel(array(
            'contato' => $contato
        ));
    }

    public function catalogoAction()
    {
        return new ViewModel([
        	'serviceManager' => $this->serviceManager		
		]);
    }

    public function saveAction()
    {
        $codigo = $this->getRequest()->getPost('codigo');
        $contato = new Contato($this->serviceManager);
        $sucesso = $contato->gravar($codigo);
        
        if (!$sucesso){
            $_SESSION['mensagemDeErro'] = $contato->getMensagemDeErro();
            if ($contato->getMensagemDeErro() == 'cancel'){
                return $this->redirect()->toRoute('home');
            }
            return $this->redirect()->toRoute('application',array('controller'=>'user','action' => 'user-error'));
        }
        
        return $this->redirect()->toRoute('application',array('controller'=>'user','action' => 'catalogo'));
    }

    public function removerAction()
    {
        $codigo = $this->params('codigo');
        $contato = new Contato($this->serviceManager);
        $contato->remover($codigo);
        return $this->redirect()->toRoute('application',array('controller'=>'user','action' => 'catalogo'));
    }

    public function userErrorAction()
    {   return new ViewModel(array(
            'mensagemDeErro' => $_SESSION['mensagemDeErro']
            ));
    }
}