function editar(codigo){
	window.location ="http://localhost:88/addressbook3/application/user/user/"+ codigo;
}
function remover(codigo){
	window.location ="http://localhost:88/addressbook3/application/user/remover/"+ codigo;
}