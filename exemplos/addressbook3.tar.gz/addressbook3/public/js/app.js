
        var loadFile = function(event) {
	    var output = document.getElementById('output');
	    output.src = URL.createObjectURL(event.target.files[0]);
	  };


function validar_form() {
	var saudacao = cadastro.saudacao.value;
	var titulo = cadastro.titulo.value;
	var prenome = cadastro.prenome.value;
	var nomeDoMeio = cadastro.nomeDoMeio.value;
	var sobrenome = cadastro.sobrenome.value;
	var empresa = cadastro.empresa.value;
	var unidade = cadastro.unidade.value;
	var nomeDeExibicao = cadastro.nomeDeExibicao.value;
	var tituloDoTrabalho = cadastro.tituloDoTrabalho.value;
	var aniversario = cadastro.aniversario.value;
	var telefone = cadastro.telefone.value;
	var celular = cadastro.celular.value;
	var fax = cadastro.fax.value;
	var telefonepar = cadastro.telefonepar.value;
	var celularpar = cadastro.celularpar.value;
	var faxpar =  cadastro.faxpar.value;
	var email = cadastro.email.value;
	var emailpar = cadastro.emailpar.value;
	var web = cadastro.web.value;
	var rua = cadastro.rua.value;
	var complemento = cadastro.complemento.value;
	var estado = cadastro.estado.value;
	var cep = cadastro.cep.value;
	var comentario = cadastro.comentario.value;
	var cidade = cadastro.cidade.value;
	var foto = cadastro.foto.value;

	
	if (saudacao == "") {
		alert('Selecione uma saudação!');
		cadastro.saudacao.focus();
		return false;
		}
	if (titulo == "") {
		alert('Informe um titulo!');
		cadastro.titulo.focus();
		return false;
		}
	if (prenome == "") {
		alert('Informe um prenome!');
		cadastro.prenome.focus();
		return false;
		}
	if (nomeDoMeio == "") {
		alert('Informe um nome do meio!');
		cadastro.nomeDoMeio.focus();
		return false;
		}
	if (sobrenome == "") {
		alert('Informe seu sobrenome!');
		cadastro.sobrenome.focus();
		return false;
		}
	if (empresa == "") {
		alert('Informe sua empresa!');
		cadastro.empresa.focus();
		return false;
		}
	if (unidade == "") {
		alert('Informe sua unidade!');
		cadastro.unidade.focus();
		return false;
		}
	if (nomeDeExibicao == "") {
		alert('Informe seu nome de exibição!');
		cadastro.nomeDeExbibicao.focus();
		return false;
		}
	if (tituloDoTrabalho == "") {
		alert('Informe seu titulo de trabalho!');
		cadastro.tituloDoTrabalho.focus();
		return false;
		}
	if (aniversario == "") {
		alert('Informe seu aniversário: DD/MM/AAAA!');
		cadastro.aniversario.focus();
		return false;
		}
	if (telefone == "") {
		alert('Informe seu telefone!');
		cadastro.telefone.focus();
		return false;
		}
	if (celular == "") {
		alert('Informe seu celular!');
		cadastro.celular.focus();
		return false;
		}
	if (fax == "") {
		alert('Informe seu fax!');
		cadastro.fax.focus();
		return false;
		}
	if (telefonepar == "") {
		alert('Informe seu telefone particular!');
		cadastro.telefonepar.focus();
		return false;
		}
	if (celularpar == "") {
		alert('Informe seu celular particular!');
		cadastro.celularpar.focus();
		return false;
		}
	if (faxpar == "") {
		alert('Informe seu fax particular!');
		cadastro.faxpar.focus();
		return false;
		}
	if (email == "") {
		alert('Informe seu email!');
		cadastro.email.focus();
		return false;
		}
	if (emailpar == "") {
		alert('Informe seu email particular!');
		cadastro.emailpar.focus();
		return false;
		}
	if (web == "") {
		alert('Informe seu endereço web!');
		cadastro.web.focus();
		return false;
		}
	if (rua == "") {
		alert('Informe sua rua!');
		cadastro.rua.focus();
		return false;
		}
	if (complemento == "") {
		alert('Informe seu complemento!');
		cadastro.complemento.focus();
		return false;
		}
	if (estado == "") {
		alert('Informe seu estado!');
		cadastro.estado.focus();
		return false;
		}
	if (cep == "") {
		alert('Informe seu CEP!');
		cadastro.cep.focus();
		return false;
		}
	if (cidade == "") {
		alert('Informe sua cidade!');
		cadastro.cidade.focus();
		return false;
		}
	if (pais == "") {
		alert('Informe seu país!');
		cadastro.pais.focus();
		return false;
		}
	if (codigo== "") {
	if (foto == "") {
		alert('Você precisa anexar uma foto!');
		cadastro.foto.focus();
		return false;
		}
	}
	return true;
}