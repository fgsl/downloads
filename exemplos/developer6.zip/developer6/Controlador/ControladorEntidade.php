<?php
namespace Controlador;

require '..' . DIRECTORY_SEPARATOR . 'autoload.php';

class ControladorEntidade
{
    private $requisicao = NULL;
    private $dados = NULL;
    
    public function despachar(array $requisicao, array $dados)
    {
        $this->requisicao = $requisicao;
        $this->dados = $dados;
        $metodo = $requisicao['metodo'];
        $this->$metodo();
        header('Location: ../index.php');
    }
    
    private function getEntidade()
    {
        return 'Entidade\\' . 
        ucfirst($this->requisicao['cadastro']);
    }
    
    
    private function apagar()
    {
        $class = $this->getEntidade();
        call_user_func(array($class,'apagar'),$this->requisicao['chave']);        
    }
    
    private function gravar()
    {
        $class = $this->getEntidade();
        call_user_func(array($class,'gravar'),$this->dados);       
    }
}

$controladorEntidade = new ControladorEntidade();
$controladorEntidade->despachar($_GET,$_POST);






