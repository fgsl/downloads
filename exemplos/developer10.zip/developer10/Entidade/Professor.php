<?php
namespace Entidade;

/**
 * 
 * @author fgsl
 *
 */
class Professor extends EntidadeAbstrata
{
    /**
     * 
     * @var integer
     */
    protected $codigo;
    /**
     * 
     * @var string
     */
    protected $nome;
    
    protected static $tabela = 'professores';
    
    protected static $form = 'form_professor.php';
    
    public static $codigoProfessor;    

    public static function getChave()
    {
        return 'codigo';
    }
    
    public static function getSelectOptions($value = NULL, $label = NULL, $sql = NULL)
    {
        $codigoProfessor = self::$codigoProfessor;
        $sql = <<<SQL
         SELECT * FROM disciplina_professor 
 INNER JOIN disciplinas ON 
 disciplina_professor.codigo_disciplina=disciplinas.codigo
 WHERE disciplina_professor.codigo_professor=$codigoProfessor;
SQL;
        
        $value = 'codigo';
        $label = 'nome';
        return parent::getSelectOptions($value,$label,$sql);
    
    }
    
    public static function adicionarDisciplina(
	$codigoDisciplina,$codigoProfessor)
	{
	    $sql = <<<SQL
INSERT INTO
disciplina_professor(codigo_disciplina,codigo_professor)
VALUES ($codigoDisciplina,$codigoProfessor)
SQL;
	    parent::executarSql($sql, 'Não conseguiu incluir');	    
	}
	
	public static function removerDisciplina(
	    $codigoDisciplina,$codigoProfessor)
	{
	    $sql = <<<SQL
DELETE FROM
disciplina_professor
WHERE codigo_disciplina=$codigoDisciplina AND
    codigo_professor=$codigoProfessor
SQL;
	    parent::executarSql($sql, 'Não conseguiu excluir');
	}
	
    
    
    
    
    
    
    
    
    
    
    
    
    
}

?>