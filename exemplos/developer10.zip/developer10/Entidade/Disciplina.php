<?php
namespace Entidade;

class Disciplina extends EntidadeAbstrata
{
    protected static $tabela = 'disciplinas';

    public static function getChave()
    {
    	return 'codigo';
    }
    
    public static function getSelectOptions($value = NULL, $label = NULL, $sql = NULL)
    {
        $sql = 'SELECT * FROM disciplinas';
        $value = 'codigo';
        $label = 'nome';
        return parent::getSelectOptions($value,$label,$sql);
        
    }
    
    public static function apagar($chave)
    {
        $chave = (integer) $chave;

        $sql = array(
            "DELETE FROM disciplinas WHERE codigo=$chave",
            "DELETE FROM disciplina_professor WHERE
                codigo_disciplina=$chave"
            );
        self::executarSql($sql, 'Não conseguiu excluir');
    }    
    
    
    
    
    
    
    
    
}

?>