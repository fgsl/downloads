<?php
namespace Util;

class Tradutor
{
    public static $localidade = 'pt_BR';
    
    public function __invoke($texto)
    {
        return $this->traduzir($texto);   
    }    
    
    public function traduzir($texto)
    {
        $filename = __DIR__ . DIRECTORY_SEPARATOR .
        'traducao.' . self::$localidade . '.xml';
        
        $xml = new \SimpleXMLElement($filename,null,true);
        
        $children = $xml->children();

        $traducao = $texto;
        foreach($children as $child)
        {
            if ($child->getName() == $texto)
            {
                $traducao = $child;
                break;
            }
        }      
        
        return $traducao;
    }
}

?>