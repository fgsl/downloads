<?php

abstract class Pessoa
{
   protected $cpf;
   protected $rg; 
   protected $nome;

   public function __construct($cpf = null,$rg = null
        ,$nome = null)
   {
       $this->cpf = $cpf;
       $this->rg = $rg;
       $this->nome = $nome;
   }
   
   public function __destruct()
   {
       echo "<br>Uma pessoa faleceu!";
   }
   
   public function __set($attribute,$value)
   {
       $this->$attribute = $value;
   }
   
   public function __get($attribute)
   {
       return isset($this->$attribute) ? $this->$attribute : null;
   }
   
   public function __toString()
   {
       return "RG: {$this->rg} CPF: {$this->cpf} Nome: {$this->nome}<br>";
   }
   
   
   
   
   
   
   
   
   
   
   
   
   
   
}

?>