<?php
require_once 'Descricao.php';
class Produto
{
    use Descricao;
}

?>