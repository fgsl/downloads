<?php
require 'Pessoa.php';
require_once 'Descricao.php';
class PessoaFisica extends Pessoa
{
    use Descricao;
}

?>