<?php
require 'Pessoa.php';

$pessoa1 = new Pessoa(1,1,'Uno');

$pessoa2 = clone $pessoa1;

$pessoa2->rg = 2;

echo $pessoa1->rg;