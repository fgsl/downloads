<?php
require 'PessoaFisica.php';
require 'Produto.php';

$pessoaFisica = new PessoaFisica();
$produto = new Produto();

echo $pessoaFisica->exibirDescricao() . '<br>';
echo $produto->exibirDescricao() . '<br>';