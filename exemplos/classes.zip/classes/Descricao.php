<?php

trait Descricao
{
    public function exibirDescricao()
    {
        echo 'descricao';
    }    
}

?>