<?php
require 'Pessoa.php';

//$pessoa = new Pessoa();
$pessoa = new Pessoa('12345','5678','Clementino');
$pessoa->nome = 'Diamantino';

//echo $pessoa->rg;
//echo $pessoa->endereco;

echo $pessoa;