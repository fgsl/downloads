<?php

class Application_Model_Promocao extends Fgsl_Model_Abstract
{


}

