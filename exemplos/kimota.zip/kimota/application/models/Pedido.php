<?php

class Application_Model_Pedido extends Fgsl_Model_Abstract
{
	public function gravar($cabecalho, $carrinho)
	{		
		$item = new Application_Model_Item();
		
		$this->getDbTable()->getAdapter()->beginTransaction();
		try {
			$this->getDbTable()->insert($cabecalho);
			$idPedido = $this->getDbTable()->getAdapter()->lastInsertId($this->getDbTable()->getName(),'id');
			$zc = new Zend_Currency();
			foreach ($carrinho as $idProduto => $dadosProduto)
			{			
				$preco = $dadosProduto['preco'];
				$preco = str_replace($zc->getSymbol(), '', $preco);
				$preco = Zend_Locale_Format::getFloat($preco);
				
				$dados = array(
						'id_pedido' => $idPedido,
						'id_produto' => $idProduto,
						'quantidade' => $dadosProduto['quantidade'],
						'preco' => $preco
						);
				
				$item->gravar($dados);
			}			
			$this->getDbTable()->getAdapter()->commit();
			return 'Seu pedido de compra foi gerado com o número '.$idPedido;
		}
		catch(Exception $e)
		{
			$this->getDbTable()->getAdapter()->rollBack();
			throw new $e;
		}
	}
}

