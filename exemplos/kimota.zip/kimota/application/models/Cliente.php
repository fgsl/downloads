<?php

class Application_Model_Cliente extends Fgsl_Model_Abstract
{
	public function __construct()
	{
		parent::__construct();
		$this->_validators = array(
				'cpf' => new Zend_Validate_StringLength(11,11),
				'nome'=> array('allowEmpty'=>true),
				'email'=> new Zend_Validate_EmailAddress(),
				'senha'=> array('presence'=>'required'),
				'senha2'=>array('allowEmpty'=>true)
				);				
	}
	
	public static function criptografar($senha)
	{
		return md5(sha1(strtolower($senha)));
	}	
}

