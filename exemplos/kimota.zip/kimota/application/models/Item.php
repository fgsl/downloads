<?php

class Application_Model_Item extends Fgsl_Model_Abstract
{
	public function gravar($dados)
	{
		$this->getDbTable()->insert($dados);
	}

}

