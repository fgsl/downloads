<?php

class Application_Model_Papel extends Fgsl_Model_Abstract
{
	public function relacionarPapelComFuncionario($idPapel, $idFuncionario, $atribuir)
	{
		$db = $this->getDbTable()->getAdapter();

		$where = $db->quoteInto('id_funcionario = ?', $idFuncionario);
		$where .= $db->quoteInto(' and id_papel = ?', $idPapel);

		$papelFuncionario = new Application_Model_DbTable_PapelFuncionario();

		$row = $papelFuncionario->fetchRow($where);
		$atribuido = $this->_isAtribuido($row);
		if ($atribuir && !$atribuido)
		{
			$this->_atribuirPapel($papelFuncionario, $idFuncionario, $idPapel, $where);
		}
		elseif ($atribuido)
		{
			$this->_destituirPapel($papelFuncionario, $where);
		}
	}

	private function _isAtribuido($row)
	{
		$atribuido = true;
		if (is_null($row))
		{
			$atribuido = false;
		}
		return $atribuido;
	}

	private function _atribuirPapel(Zend_Db_Table_Abstract $dbTable, $id_funcionario, $id_papel, $where)
	{
		$data = array(
				'id_funcionario'=>$id_funcionario,
				'id_papel'=>$id_papel
		);
		$dbTable->insert($data);
	}

	private function _destituirPapel(Zend_Db_Table_Abstract $dbTable, $where)
	{
		$dbTable->delete($where);
	}

	public function getPapeisDeFuncionarios()
	{
		$papeis = array();

		$dbTable = new Application_Model_DbTable_PapelFuncionario();

		/** Como fica a consulta em PostgreSQL:
		 select funcionarios.nome as funcionario, papeis.nome as papel
		 from papeis_funcionario
		 inner join papeis on papeis_funcionario.id_papel = papeis.id
		 inner join funcionarios on papeis_funcionario.id_funcionario = funcionarios.matricula
		 */
		$select = $dbTable->select();
		$select->setIntegrityCheck(false)
		->from('papeis_funcionario',array(
				'funcionario'=>'funcionarios.nome',
				'papel'=>'papeis.nome'
		))
		->joinInner('funcionarios',
				'papeis_funcionario.id_funcionario = funcionarios.matricula')
				->joinInner('papeis',
						'papeis_funcionario.id_papel = papeis.id')
						->order('funcionario');

		return $dbTable->fetchAll($select);
	}

	public function relacionarAcessoComPapel($idAcesso, $idPapel, $atribuir)
	{
		$db = $this->getDbTable()->getAdapter();

		$where = $db->quoteInto('id_acesso = ?', $idAcesso);
		$where .= $db->quoteInto(' and id_papel = ?', $idPapel);

		$acessoPapel = new Application_Model_DbTable_AcessoPapel();

		$row = $acessoPapel->fetchRow($where);
		$atribuido = $this->_isAtribuido($row);
		if ($atribuir && !$atribuido)
		{
			$this->_atribuirAcesso($acessoPapel, $idPapel, $idAcesso, $where);
		}
		elseif ($atribuido)
		{
			$this->_destituirAcesso($acessoPapel, $where);
		}
	}

	private function _atribuirAcesso(Zend_Db_Table_Abstract $dbTable, $idPapel, $idAcesso, $where)
	{
		$data = array(
				'id_papel'=>$idPapel,
				'id_acesso'=>$idAcesso
		);
		$dbTable->insert($data);
	}

	private function _destituirAcesso(Zend_Db_Table_Abstract $dbTable, $where)
	{
		$dbTable->delete($where);
	}

	public function getAcessosDePapeis()
	{
		$papeis = array();

		$dbTable = new Application_Model_DbTable_AcessoPapel();

		/** Como fica a consulta em PostgreSQL:
		 select papeis.nome as papel, acessos.recurso as recurso
		 from acessos_papel
		 inner join papeis on acessos_papel.id_papel = papeis.id
		 inner join acessos on acessos_papel.id_acesso = acessos.id
		 */
		$select = $dbTable->select();
		$select->setIntegrityCheck(false)
		->from('acessos_papel',array(
				'papel'=>'papeis.nome',
				'acesso'=>'acessos.recurso'
		))
		->joinInner('papeis',
				'acessos_papel.id_papel = papeis.id')
				->joinInner('acessos',
						'acessos_papel.id_acesso = acessos.id')
						->order('papel');

		return $dbTable->fetchAll($select);
	}


}

