<?php

class Application_Model_Estoque extends Fgsl_Model_Abstract
{
	public function executar(Zend_Filter_Input $input)
	{
		$id = (int) $input->produto;
		$operacao = $input->operacao;
		$quantidade = (int)$input->quantidade;
		
		$where = $this->getDbTable()->getAdapter()->quoteInto('id_produto = ?', $id);

		$row = $this->getDbTable()->fetchRow('id_produto = '.$id);
		$saldoAtual = $row->quantidade;
		// entrada
		if ($operacao == 'E')
		{
			$saldoAtual = $row->quantidade + $quantidade;
		}
		// baixa
		if ($operacao == 'B')
		{
			$saldoAtual = $row->quantidade - $quantidade;
		}
		$dados = array(
				'quantidade' => $saldoAtual
		);

		$this->getDbTable()->getAdapter()->beginTransaction();
		try {
			$this->getDbTable()->update($dados, $where);
				
			$movimentacao = new Application_Model_Movimentacao();
			$dataAtual = getdate();
			$data = "{$dataAtual['mday']}-{$dataAtual['mon']}-{$dataAtual['year']}";
			$dados = array(
					'id_produto' => $id,
					'quantidade' => $saldoAtual,
					'data' => $data,
					'tipo' => $operacao
			);
			$movimentacao->getDbTable()->insert($dados);
			$this->getDbTable()->getAdapter()->commit();
		} catch (Exception $e) {
			$this->getDbTable()->getAdapter()->rollBack();
			throw $e;
		}
	}
}

