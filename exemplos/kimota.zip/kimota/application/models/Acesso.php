<?php
class Application_Model_Acesso extends Fgsl_Model_Abstract
{
	public static function getAcl($matricula)
	{
		$db = Zend_Db_Table_Abstract::getDefaultAdapter();

		$acl = new Zend_Acl();

		//recupera todos os papéis do funcionário
		$papelFuncionario = new Application_Model_DbTable_PapelFuncionario();
		$where = $db->quoteInto('id_funcionario = ?', $matricula);
		$rowSet = $papelFuncionario->fetchAll($where);

		$acessoPapel = new Application_Model_DbTable_AcessoPapel();

		foreach($rowSet as $row)
		{
			//recupera todos os recursos do papel
			$rowPapel = $row->findParentByPapel();
			$acl->addRole($row->id_papel);
			$where = $db->quoteInto('id_papel = ?', $row->id_papel);
			$subRowSetAcesso = $acessoPapel->fetchAll($where);
			
			foreach ($subRowSetAcesso as $subRow)
			{
				$recursoPrivilegio = $subRow->findParentByAcesso();
				if (!$acl->has($recursoPrivilegio->recurso))
					$acl->addResource($recursoPrivilegio->recurso);
				$acl->allow($row->id_papel,$recursoPrivilegio->recurso,
						$recursoPrivilegio->privilegio);
			}
		}
		return $acl;
	}
}

