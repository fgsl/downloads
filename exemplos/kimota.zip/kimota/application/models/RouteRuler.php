<?php

class Application_Model_RouteRuler implements Fgsl_Controller_Router_Route_Ruler_Interface
{
	public function hasRouteStartup()
	{
		return false;
	}

	public function hasRouteShutdown()
	{
		return true;
	}

	public function hasRoutePreDispatch()
	{
		return false;
	}

	public function hasRoutePosDispatch()
	{
		return false;
	}

	public function getRouteStartup($currentRoute)
	{
		return $currentRoute;
	}

	public function getRouteShutdown($currentRoute)
	{
		$newRoute = $currentRoute;
		if ($currentRoute['module'] == 'admin')
		{			
			Zend_Layout::getMvcInstance()->disableLayout();
			if (!($currentRoute['controller'] == 'index' ||
					$currentRoute['action'] == 'login' ||
					$currentRoute['action'] == 'logout'))
			{
				if (Zend_Auth::getInstance()->hasIdentity())
				{
					$newRoute = $this->_getRoutePostAcl($currentRoute);
				}
				else
				{
					$newRoute['controller'] = 'index';
					$newRoute['action'] = 'index';					
				}
			}
		}
		return $newRoute;
	}
	
	public function getRoutePreDispatch($currentRoute)
	{
		return $currentRoute;
	}
	
	public function getRoutePostDispatch($currentRoute)
	{
		return $currentRoute;
	}
	
	private function _getRoutePostAcl(array $currentRoute)
	{
		$newRoute = $currentRoute;
		$acl = Zend_Registry::get('security')->acl;
		if (!$acl->hasRole('administrador'))
		{
			$roles = $acl->getRoles();
			$temAcesso = false;
			foreach($roles as $role)
			{
				if ($acl->isAllowed($role,$currentRoute['controller'],$currentRoute['action']))
				{
					$temAcesso = true;
					break;
				}
			}
			if (!$temAcesso)
			{
				$newRoute['controller'] = 'index';
				$newRoute['action'] = 'index';
				$flashMessenger = new Zend_Controller_Action_Helper_FlashMessenger();
				$flashMessenger->clearMessages();
				$flashMessenger->addMessage("Acesso negado ao privilégio {$currentRoute['action']} do recurso {$currentRoute['controller']}");
			}
		}
		return $newRoute;
	}	
}

