<?php

class Application_Model_Produto extends Fgsl_Model_Abstract
{
	public function remove($key)
	{
		$this->getDbTable()->getAdapter()->beginTransaction();
		try {
			$produto = $this->getDbTable()->find($key)->current();
				
			$estoque = $produto->findDependentsByEstoque()->current();
				
			$comEstoque = true;
			if ($estoque->quantidade == 0 && $estoque->reservada == 0)
			{
				$modelEstoque = new Application_Model_Estoque();
				$modelEstoque->remove($key);
				$comEstoque = false;
			}
				
			$item = $produto->findDependentsByItem();
			$movimentacao = $produto->findDependentsByMovimentacao();
			if ($comEstoque || !empty($item) || !empty($movimentacao))
			{
				throw new Exception('Produto com dependências não pode ser removido!');
			}
				
			parent::remove($key);

			$this->getDbTable()->getAdapter()->commit();
		} catch (Exception $e) {
			$this->getDbTable()->getAdapter()->rollBack();
			throw $e;
		}
	}

	public static function getProdutos($nome = null)
	{
		$db = Zend_Db_Table_Abstract::getDefaultAdapter();	
		 
		$select = $db->select();
		$select->from(array('p'=>'produtos'),
				array('id','nome','preco'))
				->join(array('e'=> 'estoques'),
						'p.id = e.id_produto',
						array('quantidade'));
		if (is_null($nome))
		{
			$select->where('p.id_promocao = 1');
		}
		else
		{
			$where = $db->quoteInto("nome like ?", "%$nome%");
			$select->where($where);
		}
		
		$stmt = $select->query();
		return $stmt->fetchAll();
	}

}

