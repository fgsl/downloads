<?php

class Application_Model_Movimentacao extends Fgsl_Model_Abstract
{


}

