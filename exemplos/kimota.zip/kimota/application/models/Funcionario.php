<?php

class Application_Model_Funcionario extends Fgsl_Model_Abstract
{
	public static function encrypt($text)
	{
		return strrev(md5(sha1($text)));
	}

	public function save($data)
	{
		$senha = $data['senha'];

		if (empty($senha))
		{
			unset($data['senha']);
		}
		else
		{
			$data['senha'] = self::encrypt($senha);
		}

		parent::save($data);
	}
}

