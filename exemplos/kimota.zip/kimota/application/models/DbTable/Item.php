<?php
class Application_Model_DbTable_Item extends Fgsl_Db_Table_Abstract
{
	protected $_name = 'itens';

	public function __construct()
	{
		parent::__construct();
		$this->_fieldKey = '';
		$this->_fieldLabels = array(
				'id_pedido' => 'Pedido',
				'id_produto' => 'Produto',
				'preco' => 'Preço'
		);
		$this->_lockedFields = array();
		$this->_orderField = 'id_pedido';
		$this->_searchField = '';
		$this->_typeElement = array(
				'id_pedido' => Fgsl_Form_Constants::SELECT,
				'id_produto' => Fgsl_Form_Constants::SELECT,
				'preco' => Fgsl_Form_Constants::TEXT
		);
		$this->_typeValue = array(
				'id_pedido' => self::INT_TYPE,
				'id_produto' => self::INT_TYPE,
				'preco' => self::FLOAT_TYPE
		);
		$this->_addRelation('Pedido', 'id_pedido', 'Pedido', 'id');
		$this->_addRelation('Produto', 'id_produto', 'Produto', 'id');		
	}
}

