<?php
class Application_Model_DbTable_AcessoPapel extends Zend_Db_Table_Abstract
{
	protected $_name = 'acessos_papel';
	protected $_referenceMap = array(
			'Acesso' => array(
					'columns' => 'id_acesso',
					'refTableClass' => 'Application_Model_DbTable_Acesso',
					'refColumns' => 'id'
			),
			'Papel' => array(
					'columns' => 'id_papel',
					'refTableClass' => 'Application_Model_DbTable_Papel',
					'refColumns' => 'id'
			)
	);
	
	public function __construct($config = array())
	{
		parent::__construct($config);
		parent::setRowClass('Fgsl_Db_Table_Row_Abstract');
	}
	
}

