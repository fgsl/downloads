<?php
class Application_Model_DbTable_Estoque extends Fgsl_Db_Table_Abstract
{
	protected $_name = 'estoques';

	public function __construct()
	{
		parent::__construct();
		$this->_fieldKey = 'id_produto';
		$this->_fieldNames = array();
		$this->_fieldNames[]='id_produto';
		$this->_fieldNames[]='produtos.nome';
		$cols = $this->_getCols();
		for ($i=1;$i<count($cols);$i++)
		{
			$this->_fieldNames[] = $cols[$i];
		}
		$this->_fieldLabels = array(
				'id_produto' => 'Id',
				'produtos.nome' => 'Nome',
				'quantidade' => 'Quantidade',
				'maximo' => 'Máximo',
				'minimo' => 'Mínimo',
				'reservada' => 'Reservada'
		);
		$this->_lockedFields = array('id_produto','reservada');
		$this->_orderField = 'produtos.nome';
		$this->_searchField = 'produtos.nome';
		$this->_typeElement = array(
				'quantidade' => Fgsl_Form_Constants::TEXT,
				'maximo' => Fgsl_Form_Constants::TEXT,
				'minimo' => Fgsl_Form_Constants::TEXT
		);
		$this->_typeValue = array(
				'id_produto' => self::INT_TYPE,
				'quantidade' => self::INT_TYPE,
				'maximo' => self::INT_TYPE,
				'minimo' => self::INT_TYPE,
				'reservada' => self::INT_TYPE
		);
		$this->_addRelation('Produto', 'id_produto', 'Produto', 'id');
	}

	public function fetchAllAsArray($select)
	{
		$records = parent::fetchAllAsArray($select);
		foreach($records as $key => $value)
		{
			unset($records[$key]['remove']);
		}
		return $records;
	}

	public function insert(array $data)
	{
		unset($data['nome']);
		parent::insert($data);
	}

	public function update(array $data,$where)
	{
		unset($data['nome']);
		parent::update($data,$where);
	}
}

