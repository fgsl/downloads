<?php
class Application_Model_DbTable_Movimentacao extends Fgsl_Db_Table_Abstract
{
	protected $_name = 'movimentacoes';

	public function __construct()
	{
		parent::__construct();
		$this->_fieldKey = 'id_produto';
		$this->_fieldLabels = array(
				'id' => 'Id',
				'id_produto' => 'Produto',
				'quantidade' => 'Quantidade',
				'data' => 'Data',
				'tipo' => 'Tipo'	
		);
		$this->_lockedFields = array('id');
		$this->_orderField = 'nome';
		$this->_searchField = 'nome';
		$this->_typeElement = array(
				'quantidade' => Fgsl_Form_Constants::TEXT,
				'data' => Fgsl_Form_Constants::TEXT,
				'tipo' => Fgsl_Form_Constants::TEXT
		);
		$this->_typeValue = array(
				'id' => self::INT_TYPE,
				'id_produto' => self::INT_TYPE,
				'quantidade' => self::INT_TYPE
		);
		$this->_addRelation('Produto', 'id_produto', 'Produto', 'id');		
	}
}

