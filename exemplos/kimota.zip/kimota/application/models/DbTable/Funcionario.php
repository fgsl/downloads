<?php
class Application_Model_DbTable_Funcionario extends Fgsl_Db_Table_Abstract
{
	protected $_name = 'funcionarios';
		
	public function __construct()
	{
		parent::__construct();
		$this->_fieldKey = 'matricula';
		$this->_fieldLabels = array(
				'matricula' => 'Matrícula',
				'nome' => 'Nome',
				'apelido' => 'Apelido',
				'senha' => 'Senha'
		);
		$this->_lockedFields = array('matricula') ;
		$this->_orderField = 'nome';
		$this->_searchField = 'nome';
		$this->_typeElement = array(
				'nome' => Fgsl_Form_Constants::TEXT,
				'apelido' => Fgsl_Form_Constants::TEXT,
				'senha' => Fgsl_Form_Constants::PASSWORD
		);
		$this->_typeValue = array(
				'matricula' => self::INT_TYPE
		);
		$this->_addDependents('PapelFuncionario');
	}
	
	public function getCustomSelect($where, $order, $limit)
	{
		$select = parent::getCustomSelect($where, $order, $limit);
		$columns = $this->getCols();
		$key = array_search('senha', $columns);
		unset($columns[$key]);
		$select->from($this->_name,$columns);		
		return $select;
	}
}