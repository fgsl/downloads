<?php
class Application_Model_DbTable_PapelFuncionario extends Zend_Db_Table_Abstract
{
	protected $_name = 'papeis_funcionario';
	protected $_referenceMap = array(
			'Papel' => array(
					'columns' => 'id_papel',
					'refTableClass' => 'Application_Model_DbTable_Papel',
					'refColumns' => 'id'
			),
			'Funcionario' => array(
					'columns' => 'id_funcionario',
					'refTableClass' => 'Application_Model_DbTable_Funcionario',
					'refColumns' => 'matricula'
			)
	);
	
	public function __construct($config = array())
	{
		parent::__construct($config);
		parent::setRowClass('Fgsl_Db_Table_Row_Abstract');
	}
}

