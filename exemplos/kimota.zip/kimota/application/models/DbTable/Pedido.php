<?php
class Application_Model_DbTable_Pedido extends Fgsl_Db_Table_Abstract
{
    protected $_name = 'pedidos';
    
    public function __construct()
    {
    	parent::__construct();
    	$this->_fieldKey = 'cpf';
    	$this->_fieldLabels = array(
    			'id' => 'Id',
    			'data' => 'Data',
    			'status' => 'Status',
    			'cpf' => 'cpf'
    	);
    	$this->_lockedFields = array('id');
    	$this->_orderField = 'data';
    	$this->_searchField = 'cpf';
	    	$this->_typeElement = array(
    			'data' => Fgsl_Form_Constants::TEXT,
    			'status' => Fgsl_Form_Constants::CHECKBOX,
    			'cpf' => Fgsl_Form_Constants::TEXT
    	);
    	$this->_typeValue = array(
    			'status' => self::BOOLEAN_TYPE);
    	$this->_addRelation('Cliente', 'cpf', 'Cliente', 'cpf');
    	$this->_addDependents('Item');
    }
}

