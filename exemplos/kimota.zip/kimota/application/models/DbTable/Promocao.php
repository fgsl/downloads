<?php
class Application_Model_DbTable_Promocao extends Fgsl_Db_Table_Abstract
{

	protected $_name = 'promocoes';

	public function __construct()
	{
		parent::__construct();
		$this->_fieldKey = 'id';
		$this->_fieldLabels = array(
				'id' => 'Id',
				'nome' => 'Nome',
				'operador' => 'Operador',
				'fator' => 'Fator'
		);
		$this->_lockedFields = array('id');
		$this->_orderField = 'nome';
		$this->_searchField = 'nome';
		$this->_typeElement = array(
				'nome' => Fgsl_Form_Constants::TEXT,
				'operador' => Fgsl_Form_Constants::SELECT,
				'fator' => Fgsl_Form_Constants::TEXT
		);
		$this->_typeValue = array(
				'fator' => self::FLOAT_TYPE
		);
		$this->_addDependents('Produto');
	}

	public function getSelectOptions($fieldName, $where = null)
	{
		if ($fieldName == 'operador')
			return array(
					'-'=>'-',
					'*'=>'*',
					'n'=>'n'
			);
		return parent::getSelectOptions($fieldName, $where);
	}
}

