<?php
class Application_Model_DbTable_Cliente extends Fgsl_Db_Table_Abstract
{
	protected $_name = 'clientes';

	public function __construct()
	{
		parent::__construct();
		$this->_fieldKey = 'cpf';
		$this->_fieldLabels = array(
				'cpf' => 'CPF',
				'nome' => 'Nome',
				'senha' => 'Senha',
				'email' => 'e-mail'
		);
		$this->_orderField = 'nome';
		$this->_searchField = 'nome';
		$this->_typeElement = array(
				'nome' => Fgsl_Form_Constants::TEXT,
				'senha' => Fgsl_Form_Constants::PASSWORD,
				'email' => Fgsl_Form_Constants::TEXT
		);
		$this->_typeValue = array();
		$this->_addDependents('Pedido');		
	}
}

