<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
	public function _initNamespaces()
	{
		Zend_Loader_Autoloader::getInstance()->registerNamespace('Fgsl');
	}

	public function _initLog()
	{
		$writer = new Zend_Log_Writer_Stream(APPLICATION_PATH . '/log/debug.log');
		Zend_Registry::set('log',new Zend_Log($writer));
	}

	public function _initSession()
	{
		Zend_Session::start();
		Zend_Registry::set('security',new Zend_Session_Namespace('security'));
		$carrinho = new Zend_Session_Namespace('carrinho');
		Zend_Registry::set('carrinho',$carrinho);
		Zend_Registry::set('form',new Zend_Session_Namespace('form'));
	}

	public function _initRouteRuler()
	{
		Fgsl_Controller_Plugin::setRouteRuler(new Application_Model_RouteRuler());
	}

	public function _initRouter()
	{
		$router = Zend_Controller_Front::getInstance()->getRouter();

		$route = new Zend_Controller_Router_Route_Regex(
				'(.)*\.(js)',
				array(
						'module'=>'default',
						'controller'=>'files',
						'action'=>'render'
				)
		);
		$router->addRoute('files',$route);
	}
}

