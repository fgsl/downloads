function pesquisarProdutos() {
	var nodeNome = dojo.byId("nome");
	var nome = nodeNome.value;
	var nodeProdutos = dojo.byId("produtos");
	var requisicao = "/kimota/default/carrinho/index/nome/" + nome;
	dojo.xhrGet({
		url : requisicao,
		handleAs : "text",
		load : function(response, args) {
			dojo.fadeOut({
				node : nodeProdutos,
				onEnd : function() {
					nodeProdutos.innerHTML = response;
					dojo.fadeIn({
						node : nodeProdutos
					}).play();
				}
			}).play();
		},
		error : function(error, args) {
			console.warn("erro!", error);
		}
	});
}

dojo.ready(function() {
	var node = dojo.byId("pesquisar");
	dojo.connect(node, "onclick", pesquisarProdutos);
});