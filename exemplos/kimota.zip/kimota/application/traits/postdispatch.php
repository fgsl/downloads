<?php

$rotuloCliente = '';
if (Zend_Auth::getInstance()->hasIdentity())
{
	$contents = Zend_Auth::getInstance()->getStorage()->read();
	$rotuloCliente = "Cliente: {$contents->nome}";
	$acao = 'logout';
	$nomeDoLink = 'Sair';
}
else
{
	$acao = 'pre-login';
	$nomeDoLink = 'Acessar';
}
$urlCliente = $this->getUrl($acao, 'cliente', 'default');

$this->view->assign('urlCliente',$urlCliente);
$this->view->assign('nomeDoLink',$nomeDoLink);
$this->view->assign('rotuloCliente',$rotuloCliente);
$this->view->assign('urlVerConteudo', $this->getUrl('ver-conteudo','carrinho','default'));
$this->view->assign('urlPesquisar', $this->getUrl('pesquisar','carrinho','default'));
