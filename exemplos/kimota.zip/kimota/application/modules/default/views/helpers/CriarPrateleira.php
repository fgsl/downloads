<?php
class Zend_View_Helper_CriarPrateleira extends Zend_View_Helper_Abstract
{
	public function criarPrateleira(array $produtos)
	{
		$action = $this->view->url(
				array(
						'module'=>'default',
						'controller'=>'carrinho',
						'action'=>'incluir',
						'id'=>''
						)
				);		
		
		$html = '<table border="0" cellpadding="10%">';
		$html.='<tr>';
		$i = 1;
		foreach ($produtos as $produto) {
			$html.='<td>'.Application_Form_Produto::getForm($produto, $action).'</td>';
			if (($i % 4) == 0)
			{
				$html.='</tr><tr>';
			}
			$i++;
		}
		if (substr($html,strlen($html)-4) == '<tr>')
		{
			$html = substr($html,0,strlen($html)-4);
		}
		else
		{
			$html = substr($html,0,strlen($html)-3);
		}
		$html .= '</table>';
	
		return $html;
	}	
}