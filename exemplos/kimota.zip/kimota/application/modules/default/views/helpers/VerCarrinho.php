<?php
class Zend_View_Helper_VerCarrinho extends Zend_View_Helper_Abstract
{
	public function verCarrinho(array $produtos, $removeAction)
	{
		$zc = new Zend_Currency();
		$symbol = $zc->getSymbol();

		$html ='';
		foreach($produtos as $id => $produto)
		{
			$html .='<tr>';
			$html.= "<td>{$produto['nome']}</td>";
			$html.= "<td>{$produto['preco']}</td>";
				
			$url = $this->view->url(
					array(
							'module'=>'default',
							'controller'=>'carrinho',
							'action'=>'editar-quantidade',
							'id'=>$id
					)
			);
				
			$html.= '<td><a href="' . $url . '">' . $produto['quantidade'] . '</a></td>';

			$produto['preco'] = str_replace($symbol, '', $produto['preco']);
			$produto['preco'] = Zend_Locale_Format::getFloat($produto['preco']);

			$total = $produto['preco'] * $produto['quantidade'];
			$total = new Zend_Currency(array('value'=>$total));
			$html .= "<td>$total</td>";

			$html.=  '<td><a href="' . $removeAction . $id . '">Remover</td>';

			$html.='</tr>';
		}		
		return $html;
	}
}