<?php

class Default_CarrinhoController extends Fgsl_Controller_Action_Abstract
{
	private $_flashMessenger;

	public function init()
	{
		/* Initialize action controller here */
		$this->_flashMessenger = $this->getHelper('flashMessenger');
	}

	public function indexAction()
	{
		// action body
		if ($this->getRequest()->isXmlHttpRequest())
		{			
			$this->getHelper('layout')->disableLayout();
			$this->getHelper('viewRenderer')->setNoRender(true);
			
			$nome = $this->_getParam('nome');			
	
			echo $this->view->criarPrateleira(Application_Model_Produto::getProdutos($nome));
		}
		else
		{
			$this->view->assign('produtos',Application_Model_Produto::getProdutos());
			$this->view->assign('messages',$this->_flashMessenger->getMessages());
			$this->_flashMessenger->clearMessages();			
		}
	}

	public function incluirAction()
	{
		$item = array();
		$id = (int) $this->_getParam('id');
		$post = new Zend_Filter_Input(null, null, $_POST);
			
		$item['nome'] = $post->nome;
		$item['preco'] = $post->preco;
		$item['quantidade'] = $post->quantidade;
			
		$itens = $this->_getItens();
		$itens[$id] = $item;
		$this->_setItens($itens);

		$this->_forward('ver-conteudo');
	}

	private function _getItens()
	{
		if (isset(Zend_Registry::get('carrinho')->itens))
		{
			$itens = Zend_Registry::get('carrinho')->itens;
		}
		else
		{
			$itens = array();
		}
		return $itens;
	}

	public function _setItens($itens)
	{
		Zend_Registry::get('carrinho')->itens = $itens;
	}

	public function verConteudoAction()
	{
		$itens = $this->_getItens();
		$this->view->assign('produtos', $itens);
		$this->view->assign('action', $this->getUrl('remover','carrinho',null, array('id'=>'')));
		$this->view->assign('urlVoltar',$this->getUrl('index','index','default'));
		$this->view->assign('urlFechar',$this->getUrl('fechar','carrinho'));
	}	
	
	public function removerAction()
	{
		$id = (int) $this->_getParam('id');
		$itens = $this->_getItens();
		unset($itens[$id]);
		$this->_setItens($itens);
		$this->_forward('ver-conteudo');
	}

	public function editarQuantidadeAction()
	{
		$id = (int) $this->_getParam('id');
		$form = new Application_Form_Item();
		$action = $this->getUrl('alterar-quantidade','carrinho','default');
		$form->setAction($action);
		$itens = $this->_getItens();
		$form->preencherCampos($id, $itens);
		$this->view->assign('form',$form);
	}

	public function alterarQuantidadeAction()
	{
		$post = new Zend_Filter_Input(array('quantidade'=>'Int'), null, $_POST);
		$itens = $this->_getItens();
		$itens[$post->id]['quantidade'] = $post->quantidade;
		$this->_setItens($itens);
		$this->_forward('ver-conteudo');
	}		
	
	public function postDispatch()
	{
		include_once APPLICATION_PATH . '/traits/postdispatch.php';
		parent::postDispatch();
	}
	
	public function fecharAction()
	{
		if (!Zend_Auth::getInstance()->hasIdentity())
		{ 
			$this->_forward('pre-login','cliente');
			return;
		}
		$this->view->assign('action',$this->getUrl('gravar-pedido','carrinho'));		
	}
	
	public function gravarPedidoAction()
	{
		$pedido = new Application_Model_Pedido();

		$data = new Zend_Date();
		
		$cabecalho = array(
				'data' => $data,
				'status' => 0,
				'cpf' => Zend_Auth::getInstance()->getStorage()->read()->cpf
		);		

		try {
			$mensagem = $pedido->gravar($cabecalho,Zend_Registry::get('carrinho')->itens);
			$this->_flashMessenger->addMessage($mensagem);
		} catch (Exception $e) {
			$this->_flashMessenger->addMessage($e->getMessage());			
		}
		Zend_Registry::get('carrinho')->itens = array();
		$this->view->assign('messages', $this->_flashMessenger->getMessages());
		$this->view->assign('urlRetornar',$this->getUrl('index','index'));	
	}
	
 
	
	
}

