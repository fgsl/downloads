<?php

class Default_FilesController extends Zend_Controller_Action
{

	public function init()
	{
		/* Initialize action controller here */
	}

	public function indexAction()
	{
		// action body
	}

	public function renderAction()
	{		
		// action body
		$this->getHelper('layout')->disableLayout();
		$this->getHelper('viewRenderer')->setNoRender(true);
		 
		$requestURI = $_SERVER['REQUEST_URI'];
		 
		$basename = basename(APPLICATION_PATH);
		 
		$requestURI = substr($requestURI, strpos($requestURI, $basename));
		 
		$requestURI = str_replace($basename, APPLICATION_PATH, $requestURI);
		 
		require_once($requestURI);
	}


}



