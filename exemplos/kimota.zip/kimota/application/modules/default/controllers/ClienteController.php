<?php

class Default_ClienteController extends Fgsl_Controller_Action_Abstract
{
	private $_flashMessenger;

	public function init()
	{
		/* Initialize action controller here */
		$this->_flashMessenger = $this->getHelper('flashMessenger');
	}

	public function indexAction()
	{
		// action body
	}

	public function preCadastrarAction()
	{
		// action body
		$this->_prepareForm(false);
	}

	public function cadastrarAction() {
		$cliente = new Application_Model_Cliente();
		$post = new Zend_Filter_Input(null, $cliente->getValidators(),$_POST);

		$cpf = $post->cpf;

		$registro = $cliente->getDbTable()->find($cpf)->current();
		if (!empty($registro))
		{
			$this->_flashMessenger->addMessage('CPF já cadastrado');
			$this->_forward('pre-cadastrar');
			return;
		}
		$form = new Application_Form_Cliente();

		if (!$form->isValid($_POST))
		{
			Zend_Registry::get('form')->cliente = $form;
			$this->_forward('pre-cadastrar');
		}
		else
		{
			try {
				$data = array(
						'cpf' => $post->cpf,
						'nome' => $post->nome,
						'email' => $post->email,
						'senha' => Application_Model_Cliente::criptografar($post->senha),
						'Insert'=>'insert'
				);
				$cliente->save($data);
				$this->_forward('index','index');
			} catch (Exception $e) {
				$this->_flashMessenger->addMessage($e->getMessage());
				$this->_forward('pre-cadastrar');
			}
		}
	}

	public function preLoginAction()
	{
		// action body
		$this->_prepareForm(true);
		$this->view->assign('urlCadastrar',$this->getUrl('pre-cadastrar','cliente'));
	}

	private function _prepareForm($isLogin = true)
	{
		if (isset(Zend_Registry::get('form')->cliente))
		{
			$form = Zend_Registry::get('form')->cliente;
			unset(Zend_Registry::get('form')->cliente);
		}
		else
		{
			$form = $this->_getForm($isLogin);
			$isLogin ? $form->setLogin() : null;
		}

		$this->view->assign('form', $form);
		$this->view->assign('messages',$this->_flashMessenger->getMessages());
		$this->_flashMessenger->clearMessages();
	}

	private function _getForm($isLogin = true)
	{
		$form = new Application_Form_Cliente();
		$form->setAction($this->getUrl($isLogin ? 'login' : 'cadastrar','cliente'));
		$isLogin ? $form->setLogin() : null;
		$cliente = new Application_Model_Cliente();
		$form->getElement('cpf')->addValidator($cliente->getValidators('cpf'));
		$isLogin ? null : $form->getElement('email')->addValidator($cliente->getValidators('email'));
		return $form;
	}

	public function loginAction()
	{
		$cliente = new Application_Model_Cliente();

		$post = new Zend_Filter_Input(null, $cliente->getValidators(), $_POST);

		$form = $this->_getForm(true);		

		if (!$form->isValid($_POST))			
		{			
			Zend_Registry::get('form')->cliente = $form;
			$this->_forward('pre-login');
		}
		else
		{
			try {				
				$clienteAutenticado = $this->_clienteAutenticado($post->cpf,$post->senha);
				if ($clienteAutenticado)
				{
					$this->_flashMessenger->addMessage('Você precisa se autenticar');
					$this->_forward('index','index');
				}
				else
				{
					$this->_forward('pre-login','cliente');
				}					
			} catch (Exception $e) {
				$this->_flashMessenger->addMessage($e->getMessage());
				$this->_forward('pre-login','cliente');
			}
		}
	}

	private function _clienteAutenticado($cpf, $senha)
	{
		$db = $this->getInvokeArg('bootstrap')->getResource('db');

		$authAdapter = new Zend_Auth_Adapter_DbTable($db);
		$authAdapter->setTableName('clientes')
		->setIdentityColumn('cpf')
		->setCredentialColumn('senha')
		->setIdentity($cpf)
		->setCredential(Application_Model_Cliente::criptografar($senha));

		$resultado = $authAdapter->authenticate();

		if ($resultado->isValid())
		{
			$contents = $authAdapter->getResultRowObject(null,'senha');
			Zend_Auth::getInstance()->getStorage()->write($contents);
			return true;
		}
		else
		{
			foreach ($resultado->getMessages() as $message)
			{
				$this->_flashMessenger->addMessage($message);
			}
			return false;
		}
	}

	public function logoutAction()
	{
		Zend_Auth::getInstance()->clearIdentity();
		Zend_Session::destroy();
		$this->_forward('index','index');
	}
	
	public function postDispatch()
	{
		include_once APPLICATION_PATH . '/traits/postdispatch.php';
		parent::postDispatch();
	}
	
}



