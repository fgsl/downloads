<?php

class Admin_PapelCrudController extends Fgsl_Controller_Action_Crud_Abstract
{

    public function init()
    {
        /* Initialize action controller here */
    	parent::init();
    	$this->_uniqueTemplatesForApp = false;
    	$this->_model = new Application_Model_Papel();
    	$this->_title = 'Cadastro de Papéis';
    	$this->_searchButtonLabel = 'Pesquisar';
    	$this->_searchOptions = array($this->_model->getDbTable()->getSearchField() =>'Nome');
    	$this->_menuLink = $this->getUrl('index','menu','admin');
    	$this->_config();    	
    }
}

