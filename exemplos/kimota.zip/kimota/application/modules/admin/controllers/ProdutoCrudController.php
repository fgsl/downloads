<?php

class Admin_ProdutoCrudController extends Fgsl_Controller_Action_Crud_Abstract
{
	public function init()
	{		
		parent::init();	

		$this->_uniqueTemplatesForApp = false;
		$this->_model = new Application_Model_Produto();
		$this->_title = 'Cadastro de Produtos';
		$this->_searchButtonLabel = 'Pesquisar';
		$this->_searchOptions = array($this->_model->getDbTable()->getSearchField() =>'Nome');
    	$this->_menuLink = $this->getUrl('index','menu','admin');
		$this->_config();
	}
}