<?php

class Admin_MovimentacaoController extends Fgsl_Controller_Action_Abstract
{

	private $_flashMessenger = null;

	public function init()
	{
		/* Initialize action controller here */
		parent::init();
		$this->_flashMessenger = $this->getHelper('FlashMessenger');		
	}

	public function indexAction()
	{
		// action body
		$form = new Application_Form_Movimentacao();
		$form->setAction($this->getUrl('executar'));		
		$this->view->assign('form', $form);
		$this->view->assign('messages', $this->_flashMessenger->getMessages());
		$this->view->assign('menuLink',$this->getUrl('index','menu','admin'));
	}

	public function executarAction()
	{
		// action body
		$this->_flashMessenger->clearMessages();
		try {
			$estoque = new Application_Model_Estoque();
			$post = new Zend_Filter_Input(null, null, $_POST);
			$estoque->executar($post);
			$this->_flashMessenger->addMessage('Operação realizada com sucesso');
		} catch (Exception $e) {
			$this->_flashMessenger->addMessage($e->getMessage());
		}
		$this->_redirect('admin/movimentacao');		
	}
}



