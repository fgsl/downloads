<?php

class Admin_AcessoCrudController extends Fgsl_Controller_Action_Crud_Abstract
{

    public function init()
    {
        /* Initialize action controller here */
    	parent::init();
    	$this->_uniqueTemplatesForApp = false;
    	$this->_model = new Application_Model_Acesso();
    	$this->_title = 'Cadastro de Acessos';
    	$this->_searchButtonLabel = 'Pesquisar';
    	$this->_searchOptions = array($this->_model->getDbTable()->getSearchField() =>'Recurso');
    	$this->_menuLink = $this->getUrl('index','menu','admin');
    	$this->_config();    	
    }
}

