<?php

class Admin_MenuController extends Fgsl_Controller_Action_Abstract
{
	private $_flashMessenger;

    public function init()
    {
        /* Initialize action controller here */
    	$this->_flashMessenger = $this->getHelper('flashMessenger');
    }

    public function indexAction()
    {
        // action body
    	$this->view->assign('messages',$this->_flashMessenger->getMessages());
    	$this->view->assign('urlProdutos',$this->getUrl(null,'produto-crud'));
    	$this->view->assign('urlPromocoes',$this->getUrl(null,'promocao-crud'));
    	$this->view->assign('urlEstoque',$this->getUrl(null,'estoque-crud'));
    	$this->view->assign('urlMovimentacao',$this->getUrl(null,'movimentacao'));    	
    	$this->view->assign('urlFuncionarios',$this->getUrl(null,'funcionario-crud'));
    	$this->view->assign('urlPapeis',$this->getUrl(null,'papel-crud'));
    	$this->view->assign('urlAcessos',$this->getUrl(null,'acesso-crud'));
    	$this->view->assign('urlPapeisFuncionario',$this->getUrl(null,'papel-funcionario'));
    	$this->view->assign('urlAcessosPapel',$this->getUrl(null,'acesso-papel'));
    	$this->view->assign('urlSair',$this->getUrl('logout','index'));    	    	
    }


}

