<?php

class Admin_PromocaoCrudController extends Fgsl_Controller_Action_Crud_Abstract
{
	public function init()
	{		
		parent::init();	

		$this->_uniqueTemplatesForApp = false;
		$this->_model = new Application_Model_Promocao();
		$this->_title = 'Cadastro de Promoções';
		$this->_searchButtonLabel = 'Pesquisar';
		$this->_searchOptions = array('nome'=>'Nome');
    	$this->_menuLink = $this->getUrl('index','menu','admin');		
		$this->_config();
	}
}

