<?php

class Admin_IndexController extends Fgsl_Controller_Action_Abstract
{
	private $_flashMessenger = null;

	public function init()
	{
		/* Initialize action controller here */
		parent::init();
		$this->_flashMessenger = $this->getHelper('FlashMessenger');
	}

	public function indexAction()
	{
		// action body
		$form = new Application_Form_Login();
		$form->setAction($this->getUrl('login'));
		$this->view->assign('form', $form);
		$this->view->assign('messages', $this->_flashMessenger->getMessages());
	}

	public function loginAction()
	{
		$this->_flashMessenger->clearMessages();
		try
		{
			$post = new Zend_Filter_Input(null, null, $_POST);
				
			$db = $this->getInvokeArg('bootstrap')->getResource('db');

			$auth = new Zend_Auth_Adapter_DbTable($db);
			$auth->setTableName('funcionarios');
			$auth->setIdentityColumn('matricula');
			$auth->setCredentialColumn('senha');
			$auth->setIdentity($post->matricula);
			$auth->setCredential(Application_Model_Funcionario::encrypt($post->senha));			

			$result = $auth->authenticate();

			if ($result->isValid())
			{
				$contents = $auth->getResultRowObject(null,'senha');
				Zend_Auth::getInstance()->getStorage()->write($contents);
				$acl = Application_Model_Acesso::getAcl($post->matricula);
				Zend_Registry::get('security')->acl = $acl;
				$this->_redirect('admin/menu');
				return;
			}
			else
			{				
				$messages = '';
				foreach ($result->getMessages() as $message)
				{
					$this->_flashMessenger->addMessage($message);
				}
			}
		}
		catch (Exception $e)
		{
			$this->_flashMessenger->addMessage($e->getMessage());
		}
		$this->_redirect('admin');
	}
	
	public function logoutAction()
	{
		Zend_Auth::getInstance()->clearIdentity();
		Zend_Session::destroy();
		$this->_redirect('admin');
	} 
}

