<?php

class Admin_PapelFuncionarioController extends Fgsl_Controller_Action_Abstract
{
	private $_flashMessenger;

	public function init()
	{
		/* Initialize action controller here */
		$this->_model = new Application_Model_Papel();
		$this->_flashMessenger = $this->getHelper('flashMessenger');
	}

	public function indexAction()
	{
		// action body
		$this->view->assign('mensagem',$this->_flashMessenger->getMessages());
		$this->view->assign('form',$this->_getForm());
		$this->view->assign('table',$this->_getTable());
		$this->view->assign('urlRetornar', $this->getUrl('menu','index'));
	}

	private function _getForm()
	{
		$form = new Application_Form_PapelFuncionario();
		$form->setAction($this->getUrl('relacionar','papel-funcionario'));
		return $form;
	}

	public function relacionarAction()
	{
		$post = new Zend_Filter_Input(null, null, $_POST);
		
		$idFuncionario = (int)$post->funcionario;
		$idPapel = (int)$post->papel;		
		
		$this->_flashMessenger->clearMessages();
		try {
			$this->_model->relacionarPapelComFuncionario($idPapel,$idFuncionario,isset($post->atribuir));
			$this->_flashMessenger->addMessage(((isset($post->atribuir) ? 'Atribuição' : 'Destituição ') . ' realizada com sucesso!'));
		} catch (Exception $e) {
			$this->_flashMessenger->addMessage($e->getMessage());
		}
		$this->_forward('index');
	}
	
	private function _getTable()
	{
		$records = $this->_model->getPapeisDeFuncionarios();
		$this->view->partialLoop()->setObjectKey('record');
		$table = $this->view->partialLoop('papeis-funcionarios.phtml',$records);
		return $table;	
	}

}

