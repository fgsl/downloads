<?php

class Admin_EstoqueCrudController extends Fgsl_Controller_Action_Crud_Abstract
{
    public function init()
    {
		parent::init(); 
		$this->_uniqueTemplatesForApp = false;
		$this->_privateTemplates = true;
		$this->_model = new Application_Model_Estoque();
		$this->_title = 'Inventário';
		$this->_searchButtonLabel = 'Pesquisar';
		$this->_searchOptions = array($this->_model->getDbTable()->getSearchField() =>'Nome');
    	$this->_menuLink = $this->getUrl('index','menu','admin');		
		$this->_config();
    }
    
    public function indexAction()
    {
    	$this->_checkEstoque();
    	parent::indexAction();
    }
    
    private function _checkEstoque()
    {
    	$subSelect = new Zend_Db_Select($this->_model->getDbTable()->getAdapter());
    	$subSelect->from('produtos','id')
    	->joinInner('estoques', 'produtos.id = estoques.id_produto',null);
    	
    	$select = $this->_model->getDbTable()->select();
    	$select->setIntegrityCheck(false)
    	->from('produtos','produtos.id');
    	
    	$sql = $select->assemble() . 'produtos except (' . $subSelect->assemble() . ')';
    	
    	$records = $this->_model->getDbTable()->getAdapter()->fetchAll($sql);
    	
    	foreach($records as $record)
    	{
    		$data = array(
    				'id_produto' => $record['id'],
    				'quantidade' => 0,
    				'maximo' => 0,
    				'minimo' => 0,
    				'reservada' => 0
    		);
    		$this->_model->getDbTable()->insert($data);
    	}
    }    
    
    protected function _getProcessedRecords(ArrayIterator $currentItems)
    {
    	return parent::_getProcessedRecords($currentItems, false);
    }
}

