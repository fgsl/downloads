<?php

class Application_Form_Cliente extends Zend_Form
{
    public function init()
    {
        /* Form Elements & Other Definitions Here ... */
    	$this->setMethod('post');
    	$element = new Zend_Form_Element_Text('cpf');
    	$element->setLabel('CPF');
    	$this->addElement($element);
    	
    	$element = new Zend_Form_Element_Text('nome');
    	$element->setLabel('Nome');
    	$this->addElement($element);
    	
    	$element = new Zend_Form_Element_Text('email');
    	$element->setLabel('e-mail');    	
    	$this->addElement($element);
    	
    	$element = new Zend_Form_Element_Password('senha');
    	$element->setLabel('Senha');
    	$this->addElement($element);
    	
   		$element = new Zend_Form_Element_Password('senha2');
   		$element->setLabel('Confirme a senha');
   		$this->addElement($element);

    	$element = new Zend_Form_Element_Submit('cadastrar');
    	$element->setValue('Cadastrar');
    	$this->addElement($element);
    }
    
    public function setLogin()
    {
   		$this->removeElement('nome');
   		$this->removeElement('email');
   		$this->removeElement('senha2');
   		$this->getElement('cadastrar')->setName('login')->setValue('Login');    	
    }    
}

