<?php

class Application_Form_AcessoPapel extends Zend_Form
{

	public function init()
	{
		/* Form Elements & Other Definitions Here ... */
		$this->setMethod('post');
		 
		$model = new Application_Model_Papel();
		 
		$records = $model->getDbTable()->fetchAll(null,'nome');
		$options = array();
		foreach ($records as $record)
		{
			$options[$record->id] = $record->nome;
		}
		$element = new Zend_Form_Element_Select('papel');
		$element->setLabel('Papel');
		$element->setMultiOptions($options);
		$this->addElement($element);
		 
		$model = new Application_Model_Acesso();
		 
		$records = $model->getDbTable()->fetchAll(null,'recurso');
		$options = array();
		foreach ($records as $record)
		{
			$options[$record->id] = $record->recurso . '/' . $record->privilegio;
		}
		$element = new Zend_Form_Element_Select('acesso');
		$element->setLabel('Acesso');
		$element->setMultiOptions($options);
		$this->addElement($element);
		 
		$element = new Zend_Form_Element_Submit('atribuir');
		$this->addElement($element);
		$element = new Zend_Form_Element_Submit('destituir');
		$this->addElement($element);
	}
}

