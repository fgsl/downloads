<?php

class Application_Form_PapelFuncionario extends Zend_Form
{

	public function init()
	{
		/* Form Elements & Other Definitions Here ... */
		$this->setMethod('post');
		 
		$model = new Application_Model_Funcionario();
		 
		$records = $model->getDbTable()->fetchAll(null,'nome');
		$options = array();
		foreach ($records as $record)
		{
			$options[$record->matricula] = $record->nome;
		}
		$element = new Zend_Form_Element_Select('funcionario');
		$element->setLabel('Funcionário');
		$element->setMultiOptions($options);
		$this->addElement($element);
		 
		$model = new Application_Model_Papel();
		 
		$records = $model->getDbTable()->fetchAll(null,'nome');
		$options = array();
		foreach ($records as $record)
		{
			$options[$record->id] = $record->nome;
		}
		$element = new Zend_Form_Element_Select('papel');
		$element->setLabel('Papel');
		$element->setMultiOptions($options);
		$this->addElement($element);
		 
		$element = new Zend_Form_Element_Submit('atribuir');
		$this->addElement($element);
		$element = new Zend_Form_Element_Submit('destituir');
		$this->addElement($element);
	}
}

