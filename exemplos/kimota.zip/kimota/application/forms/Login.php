<?php

class Application_Form_Login extends Zend_Form
{

	public function init()
	{
		/* Form Elements & Other Definitions Here ... */
		$this->setMethod('post');
		$element = new Zend_Form_Element_Text('matricula');
		$element->setLabel('Matrícula');
		$this->addElement($element);
		$element = new Zend_Form_Element_Password('senha');
		$element->setLabel('Senha');
		$this->addElement($element);
		$element = new Zend_Form_Element_Submit('login');
		$this->addElement($element);
	}
}

