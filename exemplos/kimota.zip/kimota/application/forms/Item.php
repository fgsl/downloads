<?php

class Application_Form_Item extends Zend_Form
{

	public function init()
	{
		/* Form Elements & Other Definitions Here ... */
		$this->setMethod('post');
		$element = new Zend_Form_Element_Text('nome');
		$element->setLabel('Nome');
		$element->setAttrib('readonly','true');
		$this->addElement($element);
		 
		$element = new Zend_Form_Element_Text('quantidade');
		$element->setLabel('Quantidade');
		$this->addElement($element);
		 
		$element = new Zend_Form_Element_Hidden('id');
		$this->addElement($element);
		 
		$element = new Zend_Form_Element_Submit('alterar');
		$element->setLabel('Alterar');
		$this->addElement($element);
	}

	public function preencherCampos($id, $itens)
	{
		$this->getElement('nome')->setValue($itens[$id]['nome']);
		$this->getElement('quantidade')->setValue($itens[$id]['quantidade']);
		$this->getElement('id')->setValue($id);
	}
}

