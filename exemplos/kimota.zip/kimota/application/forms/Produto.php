<?php

class Application_Form_Produto extends Zend_Form
{

	public function init()
	{
		/* Form Elements & Other Definitions Here ... */

		$this->setMethod('post');
		 
		$element = new Zend_Form_Element_Text('nome');
		$element->setLabel('Nome');
		$element->setAttrib('readonly','true');
		$this->_addDecorators($element);
		$this->addElement($element);
		
		$element = new Zend_Form_Element_Text('preco');
		$element->setLabel('Preço');
		$element->setAttrib('readonly','true');
		$this->_addDecorators($element);
		$this->addElement($element);
		
		$element = new Zend_Form_Element_Text('quantidade');
		$element->setLabel('Quantidade');
		$element->setValue(1);
		$this->_addDecorators($element);		
		$this->addElement($element);
		
		$element = new Zend_Form_Element_Text('estoque');
		$element->setLabel('Disponível em estoque');
		$element->setAttrib('readonly','true');
		$this->_addDecorators($element);
		$this->addElement($element);
		
		$element = new Zend_Form_Element_Submit('comprar');
		$element->setLabel('Comprar');
		$this->addElement($element);
		 
	}

	public static function getForm(array $produto, $action)
	{
		$form = new self();
		$form->setAction($action . "{$produto['id']}");
		$form->getElement('nome')->setValue($produto['nome']);
		$form->getElement('preco')->setValue(new Zend_Currency(array('value'=>$produto['preco'])));
		$form->getElement('estoque')->setValue($produto['quantidade']);				
		return $form;
	}
	
	private function _addDecorators($element)
	{
		$element->addDecorator('HtmlTag',array('tag'=>'div'));
		$element->addDecorator('Label',array('tag'=>'b'));		
	}
}

