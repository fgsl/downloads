<?php

class Application_Form_Movimentacao extends Zend_Form
{

    public function init()
    {
        /* Form Elements & Other Definitions Here ... */
    	$this->setMethod('post');
    	
    	$element = new Zend_Form_Element_Select('produto');
    	$element->setLabel('Produto');

    	$produto = new Application_Model_Produto();
    	$rowSet = $produto->getDbTable()->fetchAll(null,'nome');
    	$options = array();
    	foreach($rowSet as $row)
    	{
    		$options[$row->id] = $row->nome;
    	}    	
    	
    	$element->setMultiOptions($options);
    	$this->addElement($element);
    	
    	$element = new Zend_Form_Element_Select('operacao');
    	$element->setLabel('Operação');
    	$element->setMultiOptions(
    			array(
    					'E' => 'Entrada',
    					'B' => 'Baixa'
    			)
    	);
    	$this->addElement($element);
    	
    	$element = new Zend_Form_Element_Text('quantidade');
    	$element->setLabel('Quantidade');
    	$this->addElement($element);
    	
    	$element = new Zend_Form_Element_Submit('executar');
    	$this->addElement($element);    	
    }
}