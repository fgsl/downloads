<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Tropa;

use Tropa\Model\Lanterna;
use Tropa\Model\LanternaTable;
use Tropa\Model\Setor;
use Tropa\Model\SetorTable;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Mvc\ModuleRouteListener;
use Zend\Mvc\MvcEvent;
use Zend\I18n\Translator\Translator;
use Zend\Mvc\I18n\Translator as MvcTranslator;
use Zend\Validator\AbstractValidator;
use Fgsl\ServiceManager\ServiceManager;
use Fgsl\EntityManager\EntityManager;

class Module
{
    public function onBootstrap(MvcEvent $e)
    {
        $e->getApplication()->getServiceManager()->get('translator');
        $eventManager        = $e->getApplication()->getEventManager();
        $moduleRouteListener = new ModuleRouteListener();
        $moduleRouteListener->attach($eventManager);
        
        $translationPath = realpath(__DIR__ . '/../../vendor/zendframework/zendframework/resources/languages');
        
        $translator = new Translator();
        $translator->addTranslationFile(
        		'phpArray',
        		$translationPath . '/pt_BR/Zend_Validate.php',
        		'default',
        		'pt_BR'        		
        );   

        $mvcTranslator = new MvcTranslator($translator);
       
        AbstractValidator::setDefaultTranslator($mvcTranslator);

        ServiceManager::setServiceManager($e->getApplication()->getServiceManager());
        
    	EntityManager::setModelDir(__DIR__ . '/src/Tropa/Model');
    	EntityManager::setProxyDir(__DIR__ . '/src/Tropa/Proxy');
    	EntityManager::setProxyName('Tropa\Proxy');                
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                	'Fgsl' => realpath(__DIR__ . '/../../vendor/fgslframework/fgslframework/library/Fgsl')
                ),
            ),
        );
    }
}
