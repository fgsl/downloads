<?php
namespace Application\Controller;

use Application\Model\Pedido;

use Novatec\Framework\Controller\PageController;

class Pedido extends PageController
{
	public function indexAction()
	{		
	}
}