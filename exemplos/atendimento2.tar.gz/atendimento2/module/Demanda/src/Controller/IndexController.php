<?php
/**
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2016 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Demanda\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\View\Model\JsonModel;
use Demanda\Model\Demanda;

class IndexController extends AbstractActionController
{
    private $sm;
    
    public function __construct($sm)
    {
        $this->sm = $sm;
    }
    
    
    public function indexAction()
    {
        $this->sm->get('Zend\Log')
        ->info(__METHOD__ . ': Listagem de demandas');
        $demandas = $this->sm->get('DemandaTable')
        ->getAll();
        return new ViewModel([
            'demandas' => $demandas
        ]);
    }
    
    public function editAction()
    {
        $codigo = $this->params('codigo');
        
        if (is_null($codigo)){
            $demanda = new Demanda();
        } else {
            $demanda = $this->sm->
            get('DemandaTable')->getOne($codigo);
        }

        $solicitantes = $this->sm->get('SolicitanteTable')->getAll();
        $assuntos = $this->sm->get('AssuntoTable')->getAll();

        return new ViewModel([
            'demanda' => $demanda,
            'solicitantes' => $solicitantes,
            'assuntos' => $assuntos            
        ]);
    }
    
    public function saveAction()
    {
        $demanda = new Demanda();
        $demanda->exchangeArray($_POST);
        $this->sm->get('DemandaTable')
        ->save($demanda);
        $this->redirect()->toRoute('demanda');   
    }
    
    public function deleteAction()
    {
        $codigo = $this->params('codigo');
        $this->sm->get('DemandaTable')
        ->delete($codigo);
        $this->redirect()->toRoute('demanda');
    }      
}
