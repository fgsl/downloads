<?php
namespace Demanda\Model;

use Zend\ServiceManager\Factory\FactoryInterface;
use Interop\Container\ContainerInterface;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\ResultSet\ResultSet;
use Demanda\Model\Demanda;
use Demanda\Model\DemandaTable;
class DemandaTableFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        $adapter = $container->get('Zend\Db\Adapter');
        $resultSet = new ResultSet();
        $resultSet->setArrayObjectPrototype(new Demanda());
        $tableGateway = new TableGateway('demandas', $adapter,null,$resultSet);
        return new DemandaTable($tableGateway, $container);        
    }
}
