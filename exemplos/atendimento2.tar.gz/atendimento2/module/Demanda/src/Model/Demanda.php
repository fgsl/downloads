<?php
namespace Demanda\Model;

use Solicitante\Model\Solicitante;
use Assunto\Model\Assunto;
use Interop\Container\ContainerInterface;
class Demanda
{
    /**
     * @var integer
     */
    public $codigo;
    /**
     * @var Solicitante
     */
    public $solicitante;
    /**
     * @var Assunto
     */
    public $assunto;
    /**
     * @var string
     */
    public $detalhes;

    /**
     * @var ContainerInterface
     */
    public static $sm;
    
    public function toArray()
    {
        return get_object_vars($this);
    }

       
    public function exchangeArray(array $data)
    {
        foreach($data as $attribute => $value){
            if ($attribute == 'cpf')
            {
                if (self::$sm == null){
                    $this->solicitante = new Solicitante();
                    $this->solicitante->cpf = $value;
                } else {
                    $this->solicitante = self::$sm->get('SolicitanteTable')->getOne($value);
                }
            } elseif ($attribute == 'codigo_assunto')
            {
                if (self::$sm == null){                
                    $this->assunto = new Assunto();
                    $this->assunto->codigo = $value;
                } else {
                    $this->assunto = self::$sm->get('AssuntoTable')->getOne($value);                    
                }
            } else {
                $this->$attribute = $data[$attribute];
            }            
        }
    }    
}