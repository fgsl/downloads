<?php
namespace Demanda\Model;

use Zend\Db\TableGateway\TableGatewayInterface;
use Interop\Container\ContainerInterface;
class DemandaTable
{
    private $tableGateway;
    private $container;
    
    public function __construct(TableGatewayInterface
         $tableGateway, ContainerInterface $container)
    {
        $this->tableGateway = $tableGateway;
        $this->container = $container;
    }
    
    public function save(Demanda $demanda)
    {
        $set = $demanda->toArray();
        
        $set['cpf'] = $set['solicitante']->cpf;
        unset($set['solicitante']);
        $set['codigo_assunto'] = $set['assunto']->codigo;
        unset($set['assunto']);
        
        if (empty($set['codigo'])){
            unset($set['codigo']);
            $this->tableGateway->insert($set);
        } else {
            $this->tableGateway->update($set,
                ['codigo'=>$set['codigo']]);
        }
    }
    
    public function getAll($where = null)
    {
        Demanda::$sm = $this->container;
        return $this->tableGateway
        ->select($where);
    }
    
    public function getOne($codigo)
    {
        $where = ['codigo' => $codigo];
        $records = $this->getAll($where);
        return $records->current();        
    }
    
    public function delete($cpf)
    {
        $this->tableGateway
        ->delete(['cpf'=>$cpf]);
    }    
}
