<?php
namespace Solicitante\Model;

class Solicitante
{
    public $cpf;
    public $nome; 
    public $cep; 
    public $municipio; 
    public $uf; 
    public $email; 
    public $ddd; 
    public $telefone;     
    
    public function toArray()
    {
        return get_object_vars($this);
    }
    
    public function exchangeArray(array $data)
    {
        foreach(get_object_vars($this) as $attribute => $value){
            if ($attribute == 'cpf'){
                $this->$attribute = 
                str_replace(['.','-'],'',
                    $data[$attribute]);
            } else {
                $this->$attribute = $data[$attribute];
            }
        }
    }    
    
}