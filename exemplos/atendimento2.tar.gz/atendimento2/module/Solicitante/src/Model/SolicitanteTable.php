<?php
namespace Solicitante\Model;

use Zend\Db\TableGateway\TableGatewayInterface;
class SolicitanteTable
{
    private $tableGateway;
    
    public function __construct(TableGatewayInterface
         $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }
    
    public function save(Solicitante $solicitante)
    {
        $set = $solicitante->toArray();
        
        $solicitante = $this->getOne($set['cpf']);
        
        if (empty($solicitante)){
            $this->tableGateway->insert($set);
        } else {
            $this->tableGateway->update($set,
                ['cpf'=>$set['cpf']]);
        }
    }
    
    public function getAll($where = null)
    {
        return $this->tableGateway
        ->select($where);
    }
    
    public function getOne($cpf)
    {
        $where = ['cpf' => $cpf];
        $records = $this->getAll($where);
        return $records->current();        
    }
    
    public function delete($cpf)
    {
        $this->tableGateway
        ->delete(['cpf'=>$cpf]);
    }    
}
