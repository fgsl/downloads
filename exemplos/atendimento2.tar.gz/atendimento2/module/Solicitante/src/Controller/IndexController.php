<?php
/**
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2016 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Solicitante\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\View\Model\JsonModel;
use Solicitante\Model\Solicitante;

class IndexController extends AbstractActionController
{
    private $sm;
    
    public function __construct($sm)
    {
        $this->sm = $sm;
    }
    
    
    public function indexAction()
    {
        $this->sm->get('Zend\Log')
        ->info(__METHOD__ . ': Listagem de solicitantes');
        $solicitantes = $this->sm->get('SolicitanteTable')
        ->getAll();
        return new ViewModel([
            'solicitantes' => $solicitantes            
        ]);
    }
    
    public function editAction()
    {
        $cpf = $this->params('cpf');
        
        if (is_null($cpf)){
            $solicitante = new Solicitante();
        } else {
            $solicitante = $this->sm->
            get('SolicitanteTable')->getOne($cpf);
        }
        
        return new ViewModel([
            'solicitante' => $solicitante
        ]);
    }
    
    public function saveAction()
    {
        $solicitante = new Solicitante();
        $solicitante->exchangeArray($_POST);
        $this->sm->get('SolicitanteTable')
        ->save($solicitante);
        $this->redirect()->toRoute('solicitante');   
    }
    
    public function deleteAction()
    {
        $cpf = $this->params('cpf');
        $this->sm->get('SolicitanteTable')
        ->delete($cpf);
        $this->redirect()->toRoute('solicitante');
    }      
}
