<?php
namespace Assunto\Model;

use Zend\Db\TableGateway\TableGatewayInterface;
class AssuntoTable
{
    private $tableGateway;
    
    public function __construct(TableGatewayInterface
         $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }
    
    public function save(Assunto $assunto)
    {
        $set = $assunto->toArray();
        
        if (empty($set['codigo'])){
            unset($set['codigo']);
            $this->tableGateway->insert($set);
        } else {
            $this->tableGateway->update($set,
                ['codigo'=>$set['codigo']]);
        }
    }
    
    public function getAll($where = null)
    {
        return $this->tableGateway
        ->select($where);
    }
    
    public function getOne($codigo)
    {
        $where = ['codigo' => $codigo];
        $records = $this->getAll($where);
        return $records->current();        
    }
    
    public function delete($codigo)
    {
        $this->tableGateway
        ->delete(['codigo'=>$codigo]);
    }    
}
