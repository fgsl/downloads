<?php
namespace Assunto\Model;

class Assunto
{
    public $codigo;
    public $assunto;
    
    public function toArray()
    {
        return [
            'codigo' => $this->codigo,
            'assunto' => $this->assunto            
        ];
    }
    
    public function exchangeArray(array $data)
    {
        $this->codigo = $data['codigo'];
        $this->assunto = $data['assunto'];
    }
    
    
    
}