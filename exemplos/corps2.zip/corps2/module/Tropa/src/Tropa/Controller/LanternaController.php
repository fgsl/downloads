<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Tropa\Controller;

use Tropa\Form\LanternaForm;
use Tropa\Model\Lanterna;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\View\Model\ViewModel;

class LanternaController extends AbstractActionController
{
	protected $lanternaTable;

	public function indexAction()
	{
		$partialLoop = $this->getSm()->get('viewhelpermanager')->get('PartialLoop');
		$partialLoop->setObjectKey('lanterna');		
	
		$urlAdd = $this->url()->fromRoute('lanterna', array('action'=>'add'));
		$urlEdit = $this->url()->fromRoute('lanterna', array('action'=>'edit'));
		$urlDelete = $this->url()->fromRoute('lanterna', array('action'=>'delete'));
		$urlHomepage = $this->url()->fromRoute('home');
		
		$placeHolder = $this->getSm()->get('viewhelpermanager')->get('Placeholder');
		$placeHolder('url')->edit = $urlEdit;
		$placeHolder('url')->delete = $urlDelete;
		
		$pageAdapter = new DbSelect($this->getLanternaTable()->getSelect(),$this->getLanternaTable()->getSql());
		$paginator = new Paginator($pageAdapter);
		$paginator->setCurrentPageNumber($this->params()->fromRoute('page',1));
		
		return new ViewModel(array(
				'paginator' => $paginator,
				'title' => $this->setAndGetTitle(),
				'urlAdd' => $urlAdd,
				'urlHomepage' => $urlHomepage
		));
	}

	public function addAction()
	{
		$form = new LanternaForm();
		$form->get('submit')->setValue('cadastrar');
			
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$lanterna = new Lanterna();
			$form->setInputFilter($lanterna->getInputFilter());
			$form->setData($request->getPost());

			if ($form->isValid())
			{
				$lanterna->exchangeArray($form->getData());
				$this->getLanternaTable()->saveLanterna($lanterna);
					
				return $this->redirect()->toRoute('lanterna');
			}
		}
		
		return array(
				'form' => $form,
				'title' => $this->setAndGetTitle()
				);

	}

	public function editAction()
	{
		$codigo = (int) $this->params()->fromRoute('codigo', null);
		if (is_null($codigo))
		{
			return $this->redirect()->toRoute('lanterna', array(
					'action' => 'add'
			));
		}
		$lanterna = $this->getLanternaTable()->getLanterna($codigo);

		$form  = new LanternaForm();
		$form->bind($lanterna);
		$form->get('submit')->setAttribute('value', 'Editar');
			
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$form->setInputFilter($lanterna->getInputFilter());
			$form->setData($request->getPost());

			if ($form->isValid())
			{
				$this->getLanternaTable()->saveLanterna($form->getData());
					
				return $this->redirect()->toRoute('lanterna');
			}
		}
			
		return array(
				'codigo' => $codigo,
				'form' => $form,
				'title' => $this->setAndGetTitle()
		);
	}

	public function deleteAction()
	{
		$codigo = (int) $this->params()->fromRoute('codigo', null);
		if (is_null($codigo))
		{
			return $this->redirect()->toRoute('lanterna');
		}

		$request = $this->getRequest();
		if ($request->isPost())
		{
			$del = $request->getPost('del', 'Nao');

			if ($del == 'Sim')
			{
				$this->getLanternaTable()->deleteLanterna($codigo);
			}

			return $this->redirect()->toRoute('lanterna');
		}
			
		return array(
				'codigo' => $codigo,
				'form' => $this->getDeleteForm($codigo),
				'title' => $this->setAndGetTitle()
		);
	}

	public function getLanternaTable()
	{
		if (!$this->lanternaTable)
		{
			$sm = $this->getServiceLocator();
			$this->lanternaTable = $sm->get('Tropa\Model\LanternaTable');
		}
		return $this->lanternaTable;
	}

	public function getDeleteForm($codigo)
	{
		$form = new LanternaForm();
		$form->remove('codigo');
		$form->remove('nome');
		$form->remove('codigo_setor');
		$form->remove('submit');

		$form->add(array(
				'name' => 'del',
				'attributes' => array(
						'type'  => 'submit',
						'value' => 'Sim',
						'id' => 'del',
				),
		));

		$form->add(array(
				'name' => 'return',
				'attributes' => array(
						'type'  => 'submit',
						'value' => 'Não',
						'id' => 'return',
				),
		));

		return $form;
	}

	private function getSm()
	{
		return $this->getEvent()->getApplication()->getServiceManager();
	}
	
	private function setAndGetTitle()
	{
		$title = 'Lanternas Verdes';
		$headTitle = $this->getSm()->get('viewhelpermanager')->get('HeadTitle');
		$headTitle($title);
		return $title;
	}	
}
