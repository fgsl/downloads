<?php


/**
 * Exemplo de função no sentido matemático 
 * @param integer $a
 * @param integer $b
 * @return number
 */
function soma($a,$b, $c = 0)
{
    return $a + $b;
}


/**
 * 
 * @param floats $numero
 * @return number
 */
function sortear($numero)
{
    //global $valorEspecial;
    $valorEspecial = $GLOBALS['valorEspecial'];
    return ($numero * 4300) + $valorEspecial;
}




/**
 * 
 * @param string $texto
 */
function escrever($texto)
{
    echo $texto;
}


function sequencia($valor)
{
    static $valorInicial = 0;
    $valorInicial++;
    return $valor + $valorInicial;
}






