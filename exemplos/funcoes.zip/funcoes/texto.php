<?php
// Exemplo de busca de texto
$frase = "Ratatouile entrou na cozinha";

$palavra = 'Rata';

if (strpos($frase, $palavra) === FALSE)
{
    echo 'Não encontrou';
}
else
{
    echo 'Encontrou';
}

