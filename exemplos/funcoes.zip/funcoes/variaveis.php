<?php
$a = 'texto1';

$b = &$a;

$a = 0;

$c = 1;
