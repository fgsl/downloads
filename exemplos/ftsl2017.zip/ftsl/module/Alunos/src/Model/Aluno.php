<?php
namespace Alunos\Model;

class Aluno
{
    public $codigo;
    public $nome;
    
    public function __construct(array $attributes = array())
    {
        $this->exchangeArray($attributes);
    }
    
    public function exchangeArray(array $attributes)
    {
        $this->codigo = (isset($attributes['codigo']) ? $attributes['codigo'] : null);
        $this->nome = (isset($attributes['nome']) ? $attributes['nome'] : null);        
    }
    
    public function toArray()
    {
        return get_object_vars($this);
    }
}