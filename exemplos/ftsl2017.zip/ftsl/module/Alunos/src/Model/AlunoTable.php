<?php
namespace Alunos\Model;

use Zend\Db\TableGateway\TableGatewayInterface;
class AlunoTable
{
    private $tableGateway;
    
    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }
    
    public function save(Aluno $aluno)
    {
        $set = $aluno->toArray();
        
        if (empty($set['codigo'])){
            $this->tableGateway->insert($set);
        } else {
            $this->tableGateway->update($set,['codigo'=>$set['codigo']]);
        }
    }
    
    public function delete($codigo)
    {
        $this->tableGateway->delete(['codigo' => $codigo]);
    }
    
    public function get($codigo)
    {
        $alunos = $this->tableGateway->select(['codigo'=>$codigo]);
        return $alunos->current();
    }
    
    public function getAll()
    {
        return $this->tableGateway->select();
    }
    
}
