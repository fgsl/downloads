<?php
/**
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2016 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Alunos\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Alunos\Model\Aluno;

class IndexController extends AbstractActionController
{
    private $sm;
    
    public function __construct($sm){
        $this->sm = $sm;
    }
    
    public function indexAction()
    {
        $alunos = $this->getTable()->getAll();
        return new ViewModel(['alunos' => $alunos]);
    }
    
    public function editAction()
    {
        $codigo = $this->params('codigo');
        
        $aluno = $this->getTable()->get($codigo);
            
        return new ViewModel([
            'aluno' => $aluno,
            'operacao' => (is_null($codigo) ? 'Incluir ' : 'Alterar ')
        ]);
    }
    
    public function saveAction()
    {
        $codigo = $this->getRequest()->getPost('codigo');
        $nome = $this->getRequest()->getPost('nome');
        
        $aluno = new Aluno(['codigo' => $codigo, 'nome' => $nome]);
        
        $this->getTable()->save($aluno);
        
        return $this->redirect()->toRoute('alunos');
    }
    
    public function deleteAction()
    {
        $codigo = $this->params('codigo');
        
        $this->getTable()->delete($codigo);
        
        return $this->redirect()->toRoute('alunos');        
    }
    
    private function getTable()
    {
        return $this->sm->get('AlunoTable');
    }
    
    
    
    
    
    
}
