<?php
namespace App\Action;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Zend\Diactoros\Response\HtmlResponse;
use Zend\Expressive\Router;
use Zend\Expressive\Template;
use Zend\Expressive\Plates\PlatesRenderer;
use Zend\Db\Adapter\AdapterInterface;
use App\Model\Professor;
use Zend\Diactoros\Response\RedirectResponse;

class ProfessorAction
{
    /**
     * @var AdapterInterface
     */
    private $dbAdapter;

    private $router;

    private $template;

    public function __construct(Router\RouterInterface $router, Template\TemplateRendererInterface $template = null,$dbAdapter)
    {
        $this->router   = $router;
        $this->template = $template;
        $this->dbAdapter = $dbAdapter;
    }

    public function __invoke(ServerRequestInterface $request, ResponseInterface $response,
        callable $next = null)
    {
        $data = [];
        Professor::setDbAdapter($this->dbAdapter);
        $path = $request->getUri()->getPath();
        $path = explode('/', $path);
        if (isset($path[3])) { // remove a matrícula
            unset($path[3]);
        }
        $path = implode('/', $path);
        switch ($path) {
            case '/professor/save':
                $codigo = isset($_POST['codigo']) ? $_POST['codigo'] : null;
                $nome = isset($_POST['nome']) ? $_POST['nome'] : null;
                $professor = new Professor([
                    'codigo' => $codigo,
                    'nome' => $nome
                ]);
                $professor->save();
                return new RedirectResponse($this->router->generateUri('professores_list'));
            case '/professores':
                $page = 'professores';
                $data['saveLink'] = $this->router->generateUri('professores_save');
                $data['editLink'] = $this->router->generateUri('professores_edit');
                $data['deleteLink'] = $this->router->generateUri('professores_delete');
                $data['professores'] = Professor::getAll();
                break;
            case '/professor/edit':
                $page = 'professor_edit';
                $codigo = $request->getAttribute('codigo',null);
                if (is_null($codigo)){
                    $professor = ['codigo'=>null,'nome'=>null];
                } else {
                    $professor = Professor::get($codigo);
                }
                $data['professor'] = $professor;
                $data['saveLink'] = $this->router->generateUri('professores_save');
                $data['returnLink'] = $this->router->generateUri('professores_list');
                break;
            case '/professor/delete':
                $codigo = $request->getAttribute('codigo', null);
                Professor::delete($codigo);
                return new RedirectResponse($this->router->generateUri('professores_list'));
            default:
                $page = 'home-page';
        }
        $content = $this->template->render('app::' . $page, $data);
        $output = $this->template->render('layout::default');
        $output = str_replace('$content', $content, $output);
        return new HtmlResponse($output);
    }
}
