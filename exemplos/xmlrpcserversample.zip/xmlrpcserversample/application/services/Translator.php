<?php
class Translator
{
	public function getGreeting($locale)
	{
		$locale = is_array($locale) ? $locale[0] : $locale;
		
		$greeting = 'good morning';
		if ($locale == 'de') $greeting = 'guten morgen';
		if ($locale == 'es') $greeting = 'buenos dias';
		if ($locale == 'fr') $greeting = 'bon jour';
		if ($locale == 'it') $greeting = 'buon giorno';
		if ($locale == 'pt-br') $greeting = 'bom-dia';
		
		return $greeting;
	}	
	
	public function getLocales()
	{
		return array('de','es','fr','it','pt-br');
	}
}