<?php
class ServiceController extends Zend_Controller_Action
{
	private $_client;

	public function init()
	{
		$this->_client = new Zend_Rest_Client('http://localhost/restserversample/service');
	}

	public function bomdiaAction()
	{
		$locale = $this->getRequest()->getParam('locale');		
		echo $this->_client->getGreeting($locale)->get();
		exit;
	}

	public function localesAction()
	{
		foreach ($this->_client->getLocales()->get()->locale as $locale)
		{
			echo $locale.'<br />';
		}
		exit;
	}



}