<?php

class Moeda
{
    private $cotacao;
    
    public function __construct($cotacao)
    {
        $this->cotacao = $cotacao;
    }
    
    public function getCotacao()
    {
        return $this->cotacao;
    }
}

?>