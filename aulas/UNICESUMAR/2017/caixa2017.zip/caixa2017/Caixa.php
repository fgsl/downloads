<?php

class Caixa
{
    private $valor;
    private $pagamento;
    
    public function setValor($valor)
    {
        $this->valor = $valor;
    }
    
    public function receberPagamento($valor,Moeda $moeda = null)
    {
        $this->pagamento += ($valor * ($moeda == null ? 1 : $moeda->getCotacao()));
    }
    
    public function devolverTroco()
    {
        return $this->pagamento - $this->valor;    
    }
}


?>