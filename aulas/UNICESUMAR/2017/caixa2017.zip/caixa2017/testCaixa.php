<?php
require 'autoload.php';

ini_set('display_errors', 'on');
/*
 * 1 paraguaio, 1 americano e 1 brasileiro
 * foram almoçar juntos.
 * A conta deu R$ 78,00
 * 
 * O paraguaio deu 40 guaranis
 * O americano deu 10 dolares
 * O brasileiro deu 5 reais
 * 
 * 1 guarani vale R$ 0,25
 * 1 dolar vale R$ 3,00
 * 
 * Pagamento = R$ 10 (0,25 * 40) + R$ 30 + R$ 5 = R$ 45,00
 * 
 * 78 - 45 = 33 (devendo)
 * 
 */

$caixa = new Caixa();

$caixa->setValor(78);

$guarani = new Moeda(0.25);
$dolar = new Moeda(3);

$caixa->receberPagamento(40,$guarani);
$caixa->receberPagamento(10,$dolar);
$caixa->receberPagamento(5);

$troco = $caixa->devolverTroco();

if ($troco == -33){
    echo 'Passou no teste';
}
else {
    echo 'Não passou no teste';
}


