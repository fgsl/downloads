<?php

class Herbivora extends \Mammalia implements SobrevivenciaInterface
{
    public function correr()
    {
        
    }
    
    public function andar()
    {
        
    }
    
    public function parar()
    {
        
    }
    
    public function comer(Comida $comida)
    {
        
    }

    public function __isset($name)
    {
        if ($name == 'pele'){
            return true;
        }
        return false;
    }
    
    public function __invoke()
    {
        return __CLASS__;
    }
    
    
    
    
    
}

?>