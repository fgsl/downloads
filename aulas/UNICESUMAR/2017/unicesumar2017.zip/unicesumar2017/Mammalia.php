<?php

abstract class Mammalia implements \Movimento
{

    /**
     *
     * @var integer
     */
    protected static $individuos = 0;
    // private $individuos = 0;
    
    /**
     *
     * @var boolean
     */
    protected $cauda;

    /**
     *
     * @var string
     */
    protected $olhos;

    /**
     *
     * @var string
     */
    protected $pelos;

    /**
     *
     * @var integer
     */
    protected $dentes;

    /**
     *
     * @var boolean
     */
    protected $clone = false;

    public function __construct()
    {
        self::$individuos ++;
        // $this->individuos++;
    }

    public static function getIndividuos()
    {
        return self::$individuos;
        // return $this->individuos;
    }

    public function __destruct()
    {
        echo 'Estou morrendo!';
    }

    public function setCauda($cauda)
    {
        $this->cauda = $cauda;
    }

    public function getCauda()
    {
        return $this->cauda;
    }

    public function setOlhos($olhos)
    {
        $this->olhos = $olhos;
    }

    public function __call($method, array $args)
    {
        $prefix = substr($method, 0, 3);
        $attribute = lcfirst(str_replace($prefix, '', $method));
        if ($prefix == 'get') {
            return $this->$attribute;
        }
        if ($prefix == 'set') {
            $this->$attribute = $args[0];
        }
    }

    public function __toString()
    {
        return "cauda: $this->cauda dentes: $this->dentes olhos: $this->olhos pelo: $this->pelo";
    }

    public function isClone()
    {
        return $this->clone;
    }
    
    public function __clone()
    {
        $this->clone = true;
    }
    
    
    
    
    
    
    
}

?>