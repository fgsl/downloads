<?php
class TestBindings extends PHPUnit_Framework_TestCase
{
    public function testQuemSouEu()
    {
      
        $this->assertEquals('A',A::quemSouEu());
        $this->assertEquals('B',B::quemSouEu());
        $this->assertEquals('C',C::quemSouEu());
        
        $this->assertEquals('Afanásio',A::qualEMeuNome());
        $this->assertEquals('Benedito',B::qualEMeuNome());
        $this->assertEquals('Cromelildo',C::qualEMeuNome());
    }
    
}

?>