<?php

trait MulherInvisivel
{
    public function desaparecer()
    {
        return 'desaparecendo...';
    }
}