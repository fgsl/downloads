<?php

class Comida
{
    public $tipo;
    public $valor;
    public $origem;
    
    public function __get($name)
    {
        if ($name == 'temperatura'){
            return 0;
        }
        return null;
    }
    
    public function __sleep()
    {
        echo 'Vou dormir...';
        return array_keys(get_object_vars($this));
    }
    

    public function __wakeup()
    {
        echo 'Acordei!';
    }
    
}

?>