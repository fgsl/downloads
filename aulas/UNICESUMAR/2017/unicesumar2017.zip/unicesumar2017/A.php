<?php

class A
{
    protected static $nome = 'Afanásio';
    
    public static function quemSouEu()
    {
        return get_called_class();
    }
    
    public static function qualEMeuNome()
    {
        return static::$nome;
    }
}

?>