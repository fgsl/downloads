<?php

class C extends \B
{
    protected static $nome = 'Cromelildo';
}

?>