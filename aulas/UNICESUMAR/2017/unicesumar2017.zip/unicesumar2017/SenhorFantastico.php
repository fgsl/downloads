<?php

trait SenhorFantastico
{
    public function esticar()
    {
        return 'esticando...';
    }
}
