<?php
class TestMagic extends PHPUnit_Framework_TestCase
{
    public function testGetAndSet()
    {
        $comida = new Comida();
        
        $this->assertEquals(0,$comida->temperatura);
        
        $comida->temperatura = 25;
        
        $this->assertEquals(25,$comida->temperatura);
        
        
        $this->assertEquals(null,$comida->tempero);
    }
}

?>