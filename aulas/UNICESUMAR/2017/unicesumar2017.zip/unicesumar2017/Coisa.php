<?php

trait Coisa
{
    public function destruir()
    {
        return 'destruindo...';
    }
}
