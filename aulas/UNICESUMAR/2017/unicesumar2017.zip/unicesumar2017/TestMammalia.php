<?php
class TestMammalia extends PHPUnit_Framework_TestCase {
    public function testInstance()
    {
        $ornitorrinco = new Herbivora();
        
        $this->assertNotEquals('',spl_object_hash($ornitorrinco));
        
        $ornitorrinco->setCauda(true);
        
        $this->assertTrue($ornitorrinco->getCauda());

        $diaboDaTasmania = new Carnivora(50);
        $grouCoroado = new Carnivora(80);
        $dragaoDeKomodo = new Carnivora(10);
        
        $ornitorrinco->setOlhos('cor-de-burro-quando-foge');
        $dragaoDeKomodo->setOlhos('azuis');
       
        $this->assertEquals(4,Carnivora::getIndividuos());
       
    }

    public function testComparison()
    {
        $pato = new Herbivora();
        $gato = new Carnivora(40);
        $ganso = clone $pato;
        $marreco = $pato;
        
        $this->assertNotEquals($pato,$gato);
        
        $this->assertTrue($ganso !== $pato);
        $this->assertTrue($marreco === $pato);
    }
    
    public function testInduction()
    {
        $elefante = new Herbivora();
        
        $comida = new Comida();
        
        $elefante->comer($comida);
        
        $this->assertTrue($elefante instanceof Herbivora);
    }
    
    public function testCall()
    {
        $lince = new Carnivora(80);
        
        $lince->setDentes(64);
        
        $this->assertEquals(64,$lince->getDentes());
    }
    
    public function testIsset()
    {
        $rinoceronte = new Herbivora();
        
        $this->assertTrue(isset($rinoceronte->pele));
    }
    
    public function testInvoke()
    {
        $boi = new Herbivora();
        
        $this->assertEquals(Herbivora::class,$boi());
    }
    
    public function testToString()
    {
        $leao = new Carnivora(40);
        $leao->setCauda(true);
        $leao->setOlhos('verdes');
        $leao->setDentes(36);
        $leao->setPelo('marrom');
        
        $this->assertGreaterThan(40,strlen($leao));
        
        echo $leao;
        
    }
    
    public function testClone()
    {
        $cachorro = new Carnivora(20);
        $lobo = clone $cachorro;
        
        $this->assertFalse($cachorro->isClone());
        $this->assertTrue($lobo->isClone());
    }
    
    public function testCarnivora()
    {
        $tigre = new Carnivora(80);
        
        $this->assertTrue($tigre->andar());
        $this->assertTrue($tigre->correr());
        $this->assertTrue($tigre->parar());
        
        $this->assertTrue($tigre->setOlhos('verdes') instanceof Carnivora);
        $this->assertContains('verdes',$tigre->getOlhos());
        
        
    }
    
    /**
     * @expectedException Exception
     */
    public function testExcecao()
    {
        $coiote = new Carnivora(10);
        
        $coiote->setOlhos('rosa');  
    }
}
