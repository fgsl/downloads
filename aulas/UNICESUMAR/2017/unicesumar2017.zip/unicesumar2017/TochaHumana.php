<?php

trait TochaHumana
{
    public function inflamar()
    {
        return 'inflamando...';
    }
}
