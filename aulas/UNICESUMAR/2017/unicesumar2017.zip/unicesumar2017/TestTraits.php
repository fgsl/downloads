<?php
require 'autoload.php';
class TestTraits extends PHPUnit_Framework_TestCase
{
    public function testQuartetoFantastico()
    {
        $senhorFantastico = new SuperSkrull();
        
        $this->assertContains('esticando',$senhorFantastico->esticar());
        $this->assertContains('desaparecendo',$senhorFantastico->desaparecer());
    }
}