<?php

interface SobrevivenciaInterface
{
    public function comer(Comida $comida);
}