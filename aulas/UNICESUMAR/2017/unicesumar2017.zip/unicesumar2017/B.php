<?php

class B extends \A
{
    protected static $nome = 'Benedito';
}

?>