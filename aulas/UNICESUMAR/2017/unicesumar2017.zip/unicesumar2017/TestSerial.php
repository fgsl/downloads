<?php
class TestSerial extends PHPUnit_Framework_TestCase
{
    public function testSerialize()
    {
        $comida = new Comida();
        $comida->tipo = 'vegetariana';
        $comida->valor = 'alto';
        $comida->origem = 'Índia';

        
        //$serial = '';
        $serial = serialize($comida);
        
        file_put_contents('serial.txt',$serial);
        
        $serial = file_get_contents('serial.txt');
        
        $comida = unserialize($serial);

        $this->assertEquals('Comida',get_class($comida));
        $this->assertEquals('vegetariana',$comida->tipo);
        
    }

    /**
     * @expectedException PHPUnit_Framework_Error
     */
    public function testArquivo()
    {
        file_get_contents('config.ini');
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}

?>