<?php

class SuperSkrull
{
    use SenhorFantastico,MulherInvisivel;
}
