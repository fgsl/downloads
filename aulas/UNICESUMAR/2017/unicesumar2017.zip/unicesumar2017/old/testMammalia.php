<?php
ini_set('display_errors','on');

require 'autoload.php';

$ornitorrinco = new Herbivora();

if (spl_object_hash($ornitorrinco) == ''){
	echo 'Não passou no teste!';
} else {
	echo 'Passou no teste';
}

echo "\n";

$ornitorrinco->setCauda(true);
//$ornitorrinco->cauda = true;

if ($ornitorrinco->getCauda()){
	echo 'Passou no teste!';
} else {
	echo 'Não passou no teste';
}

echo "\n";

$diaboDaTasmania = new Carnivora(50);
$grouCoroado = new Carnivora(80);
$dragaoDeKomodo = new Carnivora(10);

$ornitorrinco->setOlhos('cor-de-burro-quando-foge');
$dragaoDeKomodo->setOlhos('zebrados');


if (Carnivora::getIndividuos() == 4)
{
	echo 'Passou no teste';
} else {
	echo 'Não passou no teste';
}


