<?php

class Herbivora extends \Mammalia
{
}

?>