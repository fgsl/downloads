<?php

class Carnivora extends \Mammalia
{
	private $velocidade = 0;
	
	public function __construct($velocidade) {
        parent::__construct();
		$this->velocidade = $velocidade;
	}
	
	public function setOlhos($olhos)
	{
		$olhosValidos = ['azuis','verdes','castanhos','pretos'];
		if (!in_array($olhos, $olhosValidos)){
			throw new \Exception('Olhos inválidos');
		}
		parent::setOlhos($olhos);
	}
}

?>