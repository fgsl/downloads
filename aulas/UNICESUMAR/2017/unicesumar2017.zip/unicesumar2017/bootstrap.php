<?php
ini_set('display_errors','on');
require 'autoload.php';