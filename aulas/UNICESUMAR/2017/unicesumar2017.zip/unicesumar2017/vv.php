<?php
$garoto = 'cebolinha';
$garota = 'monica';
$genero = 'garoto';
$atributo = 'genero';

echo $$$atributo;