<?php
namespace Atendimento\Model;

class Assunto extends AbstractModel
{
    protected $codigo;
    protected $assunto;
    protected $detalhes;
    
    public function getAttributes()
    {
        return get_object_vars($this);
    }
    
    public function getKeyName()
    {
        return 'codigo';
    }
}