<?php
/**
 * @deprecated
 */
namespace Atendimento\Model;

use Zend\Db\TableGateway\TableGatewayInterface;

class SolicitanteTable
{
    /**
     * @var TableGatewayInterface
     */
    private $tableGateway;
    
    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;        
    }
    
    public function save(Solicitante $solicitante)
    {
        $set = $solicitante->toArray();
        $solicitantes = $this->tableGateway->select(['cpf' => $set['cpf']]);
        if ($solicitantes->current() == null) {
            $this->tableGateway->insert($set);
        } else {
            $this->tableGateway->update($set,['cpf' => $set['cpf']]);
        }
    }
    
    public function getAll($where = null)
    {
        return $this->tableGateway->select($where);
    }
    
    public function delete($cpf)
    {
        return $this->tableGateway->delete(['cpf' => $cpf]);
    }
    
    public function find($cpf)
    {
        $solicitantes = $this->tableGateway->select(['cpf' => $cpf]);
        $solicitante = $solicitantes->current();
        if ($solicitante == null){
            $solicitante = new Solicitante();
        }
        return $solicitante;
    }
    
    
    
}

