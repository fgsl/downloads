<?php
namespace Atendimento\Model;

use Zend\Stdlib\RequestInterface;

abstract class AbstractModel
{
    
    public function getFromPost(RequestInterface $request)
    {
        $attributes = $this->getAttributes();
        foreach($attributes as $attribute => $value){
            $this->$attribute = $request->getPost($attribute); 
        }
    }
    
    /**
     * 
     * @param RequestInterface $request
     * @return \Atendimento\Model\Solicitante
     */
    public static function getModelFromPost(RequestInterface $request)
    {
        $model = static::class;
        $model = new $model();
        $model->getFromPost($request);
        return $model;
    }
    
    /**
     * @return array
     */
    public function toArray()
    {
        return $this->getAttributes();
    }
    
    public function exchangeArray($data)
    {
        foreach($data as $key => $value){
            $data[strtolower($key)] = $value;
        }
        $attributes = $this->getAttributes();
        foreach($attributes as $attribute => $value){
            $this->$attribute = $data[$attribute];
        }
    }
    
    public function getArrayCopy()
    {
        return $this->getAttributes();
    }
    
    
    abstract public function getAttributes();
    
    
    abstract public function getKeyName();
}