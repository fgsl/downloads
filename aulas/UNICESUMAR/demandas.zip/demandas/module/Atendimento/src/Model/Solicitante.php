<?php
namespace Atendimento\Model;

class Solicitante extends AbstractModel
{
    protected $cpf;
    protected $nome;
    protected $cep;
    protected $municipio;
    protected $uf;
    protected $email;
    protected $ddd;
    protected $telefone;

    
    public function getAttributes()
    {
        return get_object_vars($this); 
    }
    
    public function getKeyName()
    {
        return 'cpf';
    }
}


