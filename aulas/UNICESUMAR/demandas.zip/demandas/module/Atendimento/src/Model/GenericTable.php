<?php
namespace Atendimento\Model;

use Zend\Db\TableGateway\TableGatewayInterface;

class GenericTable
{
    /**
     * @var TableGatewayInterface
     */
    private $tableGateway;
    private $keyName;
    private $modelName;
    
    public function __construct(TableGatewayInterface $tableGateway, $keyName, $modelName)
    {
        $this->tableGateway = $tableGateway;
        $this->keyName = $keyName;
        $this->modelName = $modelName;
    }
    
    public function save(AbstractModel $model)
    {
        $set = $model->toArray();
        $records = $this->tableGateway->select([$this->keyName => $set[$this->keyName]]);
        if ($records->current() == null) {
            $this->tableGateway->insert($set);
        } else {
            $this->tableGateway->update($set,[$this->keyName => $set[$this->keyName]]);
        }
    }
    
    public function getAll($where = null)
    {
        return $this->tableGateway->select($where);
    }
    
    public function delete($id)
    {
        return $this->tableGateway->delete([$this->keyName => $id]);
    }
    
    public function find($id)
    {
        $records = $this->tableGateway->select([$this->keyName => $id]);
        $model = $records->current();
        if ($model == null){
            $modelName = $this->modelName;
            $model = new $modelName();
        }
        return $model;
    }
}