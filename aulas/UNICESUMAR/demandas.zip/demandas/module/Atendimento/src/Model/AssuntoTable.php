<?php
/**
 * @deprecated
 */
namespace Atendimento\Model;

use Zend\Db\TableGateway\TableGatewayInterface;

class AssuntoTable
{
    /**
     * @var TableGatewayInterface
     */
    private $tableGateway;
    
    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;        
    }
    
    public function save(Assunto $assunto)
    {
        $set = $assunto->toArray();
        $assuntos = $this->tableGateway->select(['codigo' => $set['codigo']]);
        if ($assuntos->current() == null) {
            $this->tableGateway->insert($set);
        } else {
            $this->tableGateway->update($set,['codigo' => $set['codigo']]);
        }
    }
    
    public function getAll($where = null)
    {
        return $this->tableGateway->select($where);
    }
    
    public function delete($codigo)
    {
        return $this->tableGateway->delete(['codigo' => $codigo]);
    }
    
    public function find($codigo)
    {
        $assuntos = $this->tableGateway->select(['codigo' => $codigo]);
        $assunto = $assuntos->current();
        if ($assunto == null){
            $assunto = new Assunto();
        }
        return $assunto;
    }
}