<?php
namespace Atendimento\Form;

use Zend\Form\Form;
use Zend\Form\Element\Text;
use Zend\Form\Element\Submit;
use Zend\Form\Element\Hidden;
use Zend\Form\Element\Textarea;

class AssuntoForm extends Form
{
    public function __construct($name = null, $options = [])
    {
        parent::__construct('assunto');
        $this->setAttribute('method', 'post');
        
        $input = new Hidden('codigo');
        $this->add($input);
        
        $input = new Text('assunto');
        $input->setLabel('Assunto:');
        $input->setAttribute('size', 80);
        $input->setAttribute('autofocus', 'autofocus');
        
        $this->add($input);
        
        $input = new Textarea('detalhes');
        $input->setLabel('Detalhes:');
        $input->setAttribute('rows', 8);
        $input->setAttribute('cols', 20);
        
        $this->add($input);
        
        $input = new Submit('gravar');
        $input->setValue('gravar');
        
        $this->add($input);
    }
}