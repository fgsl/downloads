<?php
/**
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2016 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Atendimento\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Interop\Container\ContainerInterface;

abstract class AbstractController extends AbstractActionController
{
    /**
     * @var ContainerInterface
     */
    protected $container;
    protected $tableName;
    protected $modelName;
    protected $formName;
    
    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }    
    
    public function indexAction()
    {
        $records = $this->container->get($this->tableName)->getAll();   
        return new ViewModel(['records' => $records]);
    }
  
    public function gravarAction()
    {
        $model = call_user_func([$this->modelName,'getModelFromPost'],$this->getRequest());
        
        $this->container->get($this->tableName)->save($model);           
        
        return $this->redirect()->toRoute('atendimento',['controller' => $this->getControllerName()]);
    }
    
    protected function getControllerName()
    {
        $controllerName = get_class($this);
        $controllerName = str_replace('Atendimento\\Controller\\','',$controllerName);
        return lcfirst(str_replace('Controller','',$controllerName));
    }
    
    public function excluirAction()
    {
        $id = $this->params('id');
        $this->container->get($this->tableName)->delete($id);
        return $this->redirect()->toRoute('atendimento',['controller' => $this->getControllerName()]);
    }
    
    public function editarAction()
    {
        $id = $this->params('id');
        $model = $this->container->get($this->tableName)->find($id);
        $formName = $this->formName;
        $form = new $formName();
        $form->setAttribute('action', $this->url()->fromRoute('atendimento',['controller' => $this->getControllerName(),'action' => 'gravar']));
        $form->bind($model);
        return new ViewModel(['form' => $form]);        
    }
}