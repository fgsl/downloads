<?php
require 'autoloader.php';

$aluno = new Aluno();

if ($aluno->getEndereco() instanceof Endereco){
	echo 'Passou no teste';
} else {
	echo 'Não passou';
}