<?php
require 'autoloader.php';

$aluno = new Aluno();

$nome = 'Epaminondas';

$aluno->setNome($nome);

if ($aluno->getNome() == 'Epaminondas'){
	echo 'Passou no teste';
} else {
	echo 'Não passou';
}
