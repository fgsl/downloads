<?php
require 'autoloader.php';

$aluno = new AlunoEspecial();

