<?php
require 'autoloader.php';

$pessoa = new Pessoa();

$aluno = new Aluno();