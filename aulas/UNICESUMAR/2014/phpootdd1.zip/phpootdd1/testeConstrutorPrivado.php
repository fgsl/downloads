<?php
require 'autoloader.php';

$moedas = 'Moedas';

try {
	$reflection = new ReflectionClass('Moedas');
	$construtor = $reflection->getConstructor();
	if ($construtor->isPrivate()){
		throw new Exception('Construtor privado');
	}
} catch (Exception $e) {
	$moedas = NULL;
}


if (is_null($moedas))
{
	echo 'Passou no teste';
} else {
	echo 'Não passou';
}