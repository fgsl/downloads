<?php
require 'autoloader.php';

$aluno1 = new Aluno();
$aluno2 = new Aluno();
$aluno3 = new Aluno();

if (Aluno::getQuantidade() == 3){
	echo 'Passou no primeiro teste';
} else {
	echo 'Não passou no primeiro teste';
}

unset($aluno2);

if (Aluno::getQuantidade() == 2){
	echo 'Passou no segundo teste';
} else {
	echo 'Não passou no segundo teste';
}

