<?php
class AlunoEspecial extends Aluno {
}

?>