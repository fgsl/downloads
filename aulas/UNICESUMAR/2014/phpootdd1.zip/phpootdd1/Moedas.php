<?php
final class Moedas {
	const DOLAR = 'dolar';
	const REAL = 'real';
	const GUARANI = 'guarani';
	const EURO = 'euro';
	
	/**
	 * Impede a instanciação
	 */
	private function __construct()
	{
		
	}
}

?>