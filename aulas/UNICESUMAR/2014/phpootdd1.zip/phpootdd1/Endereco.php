<?php
class Endereco {
	/**
	 * 
	 * @var string
	 */
	private $logradouro;
	/**
	 * 
	 * @var string
	 */
	private $complemento;
	/**
	 * 
	 * @var string
	 */
	private $cep;
	/**
	 * 
	 * @var string
	 */
	private $cidade;
	/**
	 * 
	 * @var string
	 */
	private $uf;
}

?>