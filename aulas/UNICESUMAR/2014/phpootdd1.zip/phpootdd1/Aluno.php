<?php
final class Aluno extends Pessoa{
	public function __construct()
	{
		parent::__construct();
		$this->cpf = '00000000000';
	}
	
	
	/**
	 * 
	 * @var string
	 */
	private $cpf;
/**
	public function setEndereco(Endereco $endereco)
	{
		$this->endereco = $endereco . ' especial';
	}
**/	
	
	public function votar(){}
	
	
}


?>