<?php
require 'autoloader.php';

$aluno = new Aluno();
$aluno->setNome('Huguinho');

if ($aluno->getNome() == 'Huguinho'){
	echo 'Passou no primeiro teste';
} else {
	echo 'Não passou no primeiro teste';
}