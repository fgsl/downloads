<?php
abstract class Pessoa implements Cidadao{
	/**
	 *
	 * @var integer
	 */
	protected static $quantidade = 0;
	
	/**
	 *
	 * @var string
	 */
	protected $nome;
	/**
	 *
	 * @var Endereco
	 */
	protected $endereco;
	
	public function __construct()
	{
		$this->endereco = new Endereco();
		self::$quantidade++;
	}
	
	public static function getQuantidade()
	{
		return self::$quantidade;
	}
	
	
	/**
	 *
	 * @param string $nome
	 */
	public function setNome($nome)
	{
		$this->nome = $nome;
	}
	
	/**
	 * @return string
	 */
	public function getNome()
	{
		return $this->nome;
	}
	
	/**
	 *
	 * @param $endereco Endereco
	 */
	final public function setEndereco(Endereco $endereco)
	{
		$this->endereco = $endereco;
	}
	
	/**
	 * @return Endereco
	 */
	public function getEndereco()
	{
		return $this->endereco;
	}
	
	
	public function __destruct()
	{
		echo 'Morri!';
		self::$quantidade--;
	}
	
	
}

?>