<?php
class Moeda {
	
	private static $cambios = array();
	
	/**
	 * 
	 * @var double
	 */
	private $valor;
	
	/**
	 * 
	 * @var string
	 */
	private $moeda;
	
	public function __construct($moeda)
	{
		$this->moeda = $moeda;
	}
	
	public function setValor($valor)
	{
		$this->valor = $valor;
	}
	
	public static function setCambio($de, $para, $taxa)
	{
		self::$cambios[$de][$para] = $taxa;
	}
	
	/**
	 * 
	 * @param array $cambios
	 */
	public static function setCambios(array $cambios)
	{
		self::$cambios = $cambios;
	}
	
	public function adiciona(Moeda $moeda)
	{
		$this->valor+= $moeda->getValorEm($this->moeda);
		return $this; 
	}
	
	public function subtrai(Moeda $moeda)
	{
		$this->valor-= $moeda->getValorEm($this->moeda);
		return $this;
	}
	
	public function getValor()
	{
		return $this->valor;
	}
	
	public function getValorEm($moeda)
	{
		return $this->valor * self::$cambios[$this->moeda][$moeda];
	}
	
	
	
}

?>