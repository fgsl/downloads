<?php
require 'autoloader.php';

$aluno1 = new Aluno();
$aluno2 = new Aluno();
$aluno3 = new Aluno();

$id1 = spl_object_hash($aluno1);
$id2 = spl_object_hash($aluno2);
$id3 = spl_object_hash($aluno3);

// Passou no teste
if ($id1 <> $id2 && 
$id2 <> $id3 &&
$id1 <> $id3){
	echo 'Passou no teste';
// Não passou no teste	
} else {
	echo 'Não passou no teste';
}