<?php
interface Residente {
	public function getEndereco();
	public function setEndereco(Endereco $endereco);
}