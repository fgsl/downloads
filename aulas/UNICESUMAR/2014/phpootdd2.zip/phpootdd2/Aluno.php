<?php
final class Aluno extends Pessoa{
	public function __construct()
	{
		parent::__construct();
		$this->cpf = '00000000000';
	}
	
	
	/**
	 * 
	 * @var string
	 */
	private $cpf;
/**
	public function setEndereco(Endereco $endereco)
	{
		$this->endereco = $endereco . ' especial';
	}
**/	
	
	public function votar(){}
	
	public function __toString()
	{
		return $this->cpf;
	}
	
	public function __call($method, array $args)
	{
		$prefix = substr($method,0,3);
		if ($prefix == 'get'){
			$attribute = lcfirst(substr($method,3));
			return $this->$attribute;
		}
		if ($prefix == 'set'){
			$attribute = lcfirst(substr($method,3));
			$this->$attribute = $args[0];
		}
	}

	public function __clone()
	{
		$this->cpf = '00000000000';
	}
	
	
	
	
}