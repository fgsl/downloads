<?php
final class Moedas {
	const DOLAR = 'dolar';
	const REAL = 'real';
	const GUARANI = 'guarani';
	const EURO = 'euro';
	
	/**
	 * Impede a instanciação
	 */
	private function __construct()
	{
		
	}
	
	public static function __callstatic($method, array $args)
	{
		$prefix = substr($method,0,3);
		if ($prefix == 'get'){
			$constName = strtoupper(substr($method,3));
			$reflection = new ReflectionClass('Moedas');
			return $reflection->getConstant($constName);
		}
	}
	
}