<?php
class OO2Test extends PHPUnit_Framework_TestCase
{
	private $serialAluno = '';	
	
	public function setUp()
	{
		require 'autoloader.php';
		$this->serialAluno = file_get_contents(__DIR__ . '/serial.txt');
	}
	
	public function testClone()
	{
		// dupla referência ao mesmo objeto
		$aluno1 = new Aluno();
		$aluno2 = $aluno1;	
		
		$id1 = spl_object_hash($aluno1);
		$id2 = spl_object_hash($aluno2);
		
		$this->assertEquals($id1,$id2);
		
		// criando uma cópia de um objeto
		$aluno2 = clone $aluno1;
		
		$id2 = spl_object_hash($aluno2);
		
		$this->assertTrue($id1 <> $id2);
	}
	
	public function testComparison()
	{
		// dupla referência ao mesmo objeto
		$aluno1 = new Aluno();
		$aluno2 = $aluno1;
			
		$this->assertTrue($aluno1 === $aluno2);
	
		// criando uma cópia de um objeto
		$aluno2 = clone $aluno1;
		
		$this->assertTrue($aluno1 == $aluno2);
	}
	
	public function testCalledClass()
	{
		$aluno = new Aluno();
		$aluno->setNome('Garfield');
		
		$this->assertEquals(
				$aluno->getAuditoria('setNome'),
				'Aluno');		
	}
	
	public function testInduction()
	{
		$reflectionClass = new ReflectionClass('Aluno');
		
		$this->assertTrue(
				$reflectionClass->
				implementsInterface('Residente'));
				
	}
	
	public function testLateStaticBindings()
	{
		$comprador = Apartamento::getComprador();
		
		$this->assertEquals($comprador,
		'Comprador de Localização Privilegiada de Apartamento');
	}
	
	public function testSerialize()
	{
		$apartamento = new Apartamento();
		
		$serial = serialize($apartamento);
		
		$apartamento = unserialize($serial);
		
		$this->assertInstanceOf('Apartamento',$apartamento);
		
	}
	
	/**
		TODO tratar arquivo de texto
	 */
	public function testUnserialize()
	{				
		$aluno = unserialize($this->serialAluno);
		
		$this->assertInstanceOf('Aluno',$aluno);
		$this->assertEquals('Obadias',$aluno->getNome());
	}	
	
	public function testGetSet()
	{
		$endereco = new Endereco();
		
		$endereco->logradouro = 'Rua Mussum, 1984';
		
		$this->assertEquals('Rua Mussum, 1984', $endereco->logradouro);
	}
	
	public function testCall()
	{
		$endereco = new Endereco();
		
		$endereco->setLogradouro('Rua dos Alfeneiros, 39');
		$endereco->setCidade('Londres');
		$endereco->setCep('980765');
		$endereco->setUf('UK');
		
		$this->assertEquals('Rua dos Alfeneiros, 39',$endereco->getLogradouro());
		$this->assertEquals('Londres',$endereco->getCidade());
		$this->assertEquals('980765',$endereco->getCep());
		$this->assertEquals('UK',$endereco->getUf());		
	}
	
	public function testIsset()
	{
	
		$aluno = new Aluno();
		isset($aluno->tipoSanguineo);
		isset($aluno->altura);
		isset($aluno->peso);
		
		$this->assertEquals(3, $aluno->getTests());
		
	}
	
	public function testInvoke()
	{
		$endereco = new Endereco();
		$endereco->setLogradouro('Rua dos Alfeneiros, 39');
		$endereco->setCidade('Londres');
		$endereco->setCep('980765');
		$endereco->setUf('UK');
		
		$this->assertContains('Londres',$endereco());
		
	}
	
	public function testCallStatic()
	{
		$moeda = Moedas::getEuro();
		
		$this->assertEquals('euro',$moeda);
	}
	
	public function testString()
	{
		$aluno = new Aluno();
		$aluno->setCpf('12345678911');
		
		$texto = '';
		$texto .= $aluno;
		
		$this->assertEquals('12345678911', $texto);
		
	}
	
	public function testMagicClone()
	{
		$aluno = new Aluno();
		$aluno->setCpf('424242424242');
		$aluno->setNome('Calvin');
		
		$aluno2 = clone $aluno;		
		
		$this->assertEquals('00000000000',$aluno2->getCpf());
		$this->assertEquals('Calvin', $aluno2->getNome());
	}
	
	public function testSleepAndWakeUp()
	{
		$apartamento = new Apartamento();
	
		$serial = serialize($apartamento);
		
		$this->assertEquals($apartamento->sleepCount, 1);
	
		$apartamento = unserialize($serial);
	
		$this->assertEquals($apartamento->sleepCount, 0);
		$this->assertEquals($apartamento->wakeUpCount, 1);	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
