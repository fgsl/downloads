<?php
class MoedaTest extends PHPUnit_Framework_TestCase
{
	public function setUp()
	{
		require 'autoloader.php';		
	}
	
	public function testCambio()
	{
		$real = new Moeda(Moedas::REAL);
		$dolar = new Moeda(Moedas::DOLAR);
		$guarani = new Moeda(Moedas::GUARANI);
		$euro = new Moeda(Moedas::EURO);
		$conta = new Moeda(Moedas::REAL);
		
		$conta->setValor(40);
		$real->setValor(20);
		$dolar->setValor(10);
		$guarani->setValor(10);
		$euro->setValor(1);
		
		/**
		 * o real vale metade do dolar e o dobro do guarani
		 * e o real vale 1/3 de euro
		 *
		 * Então temos 20 + (2 * 10) + (0.5 * 10) + (3 * 1)- 40
		 * 20 + 20 + 5 + 3 - 40
		 * 48 - 40
		 * 8
		*/
		Moeda::setCambios(Cambio::getTaxas());
		
		$pago = new Moeda(Moedas::REAL);
		$pago->adiciona($real);
		$pago->adiciona($dolar);
		$pago->adiciona($guarani);
		$pago->adiciona($euro);		
		
		$pago->subtrai($conta);

		$this->assertEquals(8, $pago->getValor());		
	}
}


