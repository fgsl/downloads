<?php
require('autoloader.php');
$aluno = new Aluno();
$aluno->setNome('Obadias');
$endereco = new Endereco();
$endereco->setCidade('Maringa');
$aluno->setEndereco($endereco);
$serial = serialize($aluno);
echo $serial;
