<?php
interface Cidadao {
	public function votar();
}

?>