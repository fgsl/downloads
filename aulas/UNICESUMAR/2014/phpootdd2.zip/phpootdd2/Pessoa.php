<?php
abstract class Pessoa implements Cidadao,Residente{
	/**
	 *
	 * @var integer
	 */
	protected static $quantidade = 0;
	
	/**
	 *
	 * @var string
	 */
	protected $nome;
	/**
	 *
	 * @var Endereco
	 */
	protected $endereco;
	
	protected $auditoria = array();
	
	protected $tests = 0;
	
	public function __construct()
	{
		$this->endereco = new Endereco();
		self::$quantidade++;
	}
	
	public static function getQuantidade()
	{
		return self::$quantidade;
	}
	
	
	/**
	 *
	 * @param string $nome
	 */
	public function setNome($nome)
	{	
		$metodo = str_replace(__CLASS__. '::', '', __METHOD__);
		$this->auditoria[$metodo] = get_called_class();
		$this->nome = $nome;
	}
	
	/**
	 * @return string
	 */
	public function getNome()
	{
		return $this->nome;
	}
	
	/**
	 *
	 * @param $endereco Endereco
	 */
	final public function setEndereco(Endereco $endereco)
	{
		$this->endereco = $endereco;
	}
	
	/**
	 * @return Endereco
	 */
	public function getEndereco()
	{
		return $this->endereco;
	}
	
	
	public function __destruct()
	{
		echo 'Morri!';
		self::$quantidade--;
	}
	
	public function getAuditoria($metodo)
	{
		return $this->auditoria[$metodo];
	}

	public function __isset($variable)
	{	
		$this->tests++;			
	}	
	
	public function getTests()
	{
		return $this->tests;
	}
	
	
}
