<?php
class Cambio {
	public static function getTaxas()
	{
		return array(
			Moedas::DOLAR => 
				array(Moedas::REAL => 2),
			Moedas::GUARANI => 
				array(Moedas::REAL => 0.5),
			Moedas::EURO => 
				array(Moedas::REAL => 3),
			Moedas::REAL => 
				array(Moedas::REAL => 1)			
		);
	}
}

?>