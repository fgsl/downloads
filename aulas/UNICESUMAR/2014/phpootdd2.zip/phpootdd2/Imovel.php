<?php
abstract class Imovel {
	public static function getLocalizacao()
	{
		return 'Localização de ' . __CLASS__;
	}
	
	public static function getComprador()
	{
		return 'Comprador de ' . static::getLocalizacao();
	}
}