<?php
class Apartamento extends \Imovel {
	public $sleepCount = 0;
	public $wakeUpCount = 0;
	
	
	public static function getLocalizacao()
	{
		return 'Localização Privilegiada de ' . __CLASS__;		
	}
	
	public function __sleep()
	{
		$this->sleepCount++;
		return array_keys(get_object_vars($this));
	}
	
	public function __wakeup()
	{
		$this->sleepCount = 0;
		$this->wakeUpCount++;
	}
	
	
	
}