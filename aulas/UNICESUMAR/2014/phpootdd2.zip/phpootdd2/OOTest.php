<?php
class OOTest extends PHPUnit_Framework_TestCase{
	public function setUp()
	{
		require 'autoloader.php';
	}	
	
	public function testIdInstances()
	{		
		$aluno1 = new Aluno();
		$aluno2 = new Aluno();
		$aluno3 = new Aluno();
		
		$id1 = spl_object_hash($aluno1);
		$id2 = spl_object_hash($aluno2);
		$id3 = spl_object_hash($aluno3);
		
		$this->assertTrue($id1 <> $id2);
		$this->assertTrue($id2 <> $id3);
		$this->assertTrue($id1 <> $id3);
	}
	
	public function testAttribute()
	{
		$aluno = new Aluno();
		
		$nome = 'Epaminondas';
		
		$aluno->setNome($nome);
		
		$this->assertEquals('Epaminondas',$aluno->getNome());		
	}
	
	public function testConstruct()
	{
		$aluno = new Aluno();
		
		$this->assertInstanceOf('Endereco',$aluno->getEndereco());
	}
	
	public function testPrivateConstruct()
	{
		$reflection = new ReflectionClass('Moedas');
		$construtor = $reflection->getConstructor();
		$this->assertTrue($construtor->isPrivate());		
	}
	
	public function testStaticProperty()
	{
		$aluno1 = new Aluno();
		$aluno2 = new Aluno();
		$aluno3 = new Aluno();
		
		$this->assertEquals(3,Aluno::getQuantidade());		
		
		unset($aluno2);

		$this->assertEquals(2,Aluno::getQuantidade());	
		
	}
	
	public function testFinalClass()
	{
		$reflection = new ReflectionClass('Aluno');
		$this->assertTrue($reflection->isFinal());				
	}
	
	public function testInterface()
	{				
		$reflection = new ReflectionClass('Pessoa');
		$this->assertTrue($reflection->isAbstract());
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}