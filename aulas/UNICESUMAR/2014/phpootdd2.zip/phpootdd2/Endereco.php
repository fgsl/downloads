<?php
class Endereco {
	/**
	 * 
	 * @var string
	 */
	private $logradouro;
	/**
	 * 
	 * @var string
	 */
	private $complemento;
	/**
	 * 
	 * @var string
	 */
	private $cep;
	/**
	 * 
	 * @var string
	 */
	private $cidade;
	/**
	 * 
	 * @var string
	 */
	private $uf;
		
	public function __set($attribute, $value)
	{
		$this->$attribute = $value;
	}
	
	public function __get($attribute)
	{
		return $this->$attribute;
	}
	
	public function __call($method, array $args)
	{
		$prefix = substr($method,0,3);
		if ($prefix == 'get'){
			$attribute = lcfirst(substr($method,3));
			return $this->$attribute;
		}
		if ($prefix == 'set'){
			$attribute = lcfirst(substr($method,3));
			$this->$attribute = $args[0];
		}		
	}

	public function __invoke()
	{
		$endereco = $this->logradouro . ' ' .
		$this->complemento . ' ' . $this->cidade
		. $this->cep . ' ' . $this->uf;
		return $endereco;
	}
	
	
	
	
}