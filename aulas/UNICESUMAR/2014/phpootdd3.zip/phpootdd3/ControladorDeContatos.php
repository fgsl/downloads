<?php
class ControladorDeContatos {
	private $gateway;
	
	public function __construct($gateway)
	{
		$this->gateway = $gateway;
	}
	
	public function persistir(Contato $contato)
	{
		$this->gateway->persistir($contato);
	}
}