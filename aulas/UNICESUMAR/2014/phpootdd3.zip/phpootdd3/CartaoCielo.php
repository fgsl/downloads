<?php
class CartaoCielo implements Cartao {
	
	public function lerCartao()
	{
		
	}
}