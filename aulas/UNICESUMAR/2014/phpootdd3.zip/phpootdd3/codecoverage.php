<?php
require 'autoloader.php';
require __DIR__ . '/vendor/autoload.php';

try {
	$coverage = new PHP_CodeCoverage ();
	$files = scandir ( __DIR__ );
	foreach ( $files as $file ) {
		if (strpos ( $file, 'Test.php' ) !== FALSE) {
			$className = substr ( $file, 0, strlen ( $file ) - 4 );
			echo $className . "\n";
			$coverage->start ( $className );
			call_user_func ( array (
					new $className (),
					'run' 
			) );
			$coverage->stop ();
		}
	}
	$writer = new PHP_CodeCoverage_Report_Clover ();
	$writer->process ( $coverage, __DIR__ . '/coverage.xml' );
	$writer = new PHP_CodeCoverage_Report_HTML ();
	$writer->process ( $coverage, __DIR__ . '/report' );
} catch ( Exception $e ) {
	echo $e->getMessage () . "\n";
	echo $e->getTraceAsString ();
}

	
