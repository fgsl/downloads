<?php
require 'autoloader.php';

$caixa = new Caixa(new CartaoRedecard());

$caixa->receberPagamento();