<?php
class ContatoGateway {
	public function inserir(Contato $contato)
	{
		// TODO	
	}
	
	public function alterar(Contato $contato)
	{
		// TODO
	}
	
	public function excluir(Contato $contato)
	{
		// TODO
	}
	
	public function pesquisar(Contato $contato)
	{
		// TODO
	}
	
	public function persistir(Contato $contato)
	{
		$contatoExistente = $this->pesquisar($contato);
		
		if (empty($contatoExistente)){
			$this->inserir($contato);
		} else {
			$this->alterar($contato);
		}
	}
	
	
	
	
	
	
}
