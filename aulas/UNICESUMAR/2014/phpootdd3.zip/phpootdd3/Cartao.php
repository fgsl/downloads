<?php
interface Cartao {
	public function lerCartao();
}