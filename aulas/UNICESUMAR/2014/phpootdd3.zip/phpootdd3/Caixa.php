<?php
class Caixa {
	/**
	 * 
	 * @var Cartao
	 */
	private $leitorDeCartao;
	
	public function __construct(Cartao $leitorDeCartao)
	{
		$this->leitorDeCartao = $leitorDeCartao;
	}
	
	
	public function receberPagamento()
	{
		$this->leitorDeCartao->lerCartao();
	}
}