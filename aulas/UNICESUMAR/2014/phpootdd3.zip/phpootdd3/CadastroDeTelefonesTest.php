<?php
class CadastroDeTelefonesTest extends PHPUnit_Framework_TestCase{
	
	public function setUp()
	{
		require 'autoloader.php';
	}
	
	
	public function testIncluir()
	{
		$contato = new Contato();
		$contato->nome = 'Aníbal';
		$contato->telefone = '55 41 987678776';

		$gateway = $this->getMock('ContatoGateway');
		
		$gateway->method('inserir')
		->willReturn(1);			
		
		$this->assertEquals(1, $gateway->inserir($contato));		
	}
	
	public function testAlterar()
	{
		
	}
	
	public function testExcluir()
	{
		
	}
	
	public function testPesquisar()
	{
		
	}	
	
	public function testPersistir()
	{
		$contato = new Contato();
		$contato->nome = 'Aníbal';
		$contato->telefone = '55 41 987678776';
		
		$gateway = $this->getMock('ContatoGateway');
		
		$gateway->expects($this->exactly(1))
		->method('persistir')
		->with($this->equalTo($contato));		
		
		$controlador = new ControladorDeContatos($gateway);
		$controlador->persistir($contato);		
	}
	
	/**
	 * @expectedException OverflowException
	 */
	public function testException()
	{
		throw new OverflowException();	
	}
	
	
	
}
