<?php
class CartaoRedecard implements Cartao {
	public function lerCartao()
	{
		
	}
}