<?php
class Contato {
	/**
	 * 
	 * @var string
	 */
	public $nome;
	/**
	 * 
	 * @var string
	 */
	public $telefone;
}
