<?php

class CrmTest extends PHPUnit_Framework_TestCase
{
    public function setUp()
    {
        spl_autoload_register(function($className){
           include $className . '.php'; 
        });
    }
    
    
    public function testHeranca()
    {
        $crm = new Crm();
        
        $resultado = $crm->emitirRelatorio();
        
        $this->assertEquals($resultado,'Imprimindo...');
    }
    
    public function testTrait()
    {
        $crm = new Crm();
        
        $resultado = $crm->marcarCompromisso();
        
        $this->assertEquals($resultado,'Compromisso marcado.');
    }
}