<?php

class Crm extends Enterprise
{
    use Agenda;
}