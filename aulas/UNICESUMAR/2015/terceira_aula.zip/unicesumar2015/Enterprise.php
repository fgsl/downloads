<?php

abstract class Enterprise
{
    public function emitirRelatorio()
    {
        return 'Imprimindo...';    
    }   
}