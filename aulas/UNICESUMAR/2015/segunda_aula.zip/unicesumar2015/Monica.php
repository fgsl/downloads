<?php
class Monica {
}

?>