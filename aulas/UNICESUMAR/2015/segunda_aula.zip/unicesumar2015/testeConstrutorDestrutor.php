<?php
spl_autoload_register(
function($className) {
	require $className . '.php';
});

$gato = new Carnivora(TRUE,32,'azuis','grosso');

if ($gato->getCauda() &&
$gato->getDentes() == 32 &&
$gato->getOlhos() == 'azuis' &&
$gato->getPelo() == 'grosso'){
	echo 'Passou no teste';
} else {
	echo 'Não passou no teste';
} 
