<?php
interface Movimento {
	public static function andar();
	public static function correr();
	public static function parar();
}
