<?php

/**
 *
 * @author fgsl
 */
abstract class Mammalia implements Movimento
{

    /**
     *
     * @var boolean
     *
     */
    protected $cauda = FALSE;

    /**
     *
     * @var integer
     *
     */
    protected $dentes = 0;

    /**
     *
     * @var string
     *
     */
    protected $olhos = 'pretos';

    /**
     *
     * @var string
     *
     */
    protected $pelo = 'fino';

    /**
     *
     * @var string
     */
    protected $casco;

    /**
     *
     * @var boolean
     */
    protected $clonado = FALSE;

    /**
     *
     * @var integer
     *
     */
    protected static $individuos = 0;

    /**
     */
    public function __construct($cauda = FALSE, $dentes = 0, $olhos = 'pretos', $pelo = 'fino')
    {
        $this->cauda = $cauda;
        $this->dentes = $dentes;
        $this->olhos = $olhos;
        $this->pelo = $pelo;
        
        self::$individuos ++;
    }

    /**
     *
     * @param boolean $cauda            
     *
     */
    public function setCauda($cauda)
    {
        $this->cauda = $cauda;
    }

    /**
     *
     * @return boolean
     *
     */
    public function getCauda()
    {
        return $this->cauda;
    }

    /**
     *
     * @return integer
     *
     */
    public function getDentes()
    {
        return $this->dentes;
    }

    /**
     *
     * @return string
     *
     */
    public function getOlhos()
    {
        return $this->olhos;
    }

    /**
     *
     * @return string
     *
     */
    public function getPelo()
    {
        return $this->pelo;
    }

    /**
     *
     * @return integer
     *
     */
    public static function getIndividuos()
    {
        return self::$individuos;
    }

    public static function andar()
    {
        return 'andando...';
    }

    public static function correr()
    {
        return static::andar();
    }

    public static function parar()
    {}

    public function getCalledClass()
    {
        return get_called_class();
    }

    public function getClass()
    {
        return __CLASS__;
    }

    public function __destruct()
    {
        self::$individuos --;
        // echo 'A instância ' . spl_object_hash ( $this ) . ' foi destruída.' . "\n";
    }

    public function __set($name, $value)
    {
        $this->$name = $value;
    }

    public function __get($name)
    {
        return $this->$name;
    }

    public function __call($method, array $args)
    {
        if (substr(strrev($method), 0, 4) == strrev('Type')) {
            $method = substr($method, 0, - 4);
            $attribute = lcfirst(substr($method, 3));
            return gettype($this->$attribute);
        }
        throw new Exception("method does not exists");
    }

    public function __isset($attribute)
    {
        return isset($this->$attribute);
    }

    public function __invoke()
    {
        return $this->getClass();
    }

    public function __callStatic($method, array $args)
    {
        if ($method == 'getSelf') {
            return get_called_class();
        }
    }

    public function __toString()
    {
        return get_called_class();
    }

    public function getClonado()
    {
        return $this->clonado;
    }

    public function __clone()
    {
        $this->clonado = TRUE;
    }
}
