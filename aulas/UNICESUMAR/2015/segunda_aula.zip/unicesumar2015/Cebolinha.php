<?php
class Cebolinha
{
	public function receberCoelhada(Monica $monica)
	{
	}
}
