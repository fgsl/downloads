<?php 
class Herbivora extends Mammalia
{
	public function comunicar()
	{
		return 'grunf...';
	}
}
