<?php
class TesteInstancia extends PHPUnit_Framework_TestCase
{
	public function setUp()
	{
		error_reporting(E_ERROR | E_PARSE);
		spl_autoload_register(
		function($className) {
		include $className . '.php';
		});
	}

	public function testIgualdadeDeInstancias()
	{
		$lobo = new Carnivora();
		$cachorro = new Carnivora();
		$urso = new Carnivora();

		$this->assertNotEquals(spl_object_hash($lobo),spl_object_hash($cachorro));
		$this->assertNotEquals(spl_object_hash($lobo),spl_object_hash($urso));

		unset($lobo);
		unset($cachorro);
		unset($urso);
	}

	public function testVisibilidade()
	{
		$gato = new Carnivora();
		$gato->setCauda(TRUE);
	
		$this->assertTrue($gato->getCauda());

		unset($gato);
	}

	public function testStatic()
	{
		$gato = new Carnivora();
		$ornitorrinco = new Carnivora();
		$peixeBoi = new Carnivora();

		$this->assertEquals(3, Carnivora::getIndividuos());

		unset($gato);
		unset($ornitorrinco);
		unset($peixeBoi);
	}

	public function testHeranca()
	{
		$carcaju = new Carnivora(TRUE,46,'castanhos','duro');


		$cauda = $carcaju->getCauda();
		$dentes = $carcaju->getDentes();
		$olhos = $carcaju->getOlhos();
		$pelo = $carcaju->getPelo();
		$individuos = Carnivora::getIndividuos();

		$this->assertTrue($cauda);
		$this->assertEquals($dentes,46);
		$this->assertEquals($olhos,'castanhos');
		$this->assertEquals($pelo,'duro');
		$this->assertEquals($individuos,1);		
	}	

	public function testComparacaoDeObjetos()
	{
		$leao = new Carnivora();
		$tigre = new Carnivora();

		$this->assertTrue($leao == $tigre);

		$pantera = $tigre;

		$this->assertTrue($pantera === $tigre);

		$leopardo = clone $tigre;

		$this->assertFalse($leopardo === $tigre);
	}

	public function testComparacaoDeClasses()
	{
		$vaca = new Herbivora();
		$diaboDaTasmania = new Carnivora();

		$this->assertInstanceOf('Herbivora',$vaca);
		$this->assertEquals(get_class($diaboDaTasmania),'Carnivora');

		$shaun = new Ovelha();

		$this->assertEquals('Ovelha',$shaun->getCalledClass());
		$this->assertEquals('Mammalia',$shaun->getClass());


	}

	public function testTipoNaAssinatura()
	{
		$cebolinha = new Cebolinha();
		$reflexao = new ReflectionClass(get_class($cebolinha));
		$metodos = $reflexao->getMethods();

		$argumentos = $metodos[0]->getParameters();

		$argumento = $argumentos[0];

		$this->assertEquals($argumento->getClass()->name,'Monica');	

	}	

	public function testLateStaticBindings()
	{
		$acao = Ovelha::correr();

		$this->assertEquals('pulando...',$acao);
	}


	public function testSerialize()
	{
		$ovelha = new Ovelha();
		
		$serial = serialize($ovelha);
		
		$this->assertTrue($ovelha->serializado);
		
		//$this->assertTrue(strpos(serial,'O:') !== FALSE);
		
		file_put_contents(__DIR__ . '/serial.txt', $serial);
	}
	
	public function testUnserialize()
	{
		$serial = file_get_contents(__DIR__ . '/serial.txt');
		
		$ovelha = unserialize($serial);
		
		//$this->assertFalse($ovelha->serializado);
		
		$this->assertInstanceOf('Ovelha',$ovelha);
	}
	
	public function testSetAndGet()
	{
		$ovelha = new Ovelha();
		
		$ovelha->casco = 'preto';
		
		$this->assertEquals($ovelha->casco,'preto');
	}
	
	public function testDynamicMethod()
	{
		$ovelha = new Ovelha();
		
		$this->assertEquals('integer',$ovelha->getDentesType());
		$this->assertEquals('string',$ovelha->getOlhosType());
		
		echo $ovelha->getDentesType() . "\n";
	}
	
	public function testIsset()
	{
		$ovelha = new Ovelha();
		
		$this->assertTrue(isset($ovelha->dentes));
		$this->assertTrue(isset($ovelha->olhos));
	}
	
	public function testInvoke()
	{
		$gnu = new Herbivora();
		
		$this->assertEquals('Mammalia',$gnu());		
	}
	
	public function testCallStatic()
	{
		$this->assertEquals('Carnivora',Carnivora::getSelf());;
	}
	
	public function testToString()
	{
		$frase1 = 'O nome da classe é Ovelha';
		
		$ovelha = new Ovelha();
		
		$frase2 = 'O nome da classe é ' . $ovelha;
		
		
		$this->assertEquals($frase1,$frase2);
	}
	
	public function testClone()
	{
		$boi = new Herbivora();
		$bisao = clone $boi;
		
		$this->assertFalse($boi->getClonado());
		$this->assertTrue($bisao->getClonado());
	}	
	
	
	
	
	
	
	
	

















































}
