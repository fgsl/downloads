<?php
spl_autoload_register(
function($className) {
	require $className . '.php';
});

$gato = new Carnivora();
$gato->setCauda(TRUE);


if ($gato->getCauda()){
	echo 'Passou no teste';
} else {
	echo 'Não passou no teste';
} 
