<?php 
final class Ovelha extends Herbivora
{
	public $serializado = FALSE;

	public function comunicar()
	{
		return 
		parent::comunicar() . 'béééé...';
	}

	public function getCauda(){
		return $this->cauda;
	}

	public static function andar()
	{
		return 'pulando...';
	}
	
	public function __sleep()
	{
		$this->serializado = TRUE;
	}
	
	public function __wakeup()
	{
		//throw new Exception();
		$this->serializado = FALSE;
	}
	
	
}
