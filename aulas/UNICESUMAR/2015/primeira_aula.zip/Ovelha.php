<?php 
final class Ovelha extends Herbivora
{


	public function comunicar()
	{
		return 
		parent::comunicar() . 'béééé...';
	}
public function getCauda(){
return $this->cauda;
}

}
