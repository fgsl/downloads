<?php 
class Carnivora extends Mammalia
{
}
