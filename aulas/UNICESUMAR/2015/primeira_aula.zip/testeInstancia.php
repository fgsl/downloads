<?php

spl_autoload_register(
function($className) {
	require $className . '.php';
});


$lobo = new Carnivora();
$cachorro = new Carnivora();
$urso = new Carnivora();

if (spl_object_hash($lobo) <> 
spl_object_hash($cachorro) &&
spl_object_hash($lobo) <>
spl_object_hash($urso)){
	echo 'Passou no teste';
} else {
	echo 'Não passou no teste';
} 
