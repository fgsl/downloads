<?php
interface Movimento {
	public function andar();
	public function correr();
	public function parar();
}
