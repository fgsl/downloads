<?php
require 'Mammalia.php';
require 'Carnivora.php';

$carcaju = new Carnivora(TRUE,46,'castanhos','duro');


$cauda = $carcaju->getCauda();
$dentes = $carcaju->getDentes();
$olhos = $carcaju->getOlhos();
$pelo = $carcaju->getPelo();
$individuos = Carnivora::getIndividuos();

if ( $cauda &&
 $dentes == 46 &&
 $olhos == 'castanhos' &&
 $pelo == 'duro' &&
$individuos == 1){
	echo "Passou no teste \n";
} else {
	echo "Não passou no teste \n";
} 

echo 'Cauda: ' . ($cauda ? 'Tem' : 'Não tem') . "\n";
echo "Dentes: $dentes \n";
echo "Olhos: $olhos \n";
echo "Pelo: $pelo \n";



