<?php
spl_autoload_register(
function($className) {
	require $className . '.php';
});


$gato = new Carnivora();
$ornitorrinco = new Carnivora();
$peixeBoi = new Carnivora();

if (Carnivora::getIndividuos()==3){
	echo "Passou no teste\n";
} else {
	echo "Não passou no teste\n";
}

echo 'Número de instâncias:' . Carnivora::getIndividuos() . "\n";
 
