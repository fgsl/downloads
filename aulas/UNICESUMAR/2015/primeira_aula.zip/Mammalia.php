<?php
/**
*
* @author fgsl
*/
abstract class Mammalia implements Movimento {
/**
*
* @var boolean
*/
protected $cauda = FALSE;
/**
*
* @var integer
*/
protected $dentes = 0;
/**
*
* @var string
*/
protected $olhos = 'pretos';
/**
*
* @var string
*/
protected $pelo = 'fino';

/**
* @var integer
*/
protected static $individuos = 0;

/**
*
*/
public function __construct($cauda = FALSE,$dentes = 0,$olhos = 'pretos',$pelo = 'fino')
{
	$this->cauda = $cauda;
	$this->dentes = $dentes;
	$this->olhos = $olhos;
	$this->pelo = $pelo;

	self::$individuos++;
}


/**
*
* @param boolean $cauda
*/
public function setCauda($cauda){
$this->cauda = $cauda;
}
/**
*
* @return boolean
*/
public function getCauda(){
return $this->cauda;
}

/**
*
* @return integer
*/
public function getDentes(){
return $this->dentes;
}


/**
*
* @return string
*/
public function getOlhos(){
return $this->olhos;
}

/**
*
* @return string
*/
public function getPelo(){
return $this->pelo;
}

/**
* @return integer
*/
public static function getIndividuos()
{
	return self::$individuos;
}

public function andar(){}
public function correr(){}
public function parar(){}






}
