<?php
/*
 * Cenário:
 * Tres amigos pagam uma conta em conjunto,
 * sendo que cada um da um valor em moeda 
 * diferente.
 * A conta foi R$ 90,00
 * 
 * Um amigo deu R$ 10,00
 * Um amigo deu US$ 30,00
 * Um amigo deu G$ 500,00
 * 
 * 1 US$ = R$ 4,00
 * 1 G$ = R$ 0,25
 * 
 * Soma dos valores pagos:
 * 10,00 + (4 * 30) + (0.25 * 500)
 * 10,00 + 120,00 + 125 
 * 255
 * 
 * 
 * Troco = 255 - 90 = 165
 */

spl_autoload_register(function($className){
	require $className . '.php';
});


$caixa = new Caixa();

$caixa->setValorDaConta(90);

$caixa->receberPagamento(10)
->receberPagamento(30,'USD')
->receberPagamento(500,'GUA');


$troco = $caixa->getTroco();


if ($troco == 165)
{
	echo "Passou no teste \n";
} else 
{
	echo "Não passou no teste \n";
}




