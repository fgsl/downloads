<?php
class Caixa {
	
	/**
	 * 
	 * @var float
	 */
	private $valorDoPagamento;
	
	/**
	 * 
	 * @var float
	 */
	private $valorDaConta = 0;
	
	public function receberPagamento($valor,$moeda = 'BRL')
	{
		$cambio = new Cambio();
		$this->valorDoPagamento+= $cambio->converter($valor,$moeda,'BRL');
		return $this;
	}
	
	
	/**
	 * 
	 * @param float $valorDaConta
	 */
	public function setValorDaConta($valorDaConta)
	{
		$this->valorDaConta = $valorDaConta;
	}
	
	public function getTroco()
	{
		return $this->valorDoPagamento - $this->valorDaConta;	
	}
}