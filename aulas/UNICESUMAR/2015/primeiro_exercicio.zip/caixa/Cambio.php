<?php
class Cambio {
	
	private $cotacoes = array(
		'USD' => array(
				'BRL' => 4
		),
		'GUA' => array(
				'BRL' => 0.25
		),
		'BRL' => array(
					'BRL' => 1
		)				
					
	);
	
	public function converter($valor,$origem = 'BRL',$destino)
	{
		return $this->cotacoes[$origem][$destino] * $valor;
	}
	
}

?>