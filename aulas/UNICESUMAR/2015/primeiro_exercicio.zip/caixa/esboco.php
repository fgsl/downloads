<?php
$cambio = array(
		'USD' => array(
				'BRL' => 4,
				'EUR' => 1.5,
				'GUA' => 40
			),
		'BRL' => array(
				'USD' => 0.25,
				'EUR' => 0.75,
				'GUA' => 0.5				
		)
);

$moeda->setCambio('USD','BRL',4);

$this->cambio[$origem][$destino] = $fator;








