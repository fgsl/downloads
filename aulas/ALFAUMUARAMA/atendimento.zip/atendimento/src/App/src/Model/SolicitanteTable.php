<?php
namespace App\Model;

use Zend\Db\TableGateway\TableGatewayInterface;

class SolicitanteTable {
	private $tableGateway;

	public function __construct(TableGatewayInterface $tableGateway){
		$this->tableGateway = $tableGateway;
	}

	public function save(array $data)
	{
		$this->tableGateway->insert($data);
	}

	public function getAll()
	{
		return $this->tableGateway->select(null);
	}

	public function delete($cpf)
	{
		$this->tableGateway->delete(['cpf' => $cpf]);	
	}


}