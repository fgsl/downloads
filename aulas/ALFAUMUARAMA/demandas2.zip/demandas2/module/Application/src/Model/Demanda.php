<?php
namespace Application\Model;

class Demanda
{
    /**
     * @var integer
     */
    public $codigo;
    /**
     * @var Assunto
     */
    public $assunto;
    /**
     * @var Solicitante
     */
    public $solicitante;
}

