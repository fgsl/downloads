<?php
namespace Application\Model;

class Assunto
{
    public $codigo;
    public $assunto;
    public $detalhes;
}