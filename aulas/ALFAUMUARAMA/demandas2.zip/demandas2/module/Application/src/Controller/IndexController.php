<?php
/**
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2016 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Application\Controller;

use Zend\Db\Sql\Expression;
use Zend\Db\Sql\Insert;
use Zend\Db\Sql\Select;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Interop\Container\ContainerInterface;
use Application\Model\Solicitante;
use Application\Model\Assunto;


class IndexController extends AbstractActionController
{
    /**
     * @var ContainerInterface
     */
    private $container;
    
    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;   
    }
    
    
    public function indexAction()
    {
        return new ViewModel();
    }
    
    public function processarAction()
    {
        $solicitante = new Solicitante($_POST);
        $assunto = new Assunto($_POST);
        
        $_SESSION['dados'] = [
            'solicitante' => $solicitante,
            'assunto' => $assunto
        ];
        
        
        if (empty($solicitante->cpf) || empty($assunto->assunto) || empty($assunto->detalhes)) {
            $_SESSION['mensagem'] = 'Preencha os campos!';
            return $this->redirect()->toRoute('application');
        }
        
        $solicitanteTable = $this->container->get('SolicitanteTable');        

        $solicitanteTable->persist($solicitante);
        
        $assuntoTable = $this->container->get('AssuntoTable');
        
        $result = $assuntoTable->getByAssunto($assunto->assunto);
        
        if ($result->count() > 0) {
            $_SESSION['dados']['detalhes_gravados'] = $result->current()['detalhes'];
            return $this->redirect()->toRoute('application');
        } else {
            $assuntoTable->persist($assunto);
            $codigoAssunto = $assuntoTable->getMaxCodigo();
        }
        
        $insert = new Insert('demanda');
        $insert->columns(['codigo_solicitante','codigo_assunto'])
        ->values([$cpf,$codigoAssunto]);
        $sql = $insert->getSqlString($adapter->getPlatform());
        
        $statement = $adapter->query($sql);
        $result = $statement->execute();
        
        $_SESSION['dados'] = [];
        
        return new ViewModel();
    }
    
    
    
    
    
    
    
    
    
}
